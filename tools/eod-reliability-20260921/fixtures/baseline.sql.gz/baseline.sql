--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA IF NOT EXISTS public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_authorization_status AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_client_type AS ENUM (
    'public',
    'confidential'
);


--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_response_type AS ENUM (
    'code'
);


--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: _apply_delivery_items(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._apply_delivery_items(p_delivery_id uuid, p_items jsonb) RETURNS text
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_fp text;
begin
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'delivery % must have at least one line item', p_delivery_id using errcode = '23514';
  end if;

  -- Upsert (aggregate duplicate products by sum).
  insert into public.delivery_items
    (delivery_id, product_catalog_id, quantity_ordered, customer_price)
  select p_delivery_id, t.pid, t.qty, t.price
  from (
    select (e->>'product_catalog_id')::uuid                       as pid,
           sum(greatest((e->>'quantity_ordered')::int, 1))        as qty,
           nullif(sum(coalesce((e->>'customer_price')::numeric, 0)), 0) as price
      from jsonb_array_elements(p_items) e
     where (e->>'product_catalog_id') is not null
     group by (e->>'product_catalog_id')::uuid
  ) t
  on conflict (delivery_id, product_catalog_id) do update
    set quantity_ordered = excluded.quantity_ordered,
        customer_price   = excluded.customer_price,
        updated_at       = now();

  -- Prune lines no longer in the set.
  delete from public.delivery_items di
   where di.delivery_id = p_delivery_id
     and di.product_catalog_id not in (
       select (e->>'product_catalog_id')::uuid
         from jsonb_array_elements(p_items) e
        where (e->>'product_catalog_id') is not null);

  v_fp := public._items_fingerprint(p_delivery_id);
  update public.deliveries set items_fingerprint = v_fp where id = p_delivery_id;
  return v_fp;
end;
$$;


--
-- Name: _apply_delivery_zone(uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._apply_delivery_zone(p_delivery_id uuid, p_location_id uuid, p_audit_reason text) RETURNS TABLE(charged numeric, agent_payment numeric)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_row           public.deliveries%rowtype;
  v_charged       numeric;
  v_agent_payment numeric;
begin
  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;

  -- Keyed on (location, client, agent) exactly like correct_delivery_location /
  -- update_delivery_fields; passing assigned_agent_id reapplies the agent bonus.
  select er.charged, er.agent_payment
    into v_charged, v_agent_payment
    from public.effective_rate(p_location_id, v_row.client_id, v_row.assigned_agent_id) er;
  if v_charged is null then
    raise exception
      'no active rate card for (location=%, client=%); add one before changing the zone',
      p_location_id, v_row.client_id
      using errcode = '22023',
            hint   = 'add a rate_card row for this location/client first';
  end if;

  update public.deliveries
     set location_id            = p_location_id,
         charged_snapshot       = v_charged,
         agent_payment_snapshot = v_agent_payment,
         agent_payment_base_snapshot = v_agent_payment,
         agent_payment_base_captured_at = clock_timestamp(),
         updated_at             = now()
   where id = p_delivery_id;

  perform public.write_audit(
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old := jsonb_build_object(
      'location_id',            v_row.location_id,
      'charged_snapshot',       v_row.charged_snapshot,
      'agent_payment_snapshot', v_row.agent_payment_snapshot
    ),
    p_new := jsonb_build_object(
      'location_id',            p_location_id,
      'charged_snapshot',       v_charged,
      'agent_payment_snapshot', v_agent_payment
    ),
    p_reason   := p_audit_reason,
    p_actor_id := auth.uid()
  );

  charged := v_charged;
  agent_payment := v_agent_payment;
  return next;
end;
$$;


--
-- Name: _apply_item_deliveries(uuid, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._apply_item_deliveries(p_delivery_id uuid, p_item_quantities jsonb) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_sum integer;
begin
  update public.delivery_items di
     set quantity_delivered = t.qd,
         updated_at = now()
  from (
    select (e->>'product_catalog_id')::uuid as pid,
           sum((e->>'quantity_delivered')::int) as qd
      from jsonb_array_elements(p_item_quantities) e
     where (e->>'product_catalog_id') is not null
     group by (e->>'product_catalog_id')::uuid
  ) t
  where di.delivery_id = p_delivery_id
    and di.product_catalog_id = t.pid;

  select coalesce(sum(quantity_delivered), 0) into v_sum
    from public.delivery_items where delivery_id = p_delivery_id;
  return v_sum;
end;
$$;


--
-- Name: _assert_customer_not_blacklisted(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._assert_customer_not_blacklisted(p_phone text, p_phone_alt text) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare
  v_hit public.customer_blacklist;
begin
  v_hit := public._customer_blacklist_hit(p_phone, p_phone_alt);
  if v_hit.id is not null then
    raise exception 'Customer number % is blacklisted: %', v_hit.phone_display, v_hit.reason
      using errcode = 'P0001',
            hint = jsonb_build_object(
              'kind', 'blacklisted', 'entry_id', v_hit.id,
              'phone', v_hit.phone_display, 'reason', v_hit.reason,
              'matched_on', case when v_hit.phone_normalized = public._norm_phone(p_phone)
                                 then 'phone' else 'alt' end)::text;
  end if;
end;
$$;


--
-- Name: _assert_holds_lock(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._assert_holds_lock(p_entity_type text, p_entity_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not exists (
    select 1 from public.edit_locks
     where entity_type = p_entity_type
       and entity_id   = p_entity_id
       and user_id     = auth.uid()
       and acquired_at > now() - interval '5 minutes'
  ) then
    raise exception 'edit lock not held (or expired) for this %', p_entity_type
      using errcode = '55P03';
  end if;
end $$;


--
-- Name: _assert_same_customer_settlement_ready(text, uuid, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._assert_same_customer_settlement_ready(p_subject text, p_id uuid, p_day date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$ begin
  if p_subject<>'agent' then return; end if;
  perform public._refresh_same_customer_pay_period(p_id,p_day);
  if exists(select 1 from public.same_customer_earnings where rider_id=p_id and accounting_date=p_day
    and active and policy_applied and final_state='pending') then
    raise exception 'rider pay needs review before this period can be settled' using errcode='P0001';
  end if;
end $$;


--
-- Name: _calls_set_channel(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._calls_set_channel() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if new.agora_channel is null or new.agora_channel = '' then
    new.agora_channel := 'call-' || new.id::text;
  end if;
  return new;
end $$;


--
-- Name: _copy_delivery_items(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._copy_delivery_items(p_parent uuid, p_child uuid) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  insert into public.delivery_items (delivery_id, product_catalog_id, quantity_ordered, customer_price)
  select p_child, product_catalog_id, quantity_ordered, customer_price
    from public.delivery_items where delivery_id = p_parent
  on conflict (delivery_id, product_catalog_id) do nothing;
  update public.deliveries set items_fingerprint = public._items_fingerprint(p_child) where id = p_child;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customer_blacklist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_blacklist (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    phone_normalized text NOT NULL,
    phone_display text NOT NULL,
    reason text NOT NULL,
    source_delivery_id uuid,
    added_by uuid NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    removed_by uuid,
    removed_at timestamp with time zone,
    removal_note text
);


--
-- Name: _customer_blacklist_hit(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._customer_blacklist_hit(p_phone text, p_phone_alt text) RETURNS public.customer_blacklist
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select b.* from public.customer_blacklist b
   where b.removed_at is null
     and b.phone_normalized in (public._norm_phone(p_phone), public._norm_phone(p_phone_alt))
   order by (b.phone_normalized = public._norm_phone(p_phone)) desc, b.added_at desc
   limit 1;
$$;


--
-- Name: _delivery_items_sig(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._delivery_items_sig(p_items jsonb) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  select public._items_fingerprint_from_canon(
    string_agg(t.pid || ':' || t.qty::text, '|' order by t.pid)
  )
  from (
    select (elem->>'product_catalog_id')               as pid,
           sum((elem->>'quantity_ordered')::integer)   as qty
      from jsonb_array_elements(coalesce(p_items, '[]'::jsonb)) elem
     where elem->>'product_catalog_id' is not null
     group by (elem->>'product_catalog_id')
  ) t
$$;


--
-- Name: _dm_is_terminal_status(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._dm_is_terminal_status(p_status text) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$
  select p_status = any(array[
    'delivered','cancelled','failed_delivery','unserious','rolled_over'
  ])
$$;


--
-- Name: _dm_issue_label(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._dm_issue_label(p_issue_type text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select case p_issue_type
    when 'wrong_address'     then 'Wrong address'
    when 'cant_reach_client' then 'Can''t reach client'
    when 'payment_dispute'   then 'Payment dispute'
    when 'product_issue'     then 'Product issue'
    when 'other'             then 'Issue'
    else 'Issue'
  end
$$;


--
-- Name: _effective_scheduled_date(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._effective_scheduled_date(p_scheduled_date date, p_created_via text) RETURNS date
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  with n as (
    select (now() at time zone 'Africa/Lagos')::timestamp as lagos_now
  ),
  d as (
    select lagos_now::date as lagos_today,
           extract(hour from lagos_now)::int as lagos_hour
      from n
  )
  select case
    when d.lagos_hour >= 22 and p_scheduled_date = d.lagos_today
      then public._ensure_workday(d.lagos_today + 1)
    when p_created_via = 'bot' and p_scheduled_date < d.lagos_today
      then public._ensure_workday(
             case when d.lagos_hour >= 22 then d.lagos_today + 1
                  else d.lagos_today
             end)
    else p_scheduled_date
  end
  from d;
$$;


--
-- Name: _ensure_workday(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._ensure_workday(p_candidate date) RETURNS date
    LANGUAGE sql IMMUTABLE
    AS $$
  select case
    when extract(isodow from p_candidate) = 7   -- ISO Sunday
      then p_candidate + 1
    else p_candidate
  end
$$;


--
-- Name: _eod_classify(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._eod_classify(p_for_date date) RETURNS TABLE(delivery_id uuid, current_status text, action text, resolved_sibling_status text, resolved_sibling_label text, group_max_sort integer)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  with eligible as (
    select d.id, d.client_id, d.assigned_agent_id, d.current_status,
           d.customer_phone_normalized,
           coalesce(d.items_fingerprint, d.product_catalog_id::text) as item_key,  -- [Feature A]
           d.scheduled_date,
           d.text_fingerprint,
           public._norm_address(d.raw_address) as norm_addr,
           d.created_at, d.updated_at, d.rollover_count,
           sd.sort_order as status_sort,
           sd.category   as status_category,
           cl.auto_cancel_soft_fails,
           resolved.sibling_status as resolved_sibling_status,
           resolved.sibling_label  as resolved_sibling_label,
           (resolved.sibling_status is not null) as has_resolved_sibling
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
      join public.clients cl on cl.id = d.client_id
      left join lateral (
        select sib.current_status as sibling_status, sib_def.label as sibling_label
          from public._find_sibling_deliveries(d.id) sib
          join public.delivery_status_defs sib_def on sib_def.status = sib.current_status
         where sib_def.category = 'terminal'
           and sib.current_status not in ('agent_cancelled', 'rolled_over')
         order by sib.created_at desc, sib.id limit 1
      ) as resolved on true
     where (d.scheduled_date = p_for_date
            -- Client policy (auto_cancel_soft_fails): a postponed order is dead the
            -- night it was postponed -- sweep it into TONIGHT's classification even
            -- though its scheduled_date was snapped forward to the requested day.
            or (d.current_status = 'postponed' and cl.auto_cancel_soft_fails))
       and d.deleted_at is null
       and d.order_type = 'delivery'   -- waybills/pickups are money-only & terminal; they never roll
       and sd.category <> 'terminal'
       and not exists (
         select 1 from public.deliveries c
          where c.parent_delivery_id = d.id and c.created_via = 'rollover')
  ),
  clustered as (
    -- Sibling clustering for dedup (identical to _find_sibling_deliveries):
    -- same customer + items + day, matched on raw-message text_fingerprint OR
    -- normalized address. sib_cluster = min id over a row's siblings.
    select e.*,
           (select min(e2.id::text)
              from eligible e2
             where e2.customer_phone_normalized = e.customer_phone_normalized
               and e2.item_key       = e.item_key
               and e2.scheduled_date = e.scheduled_date
               and (
                 e2.id = e.id
                 or (e2.text_fingerprint is not null and e2.text_fingerprint = e.text_fingerprint)
                 or (e2.norm_addr       is not null and e2.norm_addr       = e.norm_addr)
               )
           ) as sib_cluster
      from eligible e
  ),
  same_agent_ranked as (
    select c.*,
           row_number() over (
             partition by c.customer_phone_normalized, c.item_key,
                          c.scheduled_date, c.sib_cluster,
                          coalesce(c.assigned_agent_id::text, '!unassigned:' || c.id::text)
             order by c.status_sort desc, c.updated_at desc, c.created_at asc, c.id asc
           ) as same_agent_rn
      from clustered c
  ),
  cross_agent_ranked as (
    select s.*,
           count(*) filter (where s.same_agent_rn = 1)
             over (partition by s.customer_phone_normalized, s.item_key,
                                s.scheduled_date, s.sib_cluster) as group_canonical_count,
           max(s.status_sort) filter (where s.same_agent_rn = 1)
             over (partition by s.customer_phone_normalized, s.item_key,
                                s.scheduled_date, s.sib_cluster) as group_max_sort,
           row_number() over (
             partition by s.customer_phone_normalized, s.item_key,
                          s.scheduled_date, s.sib_cluster
             order by s.status_sort desc, s.updated_at desc, s.created_at asc, s.id asc
           ) as cross_agent_rn
      from same_agent_ranked s
  )
  select
    id            as delivery_id,
    current_status,
    case
      when has_resolved_sibling then 'sibling_resolved'
      when same_agent_rn > 1 then 'dedup_same_agent'
      when group_canonical_count > 1 and cross_agent_rn > 1 then 'dedup_cross_agent'
      when current_status in ('not_around','not_available') then 'close_disinterest'
      when current_status in ('not_answering','not_connecting','number_busy','switched_off','tomorrow','postponed')
           and auto_cancel_soft_fails then 'close_policy'
      when current_status = 'follow_up' then 'close_followup'
      when status_category in ('initial','soft_failure')
           and current_status <> 'no_product'
           and rollover_count >= 1 then 'cap_unserious'
      else 'roll'
    end           as action,
    resolved_sibling_status,
    resolved_sibling_label,
    group_max_sort::int
  from cross_agent_ranked
  order by customer_phone_normalized, item_key, sib_cluster, same_agent_rn, cross_agent_rn;
$$;


--
-- Name: _norm_phone(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._norm_phone(p text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  with stripped as (
    select regexp_replace(coalesce(p, ''), '\D', '', 'g') as digits
  ),
  no_country as (
    select case when digits like '234%' then substring(digits from 4) else digits end as d
    from stripped
  ),
  no_leading_zero as (
    select case when d like '0%' then substring(d from 2) else d end as d
    from no_country
  )
  select nullif(d, '') from no_leading_zero
$$;


--
-- Name: _same_customer_phone_v1(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_phone_v1(p_phone text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    SET search_path TO 'public'
    AS $_$
  with raw as (
    select case when btrim(coalesce(p_phone,'')) ~ '^[+0-9(). -]+$'
      then regexp_replace(p_phone, '[^0-9]', '', 'g') end as digits
  ), subscriber as (
    select case when digits like '00234%' then substring(digits from 6)
      when digits like '234%' then substring(digits from 4)
      when digits like '0%' then substring(digits from 2) else digits end as n
    from raw
  )
  -- A plausible Nigerian mobile number, not proof of identity/reachability.
  select case when n ~ '^[789][0-9]{9}$' then '+234' || n end from subscriber;
$_$;


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id uuid NOT NULL,
    product_catalog_id uuid,
    location_id uuid,
    assigned_agent_id uuid,
    parent_delivery_id uuid,
    customer_name text NOT NULL,
    customer_phone text,
    raw_address text,
    quantity_ordered integer NOT NULL,
    quantity_delivered integer,
    customer_price numeric(10,2) NOT NULL,
    paid numeric(10,2),
    payment_method text,
    charged_snapshot numeric(10,2),
    agent_payment_snapshot numeric(10,2),
    current_status text DEFAULT 'pending'::text NOT NULL,
    created_date date DEFAULT CURRENT_DATE NOT NULL,
    scheduled_date date DEFAULT CURRENT_DATE NOT NULL,
    created_by_user_id uuid,
    created_via text DEFAULT 'bot'::text NOT NULL,
    bot_raw_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    customer_phone_normalized text GENERATED ALWAYS AS (public._norm_phone(customer_phone)) STORED,
    text_fingerprint text,
    rollover_count integer DEFAULT 0 NOT NULL,
    cash_pos_fee_snapshot numeric,
    customer_phone_alt text,
    items_fingerprint text,
    rolled_from_status text,
    rolled_from_date date,
    delivery_instructions text,
    assigned_at timestamp with time zone,
    client_rep text,
    order_type text DEFAULT 'delivery'::text NOT NULL,
    same_customer_phone text GENERATED ALWAYS AS (public._same_customer_phone_v1(customer_phone)) STORED,
    same_customer_phone_alt text GENERATED ALWAYS AS (public._same_customer_phone_v1(customer_phone_alt)) STORED,
    same_customer_key_override uuid,
    same_customer_match_mode text DEFAULT 'auto'::text NOT NULL,
    same_customer_match_revision bigint DEFAULT 0 NOT NULL,
    agent_payment_base_snapshot numeric(10,2),
    agent_payment_base_captured_at timestamp with time zone,
    CONSTRAINT chk_quantity_delivered_when_terminal CHECK (((current_status <> 'delivered'::text) OR (quantity_delivered IS NOT NULL))),
    CONSTRAINT deliveries_agent_payment_snapshot_check CHECK ((agent_payment_snapshot >= (0)::numeric)),
    CONSTRAINT deliveries_charged_snapshot_check CHECK ((charged_snapshot >= (0)::numeric)),
    CONSTRAINT deliveries_created_via_check CHECK ((created_via = ANY (ARRAY['bot'::text, 'manual'::text, 'rollover'::text]))),
    CONSTRAINT deliveries_customer_price_check CHECK ((customer_price >= (0)::numeric)),
    CONSTRAINT deliveries_delivery_requires_fields CHECK (((order_type <> 'delivery'::text) OR ((product_catalog_id IS NOT NULL) AND (customer_phone IS NOT NULL) AND (raw_address IS NOT NULL)))),
    CONSTRAINT deliveries_order_type_check CHECK ((order_type = ANY (ARRAY['delivery'::text, 'waybill'::text, 'replacement'::text]))),
    CONSTRAINT deliveries_paid_check CHECK ((paid >= (0)::numeric)),
    CONSTRAINT deliveries_payment_method_check CHECK ((payment_method = ANY (ARRAY['cash'::text, 'transfer'::text, 'vendor_direct'::text]))),
    CONSTRAINT deliveries_quantity_delivered_check CHECK ((quantity_delivered >= 0)),
    CONSTRAINT deliveries_quantity_ordered_check CHECK ((quantity_ordered > 0)),
    CONSTRAINT deliveries_same_customer_match_mode_check CHECK ((same_customer_match_mode = ANY (ARRAY['auto'::text, 'linked'::text, 'separate'::text])))
);


--
-- Name: TABLE deliveries; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.deliveries IS 'The core delivery record. Money rule: Remit = paid - charged_snapshot. Reda never absorbs underpayment.';


--
-- Name: COLUMN deliveries.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.deliveries.location_id IS 'Null means address could not be normalized (Needs Review queue).';


--
-- Name: COLUMN deliveries.parent_delivery_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.deliveries.parent_delivery_id IS 'For rollovers: points to the original row when this is a retry for tomorrow.';


--
-- Name: COLUMN deliveries.charged_snapshot; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.deliveries.charged_snapshot IS 'Snapshotted from rate_card at creation. Immune to rate changes.';


--
-- Name: COLUMN deliveries.cash_pos_fee_snapshot; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.deliveries.cash_pos_fee_snapshot IS 'POS-to-bank fee Reda incurs converting customer cash. Snapshotted at delivered-time so historical client remits are immutable. NULL on rows delivered before 2026-05-29.';


--
-- Name: COLUMN deliveries.items_fingerprint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.deliveries.items_fingerprint IS 'Stable sha256 of the sorted (product_catalog_id, quantity_ordered) item set. Replaces single product_catalog_id in dedup/sibling/rollover keys (Feature A, Phase 2+).';


--
-- Name: COLUMN deliveries.client_rep; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.deliveries.client_rep IS 'Client''s own sales rep / closer named at the end of the forwarded order (LLM-extracted at intake). Null when the message has no trailing rep name. Used at reconciliation.';


--
-- Name: _find_sibling_deliveries(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._find_sibling_deliveries(p_delivery_id uuid) RETURNS SETOF public.deliveries
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select s.*
    from public.deliveries d
    join public.deliveries s on
         s.id <> d.id
     and s.deleted_at is null
     and s.customer_phone_normalized is not null
     and s.customer_phone_normalized = d.customer_phone_normalized
     and s.items_fingerprint is not null
     and s.items_fingerprint = d.items_fingerprint   -- [Feature A] was product_catalog_id
     and s.scheduled_date = d.scheduled_date
     and (
       -- Tier 1: both sides have a text fingerprint and they agree.
       (d.text_fingerprint is not null and s.text_fingerprint is not null
        and d.text_fingerprint = s.text_fingerprint)
       OR
       -- Tier 2: same normalized address. Phone + item set + date are already
       -- enforced above; quantity is encoded in items_fingerprint, so the old
       -- explicit quantity check is redundant here.
       (public._norm_address(d.raw_address) = public._norm_address(s.raw_address))
     )
   where d.id = p_delivery_id
     and d.customer_phone_normalized is not null
$$;


--
-- Name: _guard_same_customer_identity(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._guard_same_customer_identity() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare v_owner name; v_changed boolean;
begin
  select pg_get_userbyid(relowner) into v_owner from pg_class where oid=TG_RELID;
  if TG_OP='INSERT' then
    v_changed:=new.same_customer_key_override is not null or new.same_customer_match_mode<>'auto'
      or new.same_customer_match_revision<>0;
  else
    v_changed:=(new.same_customer_key_override,new.same_customer_match_mode,new.same_customer_match_revision)
      is distinct from (old.same_customer_key_override,old.same_customer_match_mode,old.same_customer_match_revision);
  end if;
  if v_changed and current_user<>v_owner then
    raise exception 'use the audited customer-match correction action' using errcode='42501';
  end if;
  if TG_OP='UPDATE' and (new.customer_phone,new.customer_phone_alt,new.scheduled_date)
      is distinct from (old.customer_phone,old.customer_phone_alt,old.scheduled_date) then
    new.same_customer_match_revision:=old.same_customer_match_revision+1;
  end if;
  return new;
end $$;


--
-- Name: _guard_same_customer_normal_fee(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._guard_same_customer_normal_fee() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare v_explicit boolean; v_enrolled boolean;
begin
  if TG_OP='INSERT' then
    v_explicit:=new.agent_payment_base_snapshot is not null or new.agent_payment_base_captured_at is not null;
  else
    v_explicit:=(new.agent_payment_base_snapshot,new.agent_payment_base_captured_at)
      is distinct from (old.agent_payment_base_snapshot,old.agent_payment_base_captured_at);
  end if;
  if v_explicit and current_user<>(select pg_get_userbyid(relowner) from pg_class where oid=TG_RELID) then
    raise exception 'normal rider fee must be changed through an authorized correction' using errcode='42501';
  end if;
  if new.order_type<>'delivery' then return new; end if;
  -- Existing unenrolled orders keep legacy rate behavior. Once an earning exists,
  -- payout-only updates cannot overwrite its normal baseline. Explicit normal-rate
  -- writers below set both fields atomically, including a deliberately NULL rate.
  if not v_explicit then
    if TG_OP='INSERT' then
      new.agent_payment_base_snapshot:=new.agent_payment_snapshot;
      new.agent_payment_base_captured_at:=clock_timestamp();
    elsif new.agent_payment_snapshot is distinct from old.agent_payment_snapshot then
      -- Invoker cannot read the private earning table. Use the private definer
      -- adapter to get the baseline without exposing financial records to callers.
      v_enrolled:=public._same_customer_has_earning(new.id);
      if not v_enrolled then
        new.agent_payment_base_snapshot:=new.agent_payment_snapshot;
        new.agent_payment_base_captured_at:=clock_timestamp();
      end if;
    end if;
  end if;
  return new;
end $$;


--
-- Name: _guard_same_customer_settled_delivery(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._guard_same_customer_settled_delivery() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare e public.same_customer_earnings%rowtype;
begin
  if old.current_status<>'delivered' then return new; end if;
  if (old.current_status,old.deleted_at,old.paid,old.charged_snapshot,old.agent_payment_snapshot,old.cash_pos_fee_snapshot,
      old.client_id,old.scheduled_date,old.customer_phone,old.same_customer_key_override,old.agent_payment_base_snapshot)
    is not distinct from
     (new.current_status,new.deleted_at,new.paid,new.charged_snapshot,new.agent_payment_snapshot,new.cash_pos_fee_snapshot,
      new.client_id,new.scheduled_date,new.customer_phone,new.same_customer_key_override,new.agent_payment_base_snapshot) then return new; end if;
  select * into e from public.same_customer_earnings where delivery_id=old.id and policy_applied;
  if found and exists(select 1 from public.settlements where subject_type='agent' and subject_id=e.rider_id
    and period_date=e.accounting_date and voided_at is null) then
    raise exception 'rider period is settled; void the settlement before changing this delivery' using errcode='22023';
  end if;
  return new;
end $$;


--
-- Name: _items_fingerprint(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._items_fingerprint(p_delivery_id uuid) RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select public._items_fingerprint_from_canon(
    string_agg(
      di.product_catalog_id::text || ':' || di.quantity_ordered::text,
      '|' order by di.product_catalog_id
    )
  )
  from public.delivery_items di
  where di.delivery_id = p_delivery_id
$$;


--
-- Name: _items_fingerprint_from_canon(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._items_fingerprint_from_canon(p_canon text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  select case
    when p_canon is null or p_canon = '' then null
    else encode(extensions.digest(p_canon, 'sha256'), 'hex')  -- pgcrypto lives in extensions (matches _text_fingerprint)
  end
$$;


--
-- Name: _lock_same_customer_shadow_for_orders(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._lock_same_customer_shadow_for_orders(p_ids uuid[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_key text;
begin
  for v_key in
    select distinct k from (
      select public._same_customer_pay_lock_key(e.rider_id,e.customer_key,e.business_date) k
        from public.same_customer_earnings e where delivery_id=any(p_ids) and business_date is not null
      union
      select public._same_customer_pay_lock_key(e.rider_id,coalesce('phone:'||d.same_customer_phone,'solo:'||d.id::text),e.business_date)
        from public.same_customer_earnings e join public.deliveries d on d.id=e.delivery_id
        where e.delivery_id=any(p_ids) and e.business_date is not null
    ) keys order by k
  loop perform pg_advisory_xact_lock(hashtextextended(v_key,0)); end loop;
end $$;


--
-- Name: _norm_address(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._norm_address(a text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select nullif(trim(regexp_replace(
    regexp_replace(lower(coalesce(a, '')), '[^a-z0-9 ]+', ' ', 'g'),
    '\s+', ' ', 'g'
  )), '')
$$;


--
-- Name: _notify_admins_carry_cap(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._notify_admins_carry_cap(p_delivery_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_admin record;
  v_customer text;
  v_phone text;
begin
  select coalesce(customer_name, 'a customer'),
         coalesce(customer_phone, '')
    into v_customer, v_phone
    from public.deliveries
   where id = p_delivery_id;

  for v_admin in
    select id from public.users where role = 'admin' and is_active = true
  loop
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'user',
      'user_id',  v_admin.id::text,
      'title',    'Delivery carry-cap hit',
      'body',     v_customer || ' (' || v_phone || ') has rolled twice. '
                  || 'Marked unserious — call the customer or cancel.',
      'data',     jsonb_build_object('route', 'deliveries', 'delivery_id', p_delivery_id)
    ));
  end loop;
end;
$$;


--
-- Name: _notify_admins_eod_summary(date, integer, integer, integer, uuid[], integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._notify_admins_eod_summary(p_for_date date, p_cap_hit_count integer, p_same_agent_count integer, p_race_lost_count integer, p_capped_ids uuid[], p_policy_cancel_count integer DEFAULT 0, p_sibling_resolved_count integer DEFAULT 0) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_admin record;
  v_body text;
  v_data jsonb;
  v_total int := p_cap_hit_count + p_same_agent_count + p_race_lost_count
               + p_policy_cancel_count + p_sibling_resolved_count;
begin
  if v_total = 0 then return; end if;

  v_body :=
    'EOD for ' || p_for_date::text || ': '
    || p_cap_hit_count          || ' carry-capped, '
    || p_same_agent_count       || ' same-agent dupes, '
    || p_race_lost_count        || ' race losers, '
    || p_policy_cancel_count    || ' client-policy cancels, '
    || p_sibling_resolved_count || ' sibling-resolved skips — review unserious.';

  v_data := jsonb_build_object(
    'route',                   'deliveries',
    'for_date',                p_for_date,
    'cap_hit_count',           p_cap_hit_count,
    'same_agent_count',        p_same_agent_count,
    'race_lost_count',         p_race_lost_count,
    'policy_cancel_count',     p_policy_cancel_count,
    'sibling_resolved_count',  p_sibling_resolved_count,
    'capped_ids',              coalesce(to_jsonb(p_capped_ids), '[]'::jsonb)
  );

  for v_admin in
    select id from public.users where role = 'admin' and is_active = true
  loop
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'user',
      'user_id',  v_admin.id::text,
      'title',    'EOD rollover summary',
      'body',     v_body,
      'data',     v_data
    ));
  end loop;
end;
$$;


--
-- Name: _open_sibling_agents(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._open_sibling_agents(p_delivery_id uuid) RETURNS TABLE(agent_id uuid)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select distinct s.assigned_agent_id
    from public._find_sibling_deliveries(p_delivery_id) s
    join public.delivery_status_defs sd on sd.status = s.current_status
   where s.assigned_agent_id is not null
     and sd.category <> 'terminal'
$$;


--
-- Name: _product_deactivation_blockers(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._product_deactivation_blockers(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  with agent_stock as (
    select u.id as holder_id, u.display_name, cs.quantity_on_hand::int as qty
      from public.current_stock cs
      join public.users u on u.id = cs.agent_id
     where cs.product_catalog_id = p_id
       -- > 0, not <> 0: current_stock keeps rows for any non-zero balance, so
       -- a rider sitting at -2 would otherwise register as a blocker.
       and cs.quantity_on_hand > 0
       and u.role = 'agent'
  ),
  wh_stock as (
    select coalesce(sum(cs.quantity_on_hand), 0)::int as qty
      from public.current_stock cs
      join public.users u on u.id = cs.agent_id
     where cs.product_catalog_id = p_id
       and cs.quantity_on_hand > 0
       -- a warehouse PLACE holds stock; warehouse STAFF (warehouse_id set)
       -- never do, and must land in neither bucket.
       and u.role = 'warehouse'
       and u.warehouse_id is null
  ),
  open_d as (
    select d.id, d.current_status
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
     where d.deleted_at is null
       -- category, not a hardcoded status list: delivery_status_defs is the
       -- server-side authority and statuses have been reclassified before
       -- (not_around became terminal; no_product went back to soft_failure).
       and sd.category <> 'terminal'
       -- deliveries reference products two ways since multi-product shipped.
       -- Checking only the legacy column would have missed the live Perfume
       -- case, whose only reference is a delivery_items row.
       and (d.product_catalog_id = p_id
            or exists (select 1 from public.delivery_items di
                        where di.delivery_id = d.id
                          and di.product_catalog_id = p_id))
  )
  select jsonb_build_object(
    'code',            'product_deactivation_blocked',
    'product_id',      p_id,
    'agent_stock',     coalesce((select jsonb_agg(jsonb_build_object(
                                          'holder_id',   holder_id,
                                          'holder_name', display_name,
                                          'quantity',    qty)
                                        order by display_name)
                                   from agent_stock), '[]'::jsonb),
    'agent_units',     coalesce((select sum(qty) from agent_stock), 0),
    'warehouse_units', (select qty from wh_stock),
    'open_deliveries', (select count(*)::int from open_d),
    'open_statuses',   coalesce((select jsonb_agg(distinct current_status) from open_d), '[]'::jsonb)
  );
$$;


--
-- Name: FUNCTION _product_deactivation_blockers(p_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public._product_deactivation_blockers(p_id uuid) IS 'Internal. Deactivation blockers for one product: agent-held units and open non-terminal deliveries block; warehouse-held units are reported but never block. Not granted to anyone -- reach it through product_deactivation_blockers() or the guard.';


--
-- Name: _project_same_customer_pay(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._project_same_customer_pay(p_delivery_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare e public.same_customer_earnings%rowtype; d public.deliveries%rowtype;
  v_group uuid; v_ids uuid[]; v_id uuid; v_enabled boolean; v_amount numeric; v_state text; v_reason text;
  v_conflict boolean;
begin
  select group_id into v_group from public.same_customer_earnings where delivery_id=p_delivery_id;
  if not found then return; end if;
  insert into public.same_customer_projection_context values(pg_backend_pid(),txid_current()) on conflict do nothing;
  if not found then return; end if;
  select array_agg(delivery_id order by delivery_id) into v_ids from public.same_customer_earnings
    where delivery_id=p_delivery_id or (group_id=v_group and active);
  perform public._same_customer_lock_orders(v_ids,'{}'::uuid[],false);
  foreach v_id in array v_ids loop
    select * into strict e from public.same_customer_earnings where delivery_id=v_id;
    select * into strict d from public.deliveries where id=v_id;
    -- History is inserted before the operational row changes. Project only once
    -- their states agree; never let a payout UPDATE undo an in-flight completion.
    if (e.active and (d.current_status<>'delivered' or d.deleted_at is not null))
      or (not e.active and d.current_status='delivered' and d.deleted_at is null) then continue; end if;
    v_enabled:=case when e.business_date is not null then public._same_customer_policy_for_day(e.business_date)
      else public._same_customer_policy_candidate(e.occurred_at,e.recorded_at) end;
    if not v_enabled and not e.policy_applied and e.final_state<>'legacy' then continue; end if;
    v_reason:=null;
    if not v_enabled then
      v_state:='legacy'; v_amount:=coalesce(e.manual_amount,e.base_fee,e.legacy_amount);
    elsif not e.active then
      v_state:='reversed'; v_amount:=null;
    elsif e.pay_state='ready' then
      v_state:='ready'; v_amount:=e.expected_amount;
    else
      v_state:='pending'; v_amount:=null; v_reason:=e.review_reason;
    end if;
    update public.same_customer_earnings set policy_applied=v_enabled,
      legacy_amount=coalesce(legacy_amount,d.agent_payment_snapshot),final_amount=v_amount,
      final_state=v_state,final_review_reason=v_reason,revision=revision+1,updated_at=clock_timestamp()
    where delivery_id=v_id and (policy_applied,final_amount,final_state,final_review_reason)
      is distinct from (v_enabled,v_amount,v_state,v_reason);
  end loop;
  -- Frozen amounts are read from the immutable settlement snapshot, not from a
  -- mutable delivery row. Missing entries identify activity after handover.
  select exists(
    select 1 from public.same_customer_earnings x join public.deliveries dx on dx.id=x.delivery_id
    join public.settlements s on s.subject_type='agent' and s.subject_id=x.rider_id
      and s.period_date=x.accounting_date and s.voided_at is null
    left join lateral (select j.value from jsonb_array_elements(s.snapshot->'by_delivery') j
      where j.value->>'delivery_id'=x.delivery_id::text and coalesce(j.value->>'entry_type','delivery')='delivery' limit 1) frozen on true
    where x.delivery_id=any(v_ids) and x.active and x.policy_applied and dx.current_status='delivered' and dx.deleted_at is null
      and (frozen.value is null or (x.final_amount is not null and x.final_amount is distinct from (frozen.value->>'agent_payment')::numeric))
  ) into v_conflict;
  if v_conflict then
    update public.same_customer_earnings set final_state='pending',final_amount=null,
      final_review_reason='settled_period_conflict',revision=revision+1,updated_at=clock_timestamp()
    where delivery_id=any(v_ids) and active and policy_applied
      and (final_state,final_amount,final_review_reason) is distinct from ('pending'::text,null::numeric,'settled_period_conflict'::text);
  end if;
  update public.deliveries dx set agent_payment_snapshot=case when x.final_state='reversed' then x.base_fee else x.final_amount end
    from public.same_customer_earnings x where x.delivery_id=dx.id and x.delivery_id=any(v_ids)
      and x.final_state in ('ready','legacy','reversed')
      and ((x.active and dx.current_status='delivered' and dx.deleted_at is null)
        or (not x.active and (dx.current_status<>'delivered' or dx.deleted_at is not null)))
      and dx.agent_payment_snapshot is distinct from case when x.final_state='reversed' then x.base_fee else x.final_amount end;
  delete from public.same_customer_projection_context where backend_pid=pg_backend_pid() and transaction_id=txid_current();
end $$;


--
-- Name: _recalculate_customer_day_pay(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._recalculate_customer_day_pay(p_group_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare g public.same_customer_pay_groups%rowtype; v_state text; v_signature text;
begin
  if p_group_id is null then return; end if;
  select * into strict g from public.same_customer_pay_groups where id=p_group_id;
  perform public._same_customer_lock_orders(array(select delivery_id from public.same_customer_earnings where group_id=p_group_id and active),array[g.rider_id],false);
  perform pg_advisory_xact_lock(hashtextextended(public._same_customer_pay_lock_key(g.rider_id,g.customer_key,g.business_date),0));
  select * into strict g from public.same_customer_pay_groups where id=p_group_id for update;
  v_signature:=public._same_customer_manual_signature(p_group_id);
  select case
    when count(*) filter(where base_fee is null or base_fee<0 or base_fee::text in ('NaN','Infinity','-Infinity'))>0 or count(distinct base_fee)>1 then 'rate_mismatch'
    when ((count(*) filter(where manual_amount is not null)>0 and count(*)>1)
       or count(*) filter(where manual_amount is not null and manual_event_review)>0)
       and g.manual_review_signature is distinct from v_signature then 'manual_review'
    else 'ready' end into v_state
  from public.same_customer_earnings where group_id=p_group_id and active;
  with ranked as (
    select delivery_id,row_number() over(order by recorded_at,completion_event_id,delivery_id) as position
      from public.same_customer_earnings where group_id=p_group_id and active
  ), calculation as (
    select e.delivery_id,
      case when v_state='ready' then case when r.position=1 then 1::numeric else 0.5::numeric end end as factor,
      case when v_state='ready' then coalesce(e.manual_amount,round(e.base_fee*case when r.position=1 then 1 else 0.5 end,2)) end as amount,
      case when v_state='ready' then 'ready' else 'pending' end as state,
      case when v_state<>'ready' then v_state end as reason
    from ranked r join public.same_customer_earnings e using(delivery_id)
  )
  update public.same_customer_earnings e set multiplier=c.factor,expected_amount=c.amount,
    pay_state=c.state,review_reason=c.reason,revision=e.revision+1,updated_at=clock_timestamp()
  from calculation c where e.delivery_id=c.delivery_id
    and (e.multiplier,e.expected_amount,e.pay_state,e.review_reason) is distinct from (c.factor,c.amount,c.state,c.reason);
  update public.same_customer_pay_groups set state=v_state,revision=revision+1,updated_at=clock_timestamp() where id=p_group_id;
  perform public._project_same_customer_pay((select delivery_id from public.same_customer_earnings where group_id=p_group_id order by active desc,delivery_id limit 1));
end $$;


--
-- Name: _refresh_same_customer_pay_period(uuid, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._refresh_same_customer_pay_period(p_rider uuid, p_day date) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$ declare v_id uuid; begin
  for v_id in select min(delivery_id::text)::uuid from public.same_customer_earnings
    where rider_id=p_rider and accounting_date=p_day and active group by coalesce(group_id,delivery_id) loop
    perform public._project_same_customer_pay(v_id);
  end loop;
end $$;


--
-- Name: _same_customer_attempt_financial_lock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_attempt_financial_lock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_keys text[]:='{}'; v_id uuid; v_client uuid;
begin
  if TG_OP<>'INSERT' then
    select client_id into v_client from public.deliveries where id=old.delivery_id;
    v_keys:=v_keys||array['agent:'||old.assigned_agent_id::text,
      'client:'||v_client::text||':'||(old.attempted_at at time zone 'Africa/Lagos')::date::text];
    v_id:=old.delivery_id;
  end if;
  if TG_OP<>'DELETE' then
    select client_id into v_client from public.deliveries where id=new.delivery_id;
    v_keys:=v_keys||array['agent:'||new.assigned_agent_id::text,
      'client:'||v_client::text||':'||(new.attempted_at at time zone 'Africa/Lagos')::date::text];
    v_id:=new.delivery_id;
  end if;
  perform public._same_customer_lock_financial_keys(v_keys||public._same_customer_financial_keys(array[v_id]),false);
  if TG_OP='DELETE' then return old; end if;
  return new;
end $$;


--
-- Name: _same_customer_day_groups(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_day_groups(p_day date) RETURNS TABLE(group_id text, match_kind text, delivery_ids uuid[])
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  with orders as materialized (select * from public._same_customer_day_orders(p_day)),
  primary_groups as (
    select md5(p_day::text || '|' || customer_key) as group_id,
      case when bool_or(match_mode='linked') then 'linked' else 'primary' end as match_kind,
      array_agg(delivery_id order by delivery_id) as delivery_ids
    from orders group by customer_key having count(*)>1
  ), contacts as (
    select delivery_id,phone from orders where phone is not null
    union
    select delivery_id,phone_alt from orders where phone_alt is not null
  ), alternate_pairs as (
    select distinct a.delivery_id as a_id,b.delivery_id as b_id
    from contacts ca join contacts cb on ca.phone=cb.phone and ca.delivery_id<cb.delivery_id
    join orders a on a.delivery_id=ca.delivery_id join orders b on b.delivery_id=cb.delivery_id
    where a.customer_key<>b.customer_key
      and (ca.phone=a.phone_alt or ca.phone=b.phone_alt)
      and a.match_mode<>'separate' and b.match_mode<>'separate'
      and not (a.match_mode='linked' and b.match_mode='linked')
  )
  select * from primary_groups
  union all
  select md5(p_day::text || '|alternate|' || a_id::text || '|' || b_id::text),
    'alternate',array[a_id,b_id] from alternate_pairs;
$$;


--
-- Name: _same_customer_day_orders(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_day_orders(p_day date) RETURNS TABLE(delivery_id uuid, customer_key text, phone text, phone_alt text, match_mode text, customer_name text, raw_address text, client_id uuid, agent_id uuid, current_status text, revision bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  with recursive candidates as materialized (
    select d.*, public._same_customer_key(d) as customer_key
    from public.deliveries d join public.delivery_status_defs s on s.status=d.current_status
    where d.scheduled_date=p_day and d.deleted_at is null and d.order_type='delivery'
      and (s.category<>'terminal' or d.current_status='delivered')
  ), edges as materialized (
    -- Mirror the live sibling predicate, including matching forwarded text.
    -- Identity corrections do not turn race copies into extra payable orders.
    select a.id as a_id,b.id as b_id from candidates a join candidates b
      on a.id<>b.id and a.customer_phone_normalized=b.customer_phone_normalized
      and a.items_fingerprint=b.items_fingerprint
      and (a.text_fingerprint=b.text_fingerprint
        or public._norm_address(a.raw_address)=public._norm_address(b.raw_address))
  ), reachable(origin_id,member_id) as (
    select id,id from candidates
    union
    select r.origin_id,e.b_id from reachable r join edges e on e.a_id=r.member_id
  ), components as (
    select member_id,min(origin_id::text) as logical_key from reachable group by member_id
  ), ranked as (
    select c.*,row_number() over(partition by k.logical_key
      order by (current_status='delivered') desc,created_at,id) as copy_rank
    from candidates c join components k on k.member_id=c.id
  )
  select id,customer_key,same_customer_phone,same_customer_phone_alt,same_customer_match_mode,
    customer_name,raw_address,client_id,assigned_agent_id,current_status,same_customer_match_revision
  from ranked where copy_rank=1;
$$;


--
-- Name: _same_customer_delivery_financial_lock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_delivery_financial_lock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_keys text[]; v_ids uuid[];
begin
  if TG_OP='INSERT' then
    v_ids:=array[new.id];
    v_keys:=array['agent:'||new.assigned_agent_id::text,'client:'||new.client_id::text||':'||new.scheduled_date::text];
  elsif TG_OP='DELETE' then
    v_ids:=array[old.id];
    v_keys:=array['agent:'||old.assigned_agent_id::text,'client:'||old.client_id::text||':'||old.scheduled_date::text];
  else
    if (new.assigned_agent_id,new.client_id,new.scheduled_date,new.current_status,new.deleted_at,new.paid,
        new.agent_payment_snapshot,new.charged_snapshot,new.cash_pos_fee_snapshot,new.customer_phone,
        new.same_customer_key_override,new.agent_payment_base_snapshot,new.agent_payment_base_captured_at)
      is not distinct from
       (old.assigned_agent_id,old.client_id,old.scheduled_date,old.current_status,old.deleted_at,old.paid,
        old.agent_payment_snapshot,old.charged_snapshot,old.cash_pos_fee_snapshot,old.customer_phone,
        old.same_customer_key_override,old.agent_payment_base_snapshot,old.agent_payment_base_captured_at) then return new; end if;
    v_ids:=array[new.id];
    v_keys:=array['agent:'||old.assigned_agent_id::text,'agent:'||new.assigned_agent_id::text,
      'client:'||old.client_id::text||':'||old.scheduled_date::text,'client:'||new.client_id::text||':'||new.scheduled_date::text];
  end if;
  perform public._same_customer_lock_financial_keys(v_keys||public._same_customer_financial_keys(v_ids),false);
  if TG_OP='DELETE' then return old; end if;
  return new;
end $$;


--
-- Name: _same_customer_earning_audit(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_earning_audit() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  insert into public.same_customer_earning_revisions(delivery_id,actor_id,old_value,new_value)
    values(new.delivery_id,auth.uid(),case when TG_OP='UPDATE' then to_jsonb(old) end,to_jsonb(new));
  return new;
end $$;


--
-- Name: _same_customer_final_accounting_date(public.deliveries); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_final_accounting_date(d public.deliveries) RETURNS date
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce((select accounting_date from public.same_customer_earnings where delivery_id=d.id and policy_applied),d.scheduled_date)
$$;


--
-- Name: _same_customer_final_rider(public.deliveries); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_final_rider(d public.deliveries) RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce((select rider_id from public.same_customer_earnings where delivery_id=d.id and policy_applied),d.assigned_agent_id)
$$;


--
-- Name: _same_customer_financial_keys(uuid[], uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_financial_keys(p_ids uuid[], p_extra_agents uuid[] DEFAULT '{}'::uuid[]) RETURNS text[]
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce(array_agg(distinct k order by k) filter(where k is not null),'{}'::text[]) from (
    select 'agent:'||assigned_agent_id::text k from public.deliveries where id=any(p_ids)
    union all select 'agent:'||rider_id::text from public.same_customer_earnings where delivery_id=any(p_ids)
    union all select 'agent:'||x::text from unnest(p_extra_agents) x
    union all select 'client:'||client_id::text||':'||scheduled_date::text from public.deliveries where id=any(p_ids)
    union all select 'client:'||client_id::text||':'||(clock_timestamp() at time zone 'Africa/Lagos')::date::text
      from public.deliveries where id=any(p_ids)
    union all select 'agent:'||a.assigned_agent_id::text from public.replacement_attempts a where a.delivery_id=any(p_ids)
    union all select 'client:'||d.client_id::text||':'||(a.attempted_at at time zone 'Africa/Lagos')::date::text
      from public.replacement_attempts a join public.deliveries d on d.id=a.delivery_id where a.delivery_id=any(p_ids)
  ) keys
$$;


--
-- Name: _same_customer_financial_rows(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_financial_rows(p_from date, p_to date) RETURNS TABLE(delivery_id uuid, rider_id uuid, accounting_date date, quantity numeric, paid numeric, amount numeric, pay_state text, pay_reason text, business_date date, multiplier numeric, manual boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select d.id,d.assigned_agent_id,d.scheduled_date,d.quantity_delivered,d.paid,
    coalesce(d.agent_payment_snapshot,0),'legacy'::text,null::text,null::date,null::numeric,false
  from public.deliveries d
  where d.current_status='delivered' and d.deleted_at is null and d.scheduled_date between p_from and p_to
    and not exists(select 1 from public.same_customer_earnings e where e.delivery_id=d.id and e.policy_applied)
  union all
  select e.delivery_id,e.rider_id,e.accounting_date,d.quantity_delivered,d.paid,
    case when e.final_state='ready' then e.final_amount end,
    case when e.final_state='ready' and e.final_amount is not null then 'ready' else 'pending' end,
    e.final_review_reason,e.business_date,e.multiplier,e.manual_amount is not null
  from public.same_customer_earnings e join public.deliveries d on d.id=e.delivery_id
  where e.policy_applied and e.active and e.accounting_date between p_from and p_to
    and d.current_status='delivered' and d.deleted_at is null
$$;


--
-- Name: _same_customer_has_earning(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_has_earning(p_id uuid) RETURNS boolean
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if pg_trigger_depth()=0 then raise exception 'trigger-only helper' using errcode='42501'; end if;
  return exists(select 1 from public.same_customer_earnings where delivery_id=p_id);
end
$$;


--
-- Name: _same_customer_key(public.deliveries); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_key(p_delivery public.deliveries) RETURNS text
    LANGUAGE sql IMMUTABLE
    SET search_path TO 'public'
    AS $$ select case when p_delivery.same_customer_key_override is not null
    then 'override:' || p_delivery.same_customer_key_override::text
    when p_delivery.same_customer_phone is not null then 'phone:' || p_delivery.same_customer_phone
    else 'solo:' || p_delivery.id::text end $$;


--
-- Name: _same_customer_lock_financial_keys(text[], boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_lock_financial_keys(p_keys text[], p_wait boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'pg_catalog'
    AS $$
declare v_key text; v_nested boolean;
begin
  -- A nested operation may discover another subject after taking row/group locks.
  -- Never wait for a new outer lock in that case: roll back with a retryable error.
  select exists(select 1 from pg_locks where pid=pg_backend_pid() and locktype='advisory' and granted) into v_nested;
  for v_key in select distinct k from unnest(p_keys) k where k is not null order by k loop
    if p_wait and not v_nested then
      perform pg_advisory_xact_lock(hashtextextended('same-customer-finance:v1:'||v_key,0));
    elsif not pg_try_advisory_xact_lock(hashtextextended('same-customer-finance:v1:'||v_key,0)) then
      raise exception 'financial records changed concurrently; retry this operation' using errcode='40001';
    end if;
  end loop;
end $$;


--
-- Name: _same_customer_lock_orders(uuid[], uuid[], boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_lock_orders(p_ids uuid[], p_extra_agents uuid[] DEFAULT '{}'::uuid[], p_wait boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$ begin
  perform public._same_customer_lock_financial_keys(public._same_customer_financial_keys(p_ids,p_extra_agents),p_wait);
end $$;


--
-- Name: _same_customer_manual_signature(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_manual_signature(p_group uuid) RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select md5(coalesce(jsonb_agg(jsonb_build_array(delivery_id,completion_event_id,rider_id,customer_key,business_date,
    base_fee,manual_decision_id,manual_amount,manual_event_review) order by delivery_id),'[]'::jsonb)::text)
  from public.same_customer_earnings where group_id=p_group and active
$$;


--
-- Name: _same_customer_normal_fee(public.deliveries); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_normal_fee(d public.deliveries) RETURNS numeric
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select case when d.agent_payment_base_captured_at is not null then d.agent_payment_base_snapshot
    when e.delivery_id is not null then e.base_fee else d.agent_payment_snapshot end
  from (select 1) anchor left join public.same_customer_earnings e on e.delivery_id=d.id
$$;


--
-- Name: _same_customer_pay_lock_key(uuid, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_pay_lock_key(p_rider uuid, p_customer text, p_day date) RETURNS text
    LANGUAGE sql IMMUTABLE
    SET search_path TO 'public'
    AS $$
  select 'same-customer-pay:v1:'||p_rider::text||':'||p_day::text||':'||p_customer
$$;


--
-- Name: _same_customer_policy_candidate(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_policy_candidate(p_occurred timestamp with time zone, p_received timestamp with time zone) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if public._same_customer_policy_for_day((p_received at time zone 'Africa/Lagos')::date) then return true; end if;
  if p_occurred is not null and p_occurred<=p_received
    and public._same_customer_policy_for_day((p_occurred at time zone 'Africa/Lagos')::date) then return true; end if;
  -- A legacy request after policy suspension may describe an offline completion
  -- inside the active window. It needs a date before it can be priced as legacy.
  return p_occurred is null and (
    exists(select 1 from public.same_customer_pay_policy where active_from is not null
      and active_from<=(p_received at time zone 'Africa/Lagos')::date)
    or exists(select 1 from public.same_customer_pay_policy_days where enabled and business_date<=(p_received at time zone 'Africa/Lagos')::date));
end $$;


--
-- Name: _same_customer_policy_for_day(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_policy_for_day(p_day date) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_enabled boolean; p public.same_customer_pay_policy%rowtype;
begin
  if p_day is null then return false; end if;
  select enabled into v_enabled from public.same_customer_pay_policy_days where business_date=p_day;
  if found then return v_enabled; end if;
  select * into p from public.same_customer_pay_policy where singleton;
  if p.active_from is null then return false; end if;
  v_enabled:=p_day>=p.active_from and (p.inactive_from is null or p_day<p.inactive_from);
  insert into public.same_customer_pay_policy_days(business_date,enabled) values(p_day,v_enabled) on conflict do nothing;
  select enabled into strict v_enabled from public.same_customer_pay_policy_days where business_date=p_day;
  return v_enabled;
end $$;


--
-- Name: _same_customer_record_manual_fee(uuid, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_record_manual_fee(p_id uuid, p_amount numeric, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare d public.deliveries%rowtype;
begin
  select * into strict d from public.deliveries where id=p_id;
  if not public._same_customer_track_manual_fee(d) then return; end if;
  if p_amount is null or p_amount<0 or p_amount::text in ('NaN','Infinity','-Infinity') then
    raise exception 'manual rider fee must be a finite non-negative amount' using errcode='22023';
  end if;
  if exists(select 1 from public.same_customer_earnings e join public.settlements s
    on s.subject_type='agent' and s.subject_id=e.rider_id and s.period_date=e.accounting_date and s.voided_at is null
    where e.delivery_id=p_id and e.active) then
    raise exception 'cannot change the agent payout: the successful rider period is already settled' using errcode='23505';
  end if;
  insert into public.same_customer_fee_decisions(delivery_id,amount,reason,actor_id,source)
    values(p_id,round(p_amount,2),btrim(p_reason),auth.uid(),'charge_correction');
end $$;


--
-- Name: _same_customer_settlement_financial_lock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_settlement_financial_lock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare v_keys text[]:='{}';
begin
  if TG_OP<>'INSERT' then
    v_keys:=v_keys||array[case when old.subject_type='agent' then 'agent:'||old.subject_id::text
      else 'client:'||old.subject_id::text||':'||old.period_date::text end];
  end if;
  if TG_OP<>'DELETE' then
    v_keys:=v_keys||array[case when new.subject_type='agent' then 'agent:'||new.subject_id::text
      else 'client:'||new.subject_id::text||':'||new.period_date::text end];
  end if;
  perform public._same_customer_lock_financial_keys(v_keys,false);
  if TG_OP='DELETE' then return old; end if;
  -- Voiding must remain possible when late activity has made pay pending.
  -- Client settlements and pre-policy/shadow periods retain their existing rules.
  if new.subject_type='agent' and new.voided_at is null and exists(
    select 1 from public.same_customer_earnings where rider_id=new.subject_id
      and accounting_date=new.period_date and policy_applied and active
  ) then
    perform public._assert_same_customer_settlement_ready(new.subject_type,new.subject_id,new.period_date);
  end if;
  return new;
end $$;


--
-- Name: _same_customer_shadow_delivery(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_shadow_delivery() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ begin
  -- The existing status RPC inserts history BEFORE writing its final scheduled
  -- date. Postponed completions move to today, so finalize the accounting snapshot
  -- from the resulting row in the same transaction, never from the old schedule.
  if old.current_status<>'delivered' and new.current_status='delivered' then
    update public.same_customer_earnings set accounting_date=new.scheduled_date,
      revision=revision+1,updated_at=clock_timestamp()
    where delivery_id=new.id and active and accounting_date is distinct from new.scheduled_date;
  end if;
  perform public._sync_same_customer_shadow(new.id); perform public._project_same_customer_pay(new.id); return new;
end $$;


--
-- Name: _same_customer_shadow_history(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_shadow_history() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ begin
  perform public._sync_same_customer_shadow(new.delivery_id,new.id); return new;
end $$;


--
-- Name: _same_customer_track_manual_fee(public.deliveries); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._same_customer_track_manual_fee(d public.deliveries) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select d.order_type='delivery' and (
    coalesce((select enabled from public.feature_flags where key='same_customer_pay_shadow'),false)
    or exists(select 1 from public.same_customer_earnings where delivery_id=d.id)
    -- A later offline request may establish that the completion happened inside
    -- an earlier active window. Preserve explicit corrections after suspension.
    or exists(select 1 from public.same_customer_pay_policy where active_from is not null
      and active_from<=(clock_timestamp() at time zone 'Africa/Lagos')::date)
    or exists(select 1 from public.same_customer_pay_policy_days where enabled
      and business_date<=(clock_timestamp() at time zone 'Africa/Lagos')::date))
$$;


--
-- Name: _sync_same_customer_shadow(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._sync_same_customer_shadow(p_delivery_id uuid, p_event_id uuid DEFAULT NULL::uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  d public.deliveries%rowtype; e public.same_customer_earnings%rowtype;
  h public.delivery_status_history%rowtype; v_exists boolean; v_changed integer;
  v_rider uuid; v_customer text; v_day date; v_accounting date; v_active boolean;
  v_occurred timestamptz; v_recorded timestamptz; v_event uuid; v_date_reason text;
  v_manual public.same_customer_fee_decisions%rowtype; v_manual_event_review boolean; v_old_group uuid; v_new_group uuid; v_lock text; v_old_lock text; v_new_lock text;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[],false);
  select * into d from public.deliveries where id=p_delivery_id;
  if not found or d.order_type<>'delivery' then return; end if;
  select * into e from public.same_customer_earnings where delivery_id=p_delivery_id;
  v_exists:=found;
  if p_event_id is not null then
    select * into strict h from public.delivery_status_history where id=p_event_id and delivery_id=p_delivery_id;
    if h.to_status='delivered' then
      if not v_exists and not coalesce((select enabled from public.feature_flags where key='same_customer_pay_shadow'),false) and not public._same_customer_policy_candidate(h.reported_occurred_at,clock_timestamp()) then return; end if;
      if d.assigned_agent_id is null then return; end if;
      if v_exists and e.completion_event_id=h.id then return; end if;
      v_rider:=d.assigned_agent_id; v_accounting:=d.scheduled_date;
      v_recorded:=clock_timestamp(); v_occurred:=h.reported_occurred_at; v_event:=h.id; v_active:=true;
      v_day:=(v_recorded at time zone 'Africa/Lagos')::date;
      v_date_reason:=case when v_occurred is null then 'missing_occurrence'
        when v_occurred>v_recorded+interval '5 minutes' then 'clock_skew'
        when (v_occurred at time zone 'Africa/Lagos')::date<>v_day then 'date_discrepancy' end;
      if v_date_reason is not null then v_day:=null; end if;
    elsif h.from_status='delivered' and v_exists then
      v_active:=false;
    else return; end if;
  elsif not v_exists then return;
  else v_active:=d.current_status='delivered' and d.deleted_at is null;
  end if;
  if v_rider is null then
    v_rider:=e.rider_id; v_accounting:=e.accounting_date; v_day:=e.business_date;
    v_recorded:=e.recorded_at; v_occurred:=e.occurred_at; v_event:=e.completion_event_id;
    v_date_reason:=e.date_review_reason;
  end if;
  select * into v_manual from public.same_customer_fee_decisions where delivery_id=p_delivery_id order by id desc limit 1;
  v_manual_event_review:=v_manual.amount is not null and v_exists and e.manual_decision_id=v_manual.id
    and (e.manual_event_review or e.completion_event_id is distinct from v_event
      or e.customer_key is distinct from public._same_customer_key(d) or e.business_date is distinct from v_day or e.rider_id is distinct from v_rider);
  v_customer:=public._same_customer_key(d);
  v_old_group:=e.group_id;
  if v_exists and e.business_date is not null then
    v_old_lock:=public._same_customer_pay_lock_key(e.rider_id,e.customer_key,e.business_date); end if;
  if v_day is not null then v_new_lock:=public._same_customer_pay_lock_key(v_rider,v_customer,v_day); end if;
  for v_lock in select distinct x from unnest(array[v_old_lock,v_new_lock]) x where x is not null order by x loop
    perform pg_advisory_xact_lock(hashtextextended(v_lock,0));
  end loop;
  if v_day is not null then
    insert into public.same_customer_pay_groups(rider_id,customer_key,business_date)
      values(v_rider,v_customer,v_day) on conflict(rider_id,customer_key,business_date,policy_version) do nothing;
    select id into strict v_new_group from public.same_customer_pay_groups
      where rider_id=v_rider and customer_key=v_customer and business_date=v_day and policy_version=1;
  end if;
  insert into public.same_customer_earnings(delivery_id,completion_event_id,rider_id,customer_key,
    recorded_at,occurred_at,business_date,accounting_date,base_fee,group_id,active,date_review_reason,pay_state,review_reason,manual_amount,manual_reason,manual_decision_id,manual_event_review)
  values(d.id,v_event,v_rider,v_customer,v_recorded,v_occurred,v_day,v_accounting,public._same_customer_normal_fee(d),
    v_new_group,v_active,v_date_reason,case when v_active then 'pending' else 'reversed' end,v_date_reason,v_manual.amount,case when v_manual.amount is not null then v_manual.reason end,v_manual.id,coalesce(v_manual_event_review,false))
  on conflict(delivery_id) do update set completion_event_id=excluded.completion_event_id,
    rider_id=excluded.rider_id,customer_key=excluded.customer_key,recorded_at=excluded.recorded_at,
    occurred_at=excluded.occurred_at,business_date=excluded.business_date,accounting_date=excluded.accounting_date,
    manual_amount=excluded.manual_amount,manual_reason=excluded.manual_reason,manual_decision_id=excluded.manual_decision_id,manual_event_review=excluded.manual_event_review,
    base_fee=excluded.base_fee,group_id=excluded.group_id,active=excluded.active,date_review_reason=excluded.date_review_reason,
    pay_state=excluded.pay_state,review_reason=excluded.review_reason,multiplier=null,expected_amount=null,
    revision=same_customer_earnings.revision+1,updated_at=clock_timestamp()
  where (same_customer_earnings.completion_event_id,same_customer_earnings.customer_key,same_customer_earnings.base_fee,
    same_customer_earnings.active,same_customer_earnings.business_date,same_customer_earnings.manual_decision_id,same_customer_earnings.manual_event_review)
    is distinct from (excluded.completion_event_id,excluded.customer_key,excluded.base_fee,excluded.active,excluded.business_date,excluded.manual_decision_id,excluded.manual_event_review);
  get diagnostics v_changed = row_count;
  if v_changed=0 then return; end if;
  perform public._recalculate_customer_day_pay(v_old_group);
  if v_new_group is distinct from v_old_group then perform public._recalculate_customer_day_pay(v_new_group); end if;
  perform public._project_same_customer_pay(p_delivery_id);
end $$;


--
-- Name: _text_fingerprint(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._text_fingerprint(p_text text) RETURNS text
    LANGUAGE sql IMMUTABLE PARALLEL SAFE
    AS $$
  select case
    when p_text is null or btrim(p_text) = '' then null
    else encode(
      extensions.digest(
        regexp_replace(
          regexp_replace(
            lower(btrim(p_text)),
            '\s*lagos area:\s*\S+\s*', ' ', 'gi'
          ),
          '\s+', ' ', 'g'
        ),
        'sha256'
      ),
      'hex'
    )
  end
$$;


--
-- Name: _validate_replacement_payment(numeric, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._validate_replacement_payment(p_customer_paid numeric, p_payment_method text, p_payment_received_by text) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$
begin
  if p_customer_paid is null or p_customer_paid < 0 or p_customer_paid >= 'Infinity'::numeric then
    raise exception 'Enter a valid customer payment' using errcode = '23514';
  end if;
  if p_customer_paid > 0 then
    if p_payment_method is null or p_payment_method not in ('cash', 'transfer') then
      raise exception 'Payment method must be cash or transfer when the customer paid' using errcode = '23514';
    end if;
    if p_payment_received_by is null or p_payment_received_by not in ('rider', 'reda') then
      raise exception 'Say who received the money: the rider or REDA directly' using errcode = '23514';
    end if;
    return case when p_payment_method = 'cash' then 500 else 0 end;
  end if;
  if p_payment_method is not null and p_payment_method <> 'vendor_direct' then
    raise exception 'With no payment to REDA the method can only be "to vendor"' using errcode = '23514';
  end if;
  if p_payment_received_by is not null then
    raise exception 'Nobody received money on a zero payment' using errcode = '23514';
  end if;
  return 0;
end;
$$;


--
-- Name: calls; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    caller_id uuid NOT NULL,
    callee_id uuid,
    caller_device_uuid uuid NOT NULL,
    accepted_device_uuid uuid,
    agora_channel text NOT NULL,
    status text NOT NULL,
    related_delivery_id uuid,
    client_uuid uuid,
    ringing_until timestamp with time zone NOT NULL,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    duration_seconds integer,
    last_token_issued_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    callee_audience text DEFAULT 'user'::text NOT NULL,
    CONSTRAINT calls_audience_callee_consistency CHECK (((callee_audience = 'user'::text) = (callee_id IS NOT NULL))),
    CONSTRAINT calls_callee_audience_check CHECK ((callee_audience = ANY (ARRAY['user'::text, 'ops_team'::text]))),
    CONSTRAINT calls_not_self CHECK ((caller_id <> callee_id)),
    CONSTRAINT calls_status_check CHECK ((status = ANY (ARRAY['ringing'::text, 'accepted'::text, 'declined'::text, 'cancelled'::text, 'missed'::text, 'completed'::text, 'failed'::text])))
);


--
-- Name: accept_call(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.accept_call(p_call_id uuid, p_device_uuid uuid) RETURNS public.calls
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user uuid := auth.uid();
  v_aud  text;
  v_row  public.calls%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if p_device_uuid is null then
    raise exception 'p_device_uuid is required' using errcode = '22023';
  end if;

  -- Lockless read just to pick the right gate. The UPDATE below is the
  -- actual race guard.
  select callee_audience into v_aud
    from public.calls where id = p_call_id;
  if v_aud is null then
    raise exception 'call not found' using errcode = 'P0002';
  end if;

  if v_aud = 'user' then
    -- 1:1 path. Only the named callee can flip ringing → accepted.
    update public.calls
       set status               = 'accepted',
           accepted_device_uuid = p_device_uuid,
           started_at           = now()
     where id              = p_call_id
       and callee_id       = v_user
       and status          = 'ringing'
       and callee_audience = 'user'
     returning * into v_row;
  else
    -- ops_team path. Any ops user races to grab the row; whoever's UPDATE
    -- wins atomically assigns callee_id=themselves and normalizes
    -- callee_audience to 'user' so the invariant continues to hold and
    -- the rest of the call lifecycle treats this row identically to a 1:1.
    update public.calls
       set status               = 'accepted',
           accepted_device_uuid = p_device_uuid,
           started_at           = now(),
           callee_id            = v_user,
           callee_audience      = 'user'
     where id              = p_call_id
       and status          = 'ringing'
       and callee_id is null
       and callee_audience = 'ops_team'
       and public.is_admin_or_dispatcher()
     returning * into v_row;
  end if;

  if found then
    perform public.write_audit(
      'call', v_row.id,
      jsonb_build_object('status', 'ringing'),
      jsonb_build_object(
        'status',               'accepted',
        'accepted_device_uuid', p_device_uuid,
        'callee_id',            v_row.callee_id,
        'started_at',           v_row.started_at
      ),
      case when v_aud = 'ops_team' then 'team call accepted by ops user' else 'accepted by callee' end,
      v_user
    );
    return v_row;
  end if;

  -- Deliberately NARROW idempotency: only the same user re-accepting on the
  -- same device (a retried request). A different ops user arriving late at a
  -- team call that someone else grabbed must still be told it is taken.
  select * into v_row from public.calls where id = p_call_id;
  if v_row.status = 'accepted'
     and v_row.callee_id = v_user
     and v_row.accepted_device_uuid = p_device_uuid then
    return v_row;
  end if;

  raise exception 'call not available to accept (wrong callee, wrong role, wrong state, or already accepted)'
    using errcode = '55000';
end $$;


--
-- Name: acquire_edit_lock(text, uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.acquire_edit_lock(p_entity_type text, p_entity_id uuid, p_takeover boolean DEFAULT false) RETURNS TABLE(held_by uuid, holder_name text, acquired_at timestamp with time zone, is_self boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$

declare

  v_user     uuid := auth.uid();

  v_existing public.edit_locks%rowtype;

  v_ttl      interval := interval '5 minutes';

begin

  if v_user is null then

    raise exception 'acquire_edit_lock: not signed in' using errcode = '28000';

  end if;

  if not public.is_manager() then

    raise exception 'permission denied' using errcode = '42501';

  end if;



  select * into v_existing

    from public.edit_locks

   where entity_type = p_entity_type and entity_id = p_entity_id

   for update;



  -- Someone else holds it and the lock is fresh: report holder, don't claim.

  if found

     and v_existing.user_id <> v_user

     and v_existing.acquired_at > now() - v_ttl

     and not p_takeover then

    return query

      select v_existing.user_id, u.display_name, v_existing.acquired_at, false

        from public.users u where u.id = v_existing.user_id;

    return;

  end if;



  -- Take-over path: audit the swap.

  if found and v_existing.user_id <> v_user and p_takeover then

    perform public.write_audit(

      'edit_lock', p_entity_id,

      jsonb_build_object('held_by', v_existing.user_id, 'entity_type', p_entity_type),

      jsonb_build_object('held_by', v_user,             'entity_type', p_entity_type),

      'takeover', null

    );

  end if;



  insert into public.edit_locks (entity_type, entity_id, user_id)

    values (p_entity_type, p_entity_id, v_user)

    on conflict (entity_type, entity_id)

      do update set user_id = excluded.user_id, acquired_at = now();



  return query

    select v_user, u.display_name, now(), true

      from public.users u where u.id = v_user;

end $$;


--
-- Name: add_customer_blacklist(text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.add_customer_blacklist(p_phone text, p_reason text, p_source_delivery_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor    uuid := auth.uid();
  v_norm     text := public._norm_phone(p_phone);
  v_display  text := nullif(trim(p_phone), '');
  v_reason   text := nullif(trim(p_reason), '');
  v_row      public.customer_blacklist;
  v_open     integer;
  v_existing boolean := false;
begin
  if not public.is_manager() then
    raise exception 'permission denied: admin or dispatcher only' using errcode = '42501';
  end if;
  if v_norm is null or length(v_norm) < 7 then
    raise exception 'Enter a phone number with at least 7 digits' using errcode = '22023';
  end if;
  if v_reason is null then
    raise exception 'A reason is required' using errcode = '22023';
  end if;
  if p_source_delivery_id is not null
     and not exists (select 1 from public.deliveries where id = p_source_delivery_id) then
    raise exception 'Delivery not found' using errcode = '22023';
  end if;

  perform pg_advisory_xact_lock(hashtextextended('customer-blacklist:' || v_norm, 0));
  select * into v_row from public.customer_blacklist
   where phone_normalized = v_norm and removed_at is null;
  if found then
    v_existing := true;
  else
    insert into public.customer_blacklist(phone_normalized, phone_display, reason, source_delivery_id, added_by)
      values (v_norm, v_display, v_reason, p_source_delivery_id, v_actor)
      returning * into v_row;
    perform public.write_audit('customer_blacklist', v_row.id, null,
      jsonb_build_object('phone_normalized', v_norm, 'phone_display', v_display,
        'reason', v_reason, 'source_delivery_id', p_source_delivery_id),
      'blacklist customer number', v_actor);
  end if;

  select count(*) into v_open
    from public.deliveries d
    join public.delivery_status_defs sd on sd.status = d.current_status
   where d.deleted_at is null and sd.category <> 'terminal'
     and (d.customer_phone_normalized = v_norm or public._norm_phone(d.customer_phone_alt) = v_norm);

  return jsonb_build_object(
    'id', v_row.id, 'phone_display', v_row.phone_display, 'phone_normalized', v_row.phone_normalized,
    'reason', v_row.reason, 'added_at', v_row.added_at,
    'already_listed', v_existing, 'open_orders', v_open);
end;
$$;


--
-- Name: admin_set_user_credentials(uuid, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.admin_set_user_credentials(p_id uuid, p_email text DEFAULT NULL::text, p_password text DEFAULT NULL::text, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth', 'extensions'
    AS $_$
declare
  v_old           public.users;
  v_email         text := nullif(lower(trim(p_email)), '');
  v_pw            text := nullif(p_password, '');
  v_changed_email boolean := false;
  v_changed_pw    boolean := false;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select * into v_old from public.users where id = p_id;
  if not found then
    raise exception 'user not found' using errcode = 'P0002';
  end if;

  if v_email is null and v_pw is null then
    raise exception 'nothing to update: provide an email and/or a password'
      using errcode = '23514';
  end if;

  -- Email change (only when actually different).
  if v_email is not null and v_email is distinct from lower(v_old.email) then
    if v_email !~ '^[^@]+@[^@]+\.[^@]+$' then
      raise exception 'valid email required' using errcode = '23514';
    end if;
    if exists (select 1 from auth.users where email = v_email and id <> p_id) then
      raise exception 'email already in use' using errcode = '23505';
    end if;

    update auth.users
       set email              = v_email,
           email_confirmed_at = now(),
           updated_at         = now()
     where id = p_id;
    -- trigger sync_user_email_to_public mirrors this into public.users.email

    update auth.identities
       set identity_data = jsonb_set(identity_data, '{email}', to_jsonb(v_email)),
           updated_at    = now()
     where user_id = p_id and provider = 'email';

    v_changed_email := true;
  end if;

  -- Password change.
  if v_pw is not null then
    if length(v_pw) < 8 then
      raise exception 'password must be at least 8 characters' using errcode = '23514';
    end if;
    update auth.users
       set encrypted_password = extensions.crypt(v_pw, extensions.gen_salt('bf')),
           updated_at         = now()
     where id = p_id;
    v_changed_pw := true;
  end if;

  if not v_changed_email and not v_changed_pw then
    raise exception 'nothing to update: the email matches and no password was given'
      using errcode = '23514';
  end if;

  -- Force re-login on the target's devices.
  delete from auth.sessions where user_id = p_id;

  perform public.write_audit(
    'user', p_id,
    jsonb_build_object('email', v_old.email),
    jsonb_build_object(
      'email',            coalesce(v_email, v_old.email),
      'email_changed',    v_changed_email,
      'password_changed', v_changed_pw
    ),
    coalesce(p_reason, 'admin credential change')
  );
end;
$_$;


--
-- Name: agent_change_delivery_location(text, uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_change_delivery_location(p_client_uuid text, p_delivery_id uuid, p_location_id uuid, p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor       uuid := auth.uid();
  v_role        text := public.current_user_role();
  v_d           public.deliveries%rowtype;
  v_ineligible  boolean;
  v_to_charged  numeric;
  v_to_agent    numeric;
  v_auto        boolean;
  v_state       text;
  v_settled     boolean;
  v_change_id   uuid;
  v_existing    public.delivery_location_changes%rowtype;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if v_actor is null then raise exception 'not signed in' using errcode = '28000'; end if;
  if p_client_uuid is null or btrim(p_client_uuid) = '' then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  if p_location_id is null then raise exception 'a target zone is required' using errcode = '22023'; end if;
  if p_reason is null or btrim(p_reason) = '' then raise exception 'reason required' using errcode = '22023'; end if;

  -- Idempotency (queue retries): same client_uuid -> return the recorded outcome.
  select * into v_existing from public.delivery_location_changes where client_uuid = p_client_uuid limit 1;
  if found then
    return jsonb_build_object('outcome', v_existing.state, 'change_id', v_existing.id, 'idempotent', true);
  end if;

  select * into v_d from public.deliveries where id = p_delivery_id for update;
  if not found then raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002'; end if;
  if v_d.deleted_at is not null then raise exception 'delivery has been deleted' using errcode = '22023'; end if;

  -- Ownership: the assigned agent, their own row. Ops use the manager RPCs.
  if not (v_role = 'agent' and v_d.assigned_agent_id = v_actor) then
    raise exception 'permission denied: only the assigned agent can change their delivery zone'
      using errcode = '42501';
  end if;

  -- Eligibility: non-terminal OR delivered; reject other terminals + deleted.
  select (sd.category = 'terminal' and v_d.current_status <> 'delivered')
    into v_ineligible
    from public.delivery_status_defs sd where sd.status = v_d.current_status;
  if coalesce(v_ineligible, false) then
    raise exception 'cannot change the zone of a % order', v_d.current_status using errcode = '22023';
  end if;

  if p_location_id = v_d.location_id then
    raise exception 'zone is unchanged' using errcode = '22023';
  end if;

  if exists (select 1 from public.delivery_location_changes
              where delivery_id = p_delivery_id and state = 'pending') then
    raise exception 'a zone change for this order is already awaiting approval' using errcode = '22023';
  end if;

  -- New rate (bonus baked in via the assigned agent).
  select er.charged, er.agent_payment
    into v_to_charged, v_to_agent
    from public.effective_rate(p_location_id, v_d.client_id, v_d.assigned_agent_id) er;
  if v_to_charged is null then
    raise exception
      'no active rate card for (location=%, client=%); cannot change the zone',
      p_location_id, v_d.client_id
      using errcode = '22023',
            hint   = 'add a rate_card row for this location/client first';
  end if;

  -- Decision: first-time set (no prior zone/pay), or agent pay NOT increasing
  -- -> auto-apply. Otherwise hold for a manager.
  v_auto := (v_d.location_id is null)
         or (public._same_customer_normal_fee(v_d) is null)
         or (v_to_agent <= public._same_customer_normal_fee(v_d));

  -- Settled-day drift: is the delivery's scheduled_date already settled for the
  -- client OR the agent (non-voided)?
  select exists (
    select 1 from public.settlements s
     where s.voided_at is null
       and s.period_date = v_d.scheduled_date
       and ( (s.subject_type = 'client' and s.subject_id = v_d.client_id)
          or (s.subject_type = 'agent'  and s.subject_id = v_d.assigned_agent_id) )
  ) into v_settled;

  if v_auto then
    perform public._apply_delivery_zone(
      p_delivery_id, p_location_id,
      'agent_location_change:applied'
        || case when v_settled then ' [settled-day drift]' else '' end
        || ' -- ' || btrim(p_reason));
    v_state := 'applied';
  else
    v_state := 'pending';   -- delivery left untouched until a manager approves
  end if;

  insert into public.delivery_location_changes (
    client_uuid, delivery_id, requested_by_agent_id,
    from_location_id, to_location_id, from_charged, from_agent_payment,
    to_charged, to_agent_payment, reason, state
  ) values (
    p_client_uuid, p_delivery_id, v_actor,
    v_d.location_id, p_location_id, v_d.charged_snapshot, public._same_customer_normal_fee(v_d),
    v_to_charged, v_to_agent, btrim(p_reason), v_state
  ) returning id into v_change_id;

  -- Notify managers when held for approval, OR when an auto-apply lands on an
  -- already-settled day (the only auto-apply case that pushes).
  if v_state = 'pending' or v_settled then
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'managers',
      'title',    case when v_state = 'pending'
                       then 'Zone change needs approval'
                       else 'Zone changed on a settled day' end,
      'body',     coalesce(v_d.customer_name, 'A delivery')
                    || case when v_state = 'pending'
                            then ' — agent zone change raises pay; approve to apply'
                            else ' — agent auto-changed zone on a settled day' end,
      'data',     jsonb_build_object('delivery_id', p_delivery_id,
                                     'change_id', v_change_id,
                                     'route', 'location_approvals')
    ));
  end if;

  return jsonb_build_object('outcome', v_state, 'change_id', v_change_id, 'settled', v_settled);

exception
  when unique_violation then
    -- Two unique constraints collapse here: (a) idempotent replay of the SAME
    -- client_uuid, or (b) a concurrent SECOND pending request for this delivery
    -- hitting dlc_one_open_per_delivery. The implicit savepoint already rolled
    -- back any apply done in this block. If our client_uuid row exists it's (a)
    -- -> return its outcome; otherwise it's (b) -> a clean "already pending" error
    -- (NOT a bogus silent success that drops the agent's queued job).
    select * into v_existing from public.delivery_location_changes where client_uuid = p_client_uuid limit 1;
    if found then
      return jsonb_build_object('outcome', v_existing.state,
                                'change_id', v_existing.id, 'idempotent', true);
    end if;
    raise exception 'a zone change for this order is already awaiting approval'
      using errcode = '22023';
end;
$$;


--
-- Name: agent_earnings_summary(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_earnings_summary(p_from date, p_to date) RETURNS TABLE(agent_id uuid, agent_name text, deliveries_count bigint, total_quantity numeric, total_earnings numeric, total_collected numeric, total_remit numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare r record; begin
  for r in select * from public.agent_earnings_summary_v2(p_from,p_to) loop
    if r.pending_pay_count>0 then raise exception 'Rider pay needs review. Update the app to see pending earnings.' using errcode='P0001'; end if;
    agent_id:=r.agent_id; agent_name:=r.agent_name; deliveries_count:=r.deliveries_count;
    total_quantity:=r.total_quantity; total_earnings:=r.total_earnings; total_collected:=r.total_collected; total_remit:=r.total_remit;
    return next;
  end loop;
end $$;


--
-- Name: FUNCTION agent_earnings_summary(p_from date, p_to date); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.agent_earnings_summary(p_from date, p_to date) IS 'Per-agent reconciliation over [p_from, p_to] on delivered rows. total_earnings = sum(agent_payment_snapshot), the per-delivery LOCATION fee Reda pays the rider (never × quantity, never per product); total_collected = sum(paid) the rider took in; total_remit = collected − earnings, the NET the rider owes Reda. All payment methods. Admin/dispatcher sees all agents; an agent sees only themselves.';


--
-- Name: agent_earnings_summary_v2(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_earnings_summary_v2(p_from date, p_to date) RETURNS TABLE(agent_id uuid, agent_name text, deliveries_count bigint, total_quantity numeric, total_earnings numeric, total_collected numeric, total_remit numeric, known_earnings numeric, pending_pay_count bigint)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ begin
  if auth.uid() is null then raise exception 'authentication required' using errcode='42501'; end if;
  if p_from is null or p_to is null or p_from>p_to then raise exception 'valid date range required' using errcode='22023'; end if;
  return query
  select u.id,u.display_name,count(*),coalesce(sum(f.quantity),0),
    case when count(*) filter(where f.pay_state='pending')=0 then coalesce(sum(f.amount),0) end,
    coalesce(sum(f.paid),0),
    case when count(*) filter(where f.pay_state='pending')=0 then coalesce(sum(f.paid),0)-coalesce(sum(f.amount),0) end,
    coalesce(sum(f.amount) filter(where f.pay_state<>'pending'),0),count(*) filter(where f.pay_state='pending')
  from public._same_customer_financial_rows(p_from,p_to) f join public.users u on u.id=f.rider_id
  where u.role='agent' and (public.is_manager() or u.id=auth.uid())
  group by u.id,u.display_name order by u.display_name,u.id;
end $$;


--
-- Name: agent_pending_workload(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.agent_pending_workload(p_agent_id uuid) RETURNS integer
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select count(*)::int
  from public.deliveries
  where assigned_agent_id = p_agent_id
    and current_status in (
      'pending','available','available_evening',
      'not_answering','number_busy','switched_off','tomorrow','postponed','follow_up',
      'not_connecting','not_around','will_call_back','not_available'
    )
    and deleted_at is null;
$$;


--
-- Name: approve_location_change(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.approve_location_change(p_change_id uuid, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor      uuid := auth.uid();
  v_c          public.delivery_location_changes%rowtype;
  v_d          public.deliveries%rowtype;
  v_ineligible boolean;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array(select delivery_id from public.delivery_location_changes where id=p_change_id),'{}'::uuid[]);
  if not public.is_manager() then
    raise exception 'permission denied: approving a zone change requires admin or dispatcher'
      using errcode = '42501';
  end if;

  select * into v_c from public.delivery_location_changes where id = p_change_id for update;
  if not found then raise exception 'change not found: %', p_change_id using errcode = 'P0002'; end if;
  if v_c.state <> 'pending' then
    raise exception 'this change is already % and cannot be approved', v_c.state using errcode = '22023';
  end if;

  select * into v_d from public.deliveries where id = v_c.delivery_id for update;

  -- The delivery may have moved on while the request was pending.
  select (sd.category = 'terminal' and v_d.current_status <> 'delivered')
    into v_ineligible
    from public.delivery_status_defs sd where sd.status = v_d.current_status;
  v_ineligible := coalesce(v_ineligible, false) or (v_d.deleted_at is not null);

  if v_ineligible then
    update public.delivery_location_changes
       set state = 'rejected', decided_by_user_id = v_actor, decided_at = now(),
           reason = reason || ' | auto-rejected on approval: delivery no longer eligible ('
                            || v_d.current_status || ')'
     where id = p_change_id;
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'user', 'user_id', v_c.requested_by_agent_id::text,
      'title', 'Zone change not applied',
      'body',  'The order changed status before approval, so the zone change was not applied.',
      'data',  jsonb_build_object('delivery_id', v_c.delivery_id)));
    return;
  end if;

  -- Recompute at approval time (client/agent may have changed) and apply.
  perform public._apply_delivery_zone(
    v_c.delivery_id, v_c.to_location_id,
    'agent_location_change:approved -- ' || coalesce(btrim(p_reason), ''));

  update public.delivery_location_changes
     set state = 'approved', decided_by_user_id = v_actor, decided_at = now()
   where id = p_change_id;

  perform public.send_edge_notification(jsonb_build_object(
    'audience', 'user', 'user_id', v_c.requested_by_agent_id::text,
    'title', 'Zone change approved',
    'body',  'Your delivery zone change was approved.',
    'data',  jsonb_build_object('delivery_id', v_c.delivery_id)));
end;
$$;


--
-- Name: assign_same_customer_orders(uuid, uuid[], uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.assign_same_customer_orders(p_request_id uuid, p_delivery_ids uuid[], p_agent_id uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ declare v_ids uuid[]; v_prior record; v_result jsonb; v_updated integer;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(p_delivery_ids,array[p_agent_id]);
  if not public.is_manager() then raise exception 'manager role required' using errcode='42501'; end if;
  select array_agg(distinct x order by x) into v_ids from unnest(p_delivery_ids) x where x is not null;
  if p_request_id is null or p_agent_id is null or coalesce(cardinality(v_ids),0) not between 1 and 100 then
    raise exception 'request, rider and between 1 and 100 orders required' using errcode='22023'; end if;
  perform pg_advisory_xact_lock(hashtextextended('same-customer-assignment:' || p_request_id::text,0));
  select * into v_prior from public.same_customer_assignment_requests where request_id=p_request_id;
  if found then
    if v_prior.actor_id<>auth.uid() or v_prior.agent_id<>p_agent_id or v_prior.delivery_ids<>v_ids then
      raise exception 'assignment request already used for different input' using errcode='23505'; end if;
    return v_prior.result;
  end if;
  perform d.id from public.deliveries d where d.id=any(v_ids) order by d.id for update;
  if exists(select 1 from public.deliveries where id=any(v_ids) and order_type<>'delivery') then
    raise exception 'only ordinary deliveries can be selected here' using errcode='22023'; end if;
  select jsonb_agg(jsonb_build_object('delivery_id',x,'outcome',case
    when d.id is null or d.deleted_at is not null then 'unavailable'
    when s.category='terminal' then 'closed'
    when d.assigned_agent_id=p_agent_id then 'already_assigned'
    else 'assigned' end) order by x) into v_result
  from unnest(v_ids) x left join public.deliveries d on d.id=x
    left join public.delivery_status_defs s on s.status=d.current_status;
  v_updated:=public.bulk_assign_deliveries(v_ids,p_agent_id);
  v_result:=jsonb_build_object('updated_count',v_updated,'orders',v_result);
  insert into public.same_customer_assignment_requests(request_id,actor_id,agent_id,delivery_ids,result)
    values(p_request_id,auth.uid(),p_agent_id,v_ids,v_result);
  return v_result;
end $$;


--
-- Name: auto_assign_delivery(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.auto_assign_delivery(p_delivery_id uuid) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_delivery   public.deliveries%rowtype;
  v_chosen     uuid;
  v_candidates jsonb;
  v_decision   jsonb;
begin
  select * into v_delivery
  from public.deliveries
  where id = p_delivery_id
  for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_delivery.assigned_agent_id is not null then
    return v_delivery.assigned_agent_id;
  end if;

  with sibling_agents as (
    select agent_id from public._open_sibling_agents(p_delivery_id)
  ),
  stocked as (
    select u.id                                as agent_id,
           u.display_name                      as agent_name,
           coalesce(cs.quantity_on_hand, 0)    as stock,
           public.agent_pending_workload(u.id) as workload,
           coalesce(cs.quantity_on_hand, 0) >= v_delivery.quantity_ordered as eligible,
           (u.id in (select agent_id from sibling_agents)) as has_open_sibling,
           case
             when v_delivery.location_id is null then 2
             when exists (
               select 1 from public.agent_locations al
                where al.agent_id    = u.id
                  and al.location_id = v_delivery.location_id
                  and al.kind        = 'preferred'
             ) then 1
             when exists (
               select 1 from public.agent_locations al
                where al.agent_id    = u.id
                  and al.location_id = v_delivery.location_id
                  and al.kind        = 'avoid'
             ) then 3
             else 2
           end as preference_tier
    from public.users u
    left join public.current_stock cs
      on cs.agent_id           = u.id
     and cs.product_catalog_id = v_delivery.product_catalog_id
    where u.role = 'agent'
      and u.is_active = true
      and u.parent_agent_id is null
  )
  -- Soft stock preference: eligible agents are preferred via eligible DESC,
  -- but stockless agents remain selectable as last resort. The downstream
  -- tg_notify_pickup_needed trigger pushes admins+dispatchers to issue a
  -- warehouse transfer when a stockless agent is chosen.
  select
    (select agent_id from stocked
      order by eligible desc, has_open_sibling asc, preference_tier asc,
               workload asc, stock desc, random()
      limit 1),
    coalesce(jsonb_agg(jsonb_build_object(
      'agent_id',          agent_id,
      'agent_name',        agent_name,
      'stock',             stock,
      'workload',          workload,
      'eligible',          eligible,
      'has_open_sibling',  has_open_sibling,
      'preference_tier',   preference_tier
    ) order by eligible desc, has_open_sibling asc, preference_tier asc, workload asc, stock desc), '[]'::jsonb)
  into v_chosen, v_candidates
  from stocked;

  v_decision := jsonb_build_object(
    'chosen_agent_id',      v_chosen,
    'required_quantity',    v_delivery.quantity_ordered,
    'product_catalog_id',   v_delivery.product_catalog_id,
    'delivery_location_id', v_delivery.location_id,
    'candidates',           v_candidates
  );

  if v_chosen is not null then
    update public.deliveries
       set assigned_agent_id = v_chosen,
           updated_at        = now()
     where id = p_delivery_id
       and assigned_agent_id is null;
  end if;

  perform public.write_audit(
    p_actor_id    := null,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := null,
    p_new         := v_decision,
    p_reason      := case when v_chosen is null
                          then 'auto_assign: no eligible agent'
                          else 'auto_assign'
                     end
  );

  return v_chosen;
end;
$$;


--
-- Name: FUNCTION auto_assign_delivery(p_delivery_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.auto_assign_delivery(p_delivery_id uuid) IS 'Picks an agent for an unassigned delivery by stock-coverage + workload. Audit-logs the full scoring trace. Idempotent: if already assigned, returns the existing assignee.';


--
-- Name: bot_create_delivery(text, uuid, uuid, text, text, text, integer, numeric, uuid, date, text, uuid, text, jsonb, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bot_create_delivery(p_client_uuid text, p_client_id uuid, p_product_catalog_id uuid, p_customer_name text, p_customer_phone text, p_raw_address text, p_quantity_ordered integer, p_customer_price numeric, p_location_id uuid DEFAULT NULL::uuid, p_scheduled_date date DEFAULT CURRENT_DATE, p_bot_raw_message text DEFAULT NULL::text, p_assigned_agent_id uuid DEFAULT NULL::uuid, p_customer_phone_alt text DEFAULT NULL::text, p_items jsonb DEFAULT NULL::jsonb, p_delivery_instructions text DEFAULT NULL::text, p_client_rep text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_bot_user_id        uuid;
  v_delivery_id        uuid;
  v_fingerprint        text := public._text_fingerprint(p_bot_raw_message);
  v_phone_norm         text := public._norm_phone(p_customer_phone);
  v_effective_agent_id uuid := p_assigned_agent_id;
  v_orphan_id          uuid;
  v_existing_id        uuid;
  v_eff_date           date := public._effective_scheduled_date(p_scheduled_date, 'bot');
  v_client_rep         text := nullif(trim(p_client_rep), '');
  v_items_fp           text := public._delivery_items_sig(coalesce(p_items, jsonb_build_array(
                          jsonb_build_object('product_catalog_id', p_product_catalog_id,
                                             'quantity_ordered', p_quantity_ordered))));  -- [Feature A]
begin
  select id into v_bot_user_id from public.users
   where email = 'bot@reda.dev' and is_active = true limit 1;
  if v_bot_user_id is null then
    select id into v_bot_user_id from public.users
     where role = 'admin' and is_active = true order by created_at limit 1;
  end if;
  if v_bot_user_id is null then raise exception 'no admin user available to act as bot'; end if;

  perform set_config('request.jwt.claims',
    json_build_object('sub', v_bot_user_id::text, 'role', 'authenticated')::text, true);

  -- Customer blacklist: refuse before the duplicate/orphan logic can dispatch.
  perform public._assert_customer_not_blacklisted(p_customer_phone, p_customer_phone_alt);

  -- Pre-empt same-agent dupe at intake — re-keyed to items_fingerprint.
  if v_effective_agent_id is not null and v_phone_norm is not null then
    select d.id into v_existing_id
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
     where d.assigned_agent_id = v_effective_agent_id
       and d.customer_phone_normalized = v_phone_norm
       and d.items_fingerprint = v_items_fp            -- [Feature A]
       and (d.scheduled_date = v_eff_date or d.current_status = 'postponed')
       and d.deleted_at is null
       and sd.category <> 'terminal'
       and (
         (v_fingerprint is not null and d.text_fingerprint is not null and d.text_fingerprint = v_fingerprint)
         or
         (public._norm_address(d.raw_address) = public._norm_address(p_raw_address))
       )
     order by d.created_at asc limit 1;

    if v_existing_id is not null then
      raise exception 'duplicate forward: agent % already has open delivery % for customer % items % on %',
        v_effective_agent_id, v_existing_id, v_phone_norm, v_items_fp, v_eff_date
        using errcode = 'P0001',
              hint = jsonb_build_object('kind','duplicate_same_agent',
                'existing_delivery_id', v_existing_id, 'agent_id', v_effective_agent_id)::text;
    end if;
  end if;

  -- Smart-reassign of unassigned orphan — re-keyed to items_fingerprint.
  if v_phone_norm is not null then
    select d.id into v_orphan_id
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
     where d.assigned_agent_id is null
       and d.customer_phone_normalized = v_phone_norm
       and d.items_fingerprint = v_items_fp            -- [Feature A]
       and d.scheduled_date = v_eff_date
       and d.deleted_at is null
       and sd.category <> 'terminal'
       and (
         (v_fingerprint is not null and d.text_fingerprint is not null and d.text_fingerprint = v_fingerprint)
         or
         (public._norm_address(d.raw_address) = public._norm_address(p_raw_address))
       )
     order by d.created_at asc limit 1 for update;

    if v_orphan_id is not null then
      -- Absorb the orphan: attach the agent, and backfill the rep from THIS
      -- forward only if the orphan doesn't already carry one (never overwrite an
      -- existing value). The rep may only appear on the second forward.
      update public.deliveries
         set assigned_agent_id = v_effective_agent_id,
             client_rep        = coalesce(client_rep, v_client_rep),
             updated_at        = now()
       where id = v_orphan_id;
      perform public.write_audit(
        p_actor_id := v_bot_user_id, p_entity_type := 'delivery', p_entity_id := v_orphan_id,
        p_old := jsonb_build_object('assigned_agent_id', null),
        p_new := jsonb_build_object('assigned_agent_id', v_effective_agent_id,
          'client_rep', v_client_rep,
          'triggering_bot_message', p_bot_raw_message),
        p_reason := 'bot_smart_reassign: absorbed unassigned sibling');
      return v_orphan_id;
    end if;
  end if;

  v_delivery_id := public.create_delivery(
    p_client_uuid => p_client_uuid, p_client_id => p_client_id,
    p_product_catalog_id => p_product_catalog_id, p_customer_name => p_customer_name,
    p_customer_phone => p_customer_phone, p_raw_address => p_raw_address,
    p_quantity_ordered => p_quantity_ordered, p_customer_price => p_customer_price,
    p_location_id => p_location_id, p_scheduled_date => v_eff_date,
    p_assigned_agent_id => v_effective_agent_id, p_created_via => 'bot',
    p_bot_raw_message => p_bot_raw_message, p_customer_phone_alt => p_customer_phone_alt,
    p_items => p_items, p_delivery_instructions => p_delivery_instructions,
    p_client_rep => p_client_rep
  );
  return v_delivery_id;
end;
$$;


--
-- Name: bulk_assign_deliveries(uuid[], uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_assign_deliveries(p_delivery_ids uuid[], p_agent_id uuid) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor    uuid := auth.uid();
  v_agent    public.users%rowtype;
  v_updated  int  := 0;
  v_row      record;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(p_delivery_ids,array[p_agent_id]);
  if not public.is_admin_or_dispatcher() then
    raise exception 'bulk assign requires admin or dispatcher role'
      using errcode = '42501';
  end if;

  if p_delivery_ids is null or array_length(p_delivery_ids, 1) is null then
    return 0;
  end if;

  select * into v_agent from public.users where id = p_agent_id;
  if not found then
    raise exception 'agent not found' using errcode = 'P0002';
  end if;
  if v_agent.role <> 'agent' or not v_agent.is_active then
    raise exception 'target must be an active agent' using errcode = '22023';
  end if;
  if v_agent.parent_agent_id is not null then
    raise exception 'cannot bulk-assign to a sub-agent — use the team-lead handoff flow'
      using errcode = '22023';
  end if;

  for v_row in
    select d.id, d.assigned_agent_id, d.current_status
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
     where d.id = any(p_delivery_ids)
       and d.deleted_at is null
       and sd.category <> 'terminal'
     for update
  loop
    if v_row.assigned_agent_id is distinct from p_agent_id then
      update public.deliveries
         set assigned_agent_id = p_agent_id,
             updated_at        = now()
       where id = v_row.id;

      perform public.write_audit(
        p_actor_id    := v_actor,
        p_entity_type := 'delivery',
        p_entity_id   := v_row.id,
        p_old         := jsonb_build_object('assigned_agent_id', v_row.assigned_agent_id),
        p_new         := jsonb_build_object('assigned_agent_id', p_agent_id),
        p_reason      := 'bulk_assign'
      );

      v_updated := v_updated + 1;
    end if;
  end loop;

  return v_updated;
end;
$$;


--
-- Name: bulk_change_delivery_status(text, uuid[], text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_change_delivery_status(p_client_uuid text, p_delivery_ids uuid[], p_to_status text, p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_id      uuid;
  v_idx     int  := 0;
  v_changed int  := 0;
  v_skipped int  := 0;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(p_delivery_ids,'{}'::uuid[]);
  if not public.is_admin_or_dispatcher() then
    raise exception 'bulk status change requires admin or dispatcher role'
      using errcode = '42501';
  end if;
  if p_client_uuid is null or btrim(p_client_uuid) = '' then
    raise exception 'client_uuid required for idempotency' using errcode = '22023';
  end if;
  if p_to_status is null or btrim(p_to_status) = '' then
    raise exception 'to_status required' using errcode = '22023';
  end if;
  if p_delivery_ids is null or array_length(p_delivery_ids, 1) is null then
    return jsonb_build_object('changed_count', 0, 'skipped_count', 0);
  end if;

  foreach v_id in array p_delivery_ids loop
    v_idx := v_idx + 1;
    -- Per-row sub-transaction. change_delivery_status raises on:
    --   - missing row / deleted row
    --   - no valid transition (e.g., already terminal-but-not-rolled-over)
    --   - requires_admin gate when dispatcher tries an admin-only transition
    --   - the postponed/delivered argument requirements
    -- Each becomes a skip. Successful rows commit independently.
    begin
      perform public.change_delivery_status(
        p_client_uuid        := p_client_uuid || ':' || v_idx::text,
        p_delivery_id        := v_id,
        p_to_status          := p_to_status,
        p_reason             := p_reason,
        p_notes              := null,
        p_quantity_delivered := null,
        p_paid               := null,
        p_payment_method     := null
      );
      v_changed := v_changed + 1;
    exception when others then
      v_skipped := v_skipped + 1;
    end;
  end loop;

  return jsonb_build_object('changed_count', v_changed, 'skipped_count', v_skipped);
end;
$$;


--
-- Name: FUNCTION bulk_change_delivery_status(p_client_uuid text, p_delivery_ids uuid[], p_to_status text, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.bulk_change_delivery_status(p_client_uuid text, p_delivery_ids uuid[], p_to_status text, p_reason text) IS 'Admin/dispatcher bulk status change. Per-row change_delivery_status; invalid transitions skip with a count.';


--
-- Name: bulk_delete_deliveries(uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_delete_deliveries(p_delivery_ids uuid[], p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor   uuid := auth.uid();
  v_row     record;
  v_deleted int  := 0;
  v_skipped int  := 0;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(p_delivery_ids,'{}'::uuid[]);
  if not public.is_admin() then
    raise exception 'bulk delete requires admin role' using errcode = '42501';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required for bulk delete' using errcode = '22023';
  end if;
  if p_delivery_ids is null or array_length(p_delivery_ids, 1) is null then
    return jsonb_build_object('deleted_count', 0, 'skipped_count', 0);
  end if;

  for v_row in
    select id, current_status, deleted_at, assigned_agent_id
      from public.deliveries
     where id = any(p_delivery_ids)
     for update
  loop
    if v_row.deleted_at is not null
       or v_row.current_status in ('delivered', 'rolled_over') then
      v_skipped := v_skipped + 1;
      continue;
    end if;

    update public.deliveries
       set deleted_at = now(),
           updated_at = now()
     where id = v_row.id;

    -- Resolve open issues/threads on the deleted row (see delete_delivery).
    update public.delivery_messages
       set read_at = now()
     where delivery_id = v_row.id
       and read_at is null;

    perform public.write_audit(
      p_actor_id    := v_actor,
      p_entity_type := 'delivery',
      p_entity_id   := v_row.id,
      p_old         := jsonb_build_object(
                         'deleted_at', null,
                         'current_status', v_row.current_status,
                         'assigned_agent_id', v_row.assigned_agent_id
                       ),
      p_new         := jsonb_build_object('deleted_at', now()),
      p_reason      := btrim(p_reason)
    );

    v_deleted := v_deleted + 1;
  end loop;

  return jsonb_build_object('deleted_count', v_deleted, 'skipped_count', v_skipped);
end;
$$;


--
-- Name: FUNCTION bulk_delete_deliveries(p_delivery_ids uuid[], p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.bulk_delete_deliveries(p_delivery_ids uuid[], p_reason text) IS 'Admin-only bulk soft delete. Skips delivered/rolled_over/already-deleted; returns counts.';


--
-- Name: bulk_settle_agents(uuid, uuid[], date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_settle_agents(p_request_id uuid, p_agent_ids uuid[], p_period_date date, p_note text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_agent_ids uuid[];
  v_note text := nullif(btrim(p_note), '');
  v_batch public.settlement_batches%rowtype;
  v_inserted boolean := false;
  v_agent_id uuid;
  v_settlement_id uuid;
  v_expected numeric;
  v_total numeric := 0;
  v_results jsonb := '[]'::jsonb;
  v_result jsonb;
  v_invalid_count integer;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_financial_keys(array(select 'agent:'||id::text from unnest(p_agent_ids) id));
  if not public.is_admin() then
    raise exception 'only admin can record handovers' using errcode = '42501';
  end if;
  if p_request_id is null then
    raise exception 'request_id required' using errcode = '23514';
  end if;
  if p_period_date is null then
    raise exception 'period_date required' using errcode = '23514';
  end if;
  if p_agent_ids is null or cardinality(p_agent_ids) = 0 then
    raise exception 'select at least one agent' using errcode = '23514';
  end if;
  if cardinality(p_agent_ids) > 100 then
    raise exception 'a handover batch can contain at most 100 agents'
      using errcode = '22023';
  end if;

  -- Canonical ordering makes retries comparable regardless of UI ordering.
  select array_agg(agent_id order by agent_id)
    into v_agent_ids
    from (
      select distinct candidate as agent_id
        from unnest(p_agent_ids) as requested(candidate)
       where candidate is not null
    ) canonical;

  if cardinality(v_agent_ids) is distinct from cardinality(p_agent_ids) then
    raise exception 'agent_ids cannot contain nulls or duplicates'
      using errcode = '23514';
  end if;

  select count(*)
    into v_invalid_count
    from unnest(v_agent_ids) requested(agent_id)
    left join public.users u
      on u.id = requested.agent_id
     and u.role = 'agent'
   where u.id is null;
  if v_invalid_count > 0 then
    raise exception 'one or more selected users are not agents'
      using errcode = '22023';
  end if;

  -- Claim this request UUID before doing money work. ON CONFLICT makes a retry
  -- wait for the first transaction, then return that transaction's saved result.
  insert into public.settlement_batches(
    id, period_date, agent_ids, note, settled_by, result
  ) values (
    p_request_id, p_period_date, v_agent_ids, v_note, v_actor, '{}'::jsonb
  )
  on conflict (id) do nothing
  returning true into v_inserted;

  if not coalesce(v_inserted, false) then
    select * into v_batch
      from public.settlement_batches
     where id = p_request_id;

    if v_batch.settled_by is distinct from v_actor
       or v_batch.period_date is distinct from p_period_date
       or v_batch.agent_ids is distinct from v_agent_ids
       or v_batch.note is distinct from v_note then
      raise exception 'request_id was already used for a different handover batch'
        using errcode = '22023';
    end if;

    return v_batch.result;
  end if;

  if exists (
    select 1
      from public.settlements s
     where s.subject_type = 'agent'
       and s.subject_id = any(v_agent_ids)
       and s.period_date = p_period_date
       and s.voided_at is null
  ) then
    raise exception 'one or more selected agents are already handed over; refresh and try again'
      using errcode = '23505';
  end if;

  foreach v_agent_id in array v_agent_ids loop
    -- settle_period remains the single source of truth for delivery and
    -- replacement accounting, snapshots, permissions and per-settlement audit.
    v_settlement_id := public.settle_period('agent', v_agent_id, p_period_date, v_note);

    select expected_amount
      into v_expected
      from public.settlements
     where id = v_settlement_id;

    if v_expected is null or v_expected <= 0 then
      raise exception 'agent % has no positive amount to hand over for %',
        v_agent_id, p_period_date
        using errcode = '22023';
    end if;

    v_total := v_total + v_expected;
    v_results := v_results || jsonb_build_array(jsonb_build_object(
      'agent_id', v_agent_id,
      'settlement_id', v_settlement_id,
      'expected_amount', v_expected
    ));
  end loop;

  v_result := jsonb_build_object(
    'batch_id', p_request_id,
    'settled_count', cardinality(v_agent_ids),
    'expected_amount', v_total,
    'settlements', v_results
  );

  update public.settlement_batches
     set result = v_result
   where id = p_request_id;

  perform public.write_audit(
    'settlement_batch', p_request_id, null,
    jsonb_build_object(
      'period_date', p_period_date,
      'agent_ids', to_jsonb(v_agent_ids),
      'settled_count', cardinality(v_agent_ids),
      'expected_amount', v_total,
      'note', v_note
    ),
    'bulk_settle_agents'
  );

  return v_result;
end;
$$;


--
-- Name: bulk_unassign_deliveries(text, uuid[], text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bulk_unassign_deliveries(p_client_uuid text, p_delivery_ids uuid[], p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor   uuid := auth.uid();
  v_reason  text := nullif(btrim(p_reason), '');
  v_ids     uuid[];
  v_id      uuid;
  v_row     record;
  v_done    integer := 0;
  v_skipped jsonb := '[]'::jsonb;
  v_agents  jsonb := '{}'::jsonb;   -- former agent id -> rows taken off their list
  v_agent   record;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(p_delivery_ids,'{}'::uuid[]);
  if not public.is_manager() then
    raise exception 'unassign requires admin or dispatcher role' using errcode = '42501';
  end if;
  if p_client_uuid is null or btrim(p_client_uuid) = '' then
    raise exception 'client_uuid required' using errcode = '22023';
  end if;
  if v_reason is null then
    raise exception 'reason required for unassign' using errcode = '22023';
  end if;
  -- Dedupe and sort: two overlapping batches then lock rows in the same order.
  select coalesce(array_agg(distinct x order by x), '{}'::uuid[]) into v_ids
    from unnest(p_delivery_ids) x where x is not null;
  if coalesce(array_length(v_ids, 1), 0) = 0 then
    return jsonb_build_object('unassigned_count', 0, 'skipped_count', 0,
      'skipped', '[]'::jsonb, 'agents', '[]'::jsonb);
  end if;
  if array_length(v_ids, 1) > 200 then
    raise exception 'Unassign at most 200 deliveries at a time' using errcode = '22023';
  end if;

  perform set_config('reda.suppress_assignment_push', 'true', true);

  foreach v_id in array v_ids loop
    select d.id, d.customer_name, d.assigned_agent_id, d.deleted_at, d.current_status, sd.category
      into v_row
      from public.deliveries d
      left join public.delivery_status_defs sd on sd.status = d.current_status
     where d.id = v_id;
    if not found then
      v_skipped := v_skipped || jsonb_build_object('delivery_id', v_id, 'customer_name', null, 'why', 'not found');
    elsif v_row.deleted_at is not null then
      v_skipped := v_skipped || jsonb_build_object('delivery_id', v_id, 'customer_name', v_row.customer_name, 'why', 'deleted');
    elsif v_row.category = 'terminal' then
      v_skipped := v_skipped || jsonb_build_object('delivery_id', v_id, 'customer_name', v_row.customer_name,
        'why', 'closed (' || replace(v_row.current_status, '_', ' ') || ')');
    elsif v_row.assigned_agent_id is null then
      v_skipped := v_skipped || jsonb_build_object('delivery_id', v_id, 'customer_name', v_row.customer_name, 'why', 'already in the queue');
    else
      -- Per-row subtransaction through the canonical single path (same gates,
      -- same audit shape). A refusal becomes a skip, not a failed batch.
      begin
        perform public.unassign_delivery(v_id, v_reason || ' (bulk ' || left(p_client_uuid, 8) || ')');
        v_done := v_done + 1;
        v_agents := jsonb_set(v_agents, array[v_row.assigned_agent_id::text],
          to_jsonb(coalesce((v_agents->>v_row.assigned_agent_id::text)::integer, 0) + 1));
      exception when others then
        v_skipped := v_skipped || jsonb_build_object('delivery_id', v_id, 'customer_name', v_row.customer_name, 'why', sqlerrm);
      end;
    end if;
  end loop;

  -- One summary push per former rider. Never the person doing the unassign.
  for v_agent in
    select e.key::uuid as agent_id, e.value::integer as n from jsonb_each_text(v_agents) e
  loop
    if v_agent.agent_id is distinct from v_actor then
      perform public.send_edge_notification(jsonb_build_object(
        'audience', 'user',
        'user_id',  v_agent.agent_id::text,
        'title',    case when v_agent.n = 1 then 'Order moved to the queue'
                         else v_agent.n || ' orders moved to the queue' end,
        'body',     case when v_agent.n = 1 then 'One delivery is no longer on your list.'
                         else v_agent.n || ' deliveries are no longer on your list.' end,
        'data',     jsonb_build_object('kind', 'bulk_unassign', 'count', v_agent.n)));
    end if;
  end loop;

  -- The flag is transaction-local; clear it so nothing later in the same
  -- transaction (smoke tests, future composite RPCs) is silenced by accident.
  perform set_config('reda.suppress_assignment_push', 'false', true);

  return jsonb_build_object(
    'unassigned_count', v_done,
    'skipped_count',    jsonb_array_length(v_skipped),
    'skipped',          v_skipped,
    'agents', (
      select coalesce(jsonb_agg(jsonb_build_object(
               'agent_id', e.key, 'agent_name', u.display_name, 'count', e.value::integer)
               order by e.value::integer desc, u.display_name), '[]'::jsonb)
        from jsonb_each_text(v_agents) e
        left join public.users u on u.id = e.key::uuid));
end;
$$;


--
-- Name: cancel_call(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.cancel_call(p_call_id uuid) RETURNS public.calls
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user uuid := auth.uid();
  v_row  public.calls%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;

  update public.calls
     set status   = 'cancelled',
         ended_at = now()
   where id        = p_call_id
     and caller_id = v_user
     and status    = 'ringing'
   returning * into v_row;

  if found then
    perform public.write_audit(
      'call', v_row.id,
      jsonb_build_object('status', 'ringing'),
      jsonb_build_object('status', 'cancelled', 'ended_at', v_row.ended_at),
      'cancelled by caller',
      v_user
    );
    return v_row;
  end if;

  select * into v_row from public.calls where id = p_call_id;
  if not found then
    raise exception 'call not found' using errcode = 'P0002';
  end if;

  -- Already over, and it was this user's call to cancel -> no-op success.
  if v_row.caller_id = v_user
     and v_row.status in ('cancelled','declined','missed','completed','failed') then
    return v_row;
  end if;

  raise exception 'call not available to cancel (wrong caller, or call already in progress)'
    using errcode = '55000';
end $$;


--
-- Name: change_delivery_status(text, uuid, text, text, text, integer, numeric, text, timestamp with time zone, date, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.change_delivery_status(p_client_uuid text, p_delivery_id uuid, p_to_status text, p_reason text DEFAULT NULL::text, p_notes text DEFAULT NULL::text, p_quantity_delivered integer DEFAULT NULL::integer, p_paid numeric DEFAULT NULL::numeric, p_payment_method text DEFAULT NULL::text, p_effective_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_new_scheduled_date date DEFAULT NULL::date, p_item_quantities jsonb DEFAULT NULL::jsonb) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$

declare

  v_delivery       record;

  v_transition     record;

  v_actor          uuid := auth.uid();

  v_is_admin       boolean := public.is_admin();

  v_is_dispatcher  boolean := public.is_admin_or_dispatcher();

  v_role           text := public.current_user_role();

  v_effective      timestamptz := coalesce(p_effective_at, now());

  v_existing       uuid;

  v_on_hand        int;

  v_new_date       date;

  v_final_date     date;

  v_eff_items      jsonb;

  v_guard          record;

  v_sum_delivered  int;

  v_item_count     int;

  v_fulfilled_sib  record;

begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);

  if p_client_uuid is null or trim(p_client_uuid) = '' then

    raise exception 'client_uuid required' using errcode = '23514';

  end if;



  select id into v_existing from public.delivery_status_history where client_uuid = p_client_uuid limit 1;

  if v_existing is not null then return; end if;



  select * into v_delivery from public.deliveries where id = p_delivery_id for update;

  if not found then raise exception 'delivery not found' using errcode = 'P0002'; end if;

  if v_delivery.deleted_at is not null then raise exception 'delivery has been deleted' using errcode = '22023'; end if;

  if v_delivery.current_status = p_to_status then return; end if;



  select * into v_transition from public.delivery_status_transitions

   where from_status = v_delivery.current_status and to_status = p_to_status;

  if not found then

    raise exception 'invalid transition: % -> %', v_delivery.current_status, p_to_status using errcode = '22023';

  end if;



  if v_transition.requires_admin then

    if not v_is_admin then raise exception 'this transition requires admin' using errcode = '42501'; end if;

  else

    if not (v_is_dispatcher or (v_role = 'agent' and v_delivery.assigned_agent_id = v_actor)) then

      raise exception 'permission denied' using errcode = '42501';

    end if;

  end if;



  if v_transition.requires_reason and nullif(trim(p_reason), '') is null then

    raise exception 'reason required for this transition' using errcode = '23514';

  end if;



  if p_to_status in ('delivered','picked_up','waybilled') then

    select s.current_status, s.updated_at,

           coalesce(u.display_name, 'another agent') as agent_name,

           coalesce(sd.label, s.current_status) as status_label

      into v_fulfilled_sib

      from public._find_sibling_deliveries(p_delivery_id) s

      join public.delivery_status_defs sd on sd.status = s.current_status

      left join public.users u on u.id = s.assigned_agent_id

     where s.current_status in ('delivered','picked_up','waybilled')

     order by s.updated_at desc

     limit 1;

    if found then

      raise exception 'This order was already % by % (on %). It cannot be marked % again -- it is a duplicate of an order another agent has already handled.',

        v_fulfilled_sib.status_label, v_fulfilled_sib.agent_name,

        to_char(v_fulfilled_sib.updated_at at time zone 'Africa/Lagos', 'DD Mon HH24:MI'),

        p_to_status

        using errcode = 'P0001',

              hint = jsonb_build_object('code','already_fulfilled_sibling','delivery_id', p_delivery_id)::text;

    end if;

  end if;



  if p_to_status = 'postponed' and p_new_scheduled_date is not null then

    if p_new_scheduled_date <= current_date then

      raise exception 'postpone date must be in the future (got %, today is %)', p_new_scheduled_date, current_date

        using errcode = '23514';

    end if;

    v_new_date := public._ensure_workday(p_new_scheduled_date);

  end if;



  -- Replacements reschedule this same exchange; they never create a rollover child.
  if v_delivery.order_type = 'replacement' and p_to_status = 'tomorrow' then
    v_new_date := public._ensure_workday((now() at time zone 'Africa/Lagos')::date + 1);
  end if;
  v_final_date := case

    when v_new_date is not null then v_new_date

    when (v_delivery.current_status = 'postponed' or (v_delivery.order_type = 'replacement' and v_delivery.current_status = 'tomorrow'))

         and p_to_status <> 'postponed'

      then (now() at time zone 'Africa/Lagos')::date

    else v_delivery.scheduled_date

  end;



  if p_to_status = 'delivered' then

    if p_quantity_delivered is null or p_quantity_delivered <= 0 then

      raise exception 'quantity_delivered required (> 0) for delivered status' using errcode = '23514';

    end if;

    if p_paid is null or p_paid < 0 then

      raise exception 'paid required (>= 0) for delivered status' using errcode = '23514';

    end if;

    if p_payment_method not in ('cash','transfer','vendor_direct') then

      raise exception 'payment_method must be ''cash'', ''transfer'' or ''vendor_direct''' using errcode = '23514';

    end if;

    if p_payment_method = 'vendor_direct' and coalesce(p_paid, 0) <> 0 then

      raise exception 'vendor_direct requires paid = 0 (the customer paid the vendor directly)' using errcode = '23514';

    end if;

    if v_delivery.location_id is null then

      raise exception 'this delivery has no location set. Ask admin to edit the delivery and set the location before marking delivered.'

        using errcode = 'P0001',

              hint = jsonb_build_object('code','location_required','delivery_id', p_delivery_id)::text;

    end if;

    if v_delivery.assigned_agent_id is null then

      raise exception 'cannot mark delivered: no agent is assigned to this delivery. Assign an agent first.'

        using errcode = 'P0001',

              hint = jsonb_build_object('code','no_agent_assigned','delivery_id', p_delivery_id)::text;

    end if;



    if p_item_quantities is not null then

      if jsonb_typeof(p_item_quantities) <> 'array' or jsonb_array_length(p_item_quantities) = 0 then

        raise exception 'p_item_quantities must be a non-empty array' using errcode = '23514';

      end if;

      v_eff_items := p_item_quantities;

    else

      select count(*) into v_item_count

        from public.delivery_items where delivery_id = p_delivery_id;

      if v_item_count = 0 then

        v_eff_items := jsonb_build_array(jsonb_build_object(

          'product_catalog_id', v_delivery.product_catalog_id,

          'quantity_delivered', p_quantity_delivered));

      elsif v_item_count = 1 then

        select jsonb_agg(jsonb_build_object(

                 'product_catalog_id', di.product_catalog_id,

                 'quantity_delivered', p_quantity_delivered))

          into v_eff_items

          from public.delivery_items di

         where di.delivery_id = p_delivery_id;

      else

        select jsonb_agg(jsonb_build_object(

                 'product_catalog_id', di.product_catalog_id,

                 'quantity_delivered', di.quantity_ordered))

          into v_eff_items

          from public.delivery_items di

         where di.delivery_id = p_delivery_id;

      end if;

    end if;



    for v_guard in

      select (e->>'product_catalog_id')::uuid as pid,

             sum((e->>'quantity_delivered')::int) as qd

        from jsonb_array_elements(v_eff_items) e

       group by (e->>'product_catalog_id')::uuid

    loop

      select coalesce(quantity_on_hand, 0) into v_on_hand

        from public.current_stock

       where agent_id = v_delivery.assigned_agent_id and product_catalog_id = v_guard.pid;

      if coalesce(v_on_hand, 0) < v_guard.qd then

        raise exception 'insufficient_stock: agent has % units of "%", delivery needs %',

          coalesce(v_on_hand, 0), coalesce((select product_name from public.product_catalog where id = v_guard.pid), v_guard.pid::text), v_guard.qd

          using errcode = 'P0001',

                hint = jsonb_build_object('code','insufficient_stock',

                  'product_catalog_id', v_guard.pid, 'product_name', (select product_name from public.product_catalog where id = v_guard.pid), 'on_hand', coalesce(v_on_hand, 0), 'needed', v_guard.qd)::text;

      end if;

    end loop;

  end if;



  insert into public.delivery_status_history (

    delivery_id, from_status, to_status, changed_by_user_id, client_uuid, effective_at, reason, notes, reported_occurred_at

  ) values (

    p_delivery_id, v_delivery.current_status, p_to_status, v_actor, p_client_uuid, v_effective, p_reason, p_notes, p_effective_at

  );



  update public.deliveries

     set current_status      = p_to_status,

         scheduled_date      = v_final_date,

         quantity_delivered  = case when p_to_status = 'delivered' then p_quantity_delivered else quantity_delivered end,

         paid                = case when p_to_status = 'delivered' then p_paid else paid end,

         payment_method      = case when p_to_status = 'delivered' then p_payment_method else payment_method end,

         cash_pos_fee_snapshot = case

                                    when p_to_status = 'delivered' and p_payment_method = 'cash' and coalesce(p_paid, 0) > 0 then 500

                                    when p_to_status = 'delivered' then 0

                                    else cash_pos_fee_snapshot end

   where id = p_delivery_id;



  if p_to_status = 'delivered' then

    v_sum_delivered := public._apply_item_deliveries(p_delivery_id, v_eff_items);

    update public.deliveries set quantity_delivered = v_sum_delivered where id = p_delivery_id;

  end if;



  -- [Phase 2] Immutable delivery stock ledger. Replaces the current_stock

  -- view's derived delivered_decrements. Per delivered LINE ITEM; idempotency

  -- is inherited from the early-return on a duplicate p_client_uuid above.

  if p_to_status = 'delivered' then

    insert into public.stock_adjustments

      (agent_id, product_catalog_id, quantity_delta, reason, notes,

       client_uuid, created_by_user_id, delivery_id)

    select v_delivery.assigned_agent_id, di.product_catalog_id, -di.quantity_delivered, 'delivered',

           null, p_client_uuid || ':delivered:' || di.product_catalog_id::text, v_actor, p_delivery_id

      from public.delivery_items di

     where di.delivery_id = p_delivery_id

       and coalesce(di.quantity_delivered, 0) > 0;

  elsif v_delivery.current_status = 'delivered' then

    -- Leaving delivered (admin corrective transition) -> release stock back.

    insert into public.stock_adjustments

      (agent_id, product_catalog_id, quantity_delta, reason, notes,

       client_uuid, created_by_user_id, delivery_id)

    select v_delivery.assigned_agent_id, di.product_catalog_id, di.quantity_delivered, 'delivery_returned',

           'reverted: delivered -> ' || p_to_status,

           p_client_uuid || ':returned:' || di.product_catalog_id::text, v_actor, p_delivery_id

      from public.delivery_items di

     where di.delivery_id = p_delivery_id

       and coalesce(di.quantity_delivered, 0) > 0;

  end if;



  perform public.write_audit(

    'delivery', p_delivery_id,

    jsonb_build_object(

      'current_status', v_delivery.current_status, 'scheduled_date', v_delivery.scheduled_date,

      'quantity_delivered', v_delivery.quantity_delivered, 'paid', v_delivery.paid,

      'payment_method', v_delivery.payment_method, 'cash_pos_fee_snapshot', v_delivery.cash_pos_fee_snapshot

    ),

    jsonb_build_object(

      'current_status', p_to_status,

      'scheduled_date', v_final_date,

      'quantity_delivered', case when p_to_status = 'delivered' then coalesce(v_sum_delivered, p_quantity_delivered) else v_delivery.quantity_delivered end,

      'paid', case when p_to_status = 'delivered' then p_paid else v_delivery.paid end,

      'payment_method', case when p_to_status = 'delivered' then p_payment_method else v_delivery.payment_method end,

      'item_quantities', case when p_to_status = 'delivered' then v_eff_items else null end,

      'cash_pos_fee_snapshot', case

                                 when p_to_status = 'delivered' and p_payment_method = 'cash' and coalesce(p_paid, 0) > 0 then 500

                                 when p_to_status = 'delivered' then 0

                                 else v_delivery.cash_pos_fee_snapshot end

    ),

    p_reason

  );

end;

$$;


--
-- Name: check_customer_blacklist(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_customer_blacklist(p_phone text, p_phone_alt text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_hit  public.customer_blacklist;
  v_name text;
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  v_hit := public._customer_blacklist_hit(p_phone, p_phone_alt);
  if v_hit.id is null then return null; end if;
  select display_name into v_name from public.users where id = v_hit.added_by;
  return jsonb_build_object(
    'id', v_hit.id, 'phone_display', v_hit.phone_display, 'reason', v_hit.reason,
    'added_at', v_hit.added_at, 'added_by_name', v_name,
    'source_delivery_id', v_hit.source_delivery_id,
    'matched_on', case when v_hit.phone_normalized = public._norm_phone(p_phone)
                       then 'phone' else 'alt' end);
end;
$$;


--
-- Name: check_payment_client_contract(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_payment_client_contract() RETURNS void
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_headers jsonb; v_path text:=current_setting('request.path',true);
begin
  -- Trusted server integrations retain their own authorization and pay guards.
  if auth.role() is distinct from 'authenticated' then return; end if;
  -- Keep profile loading available so old native builds can show the updater.
  -- No delivery or financial data is returned by this narrow exception.
  if v_path='/users' and current_setting('request.method',true) in ('GET','HEAD') then return; end if;
  if not exists(select 1 from public.same_customer_pay_policy
      where active_from<=(now() at time zone 'Africa/Lagos')::date)
    and not exists(select 1 from public.same_customer_pay_policy_days where enabled) then return; end if;
  v_headers:=coalesce(nullif(current_setting('request.headers',true),'')::jsonb,'{}'::jsonb);
  if v_headers->>'x-reda-payment-contract' is distinct from '1' then
    raise sqlstate 'PT426' using message='Update REDA before continuing. Rider payment rules have changed.',
      detail='Refresh the web page, or restart the mobile app after its update downloads. Unsynced orders remain on your device.',
      hint='Payment client contract 1 is required.';
  end if;
end $$;


--
-- Name: claim_followup(uuid, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_followup(p_delivery_id uuid, p_takeover boolean DEFAULT false) RETURNS TABLE(held_by uuid, holder_name text, claimed_at timestamp with time zone, is_self boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user           uuid := auth.uid();
  v_role           text;
  v_status         text;
  v_needs_followup boolean;
  v_assigned_agent uuid;
  v_existing       public.delivery_followups%rowtype;
  v_is_new_claim   boolean := false;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;

  -- One read: status + its needs_followup flag + the assigned agent (used to
  -- decide whether there's anyone to notify). Source of truth for the flag is
  -- delivery_status_defs, not an inlined list.
  select d.current_status, coalesce(def.needs_followup, false), d.assigned_agent_id
    into v_status, v_needs_followup, v_assigned_agent
    from public.deliveries d
    left join public.delivery_status_defs def on def.status = d.current_status
   where d.id = p_delivery_id;
  if v_status is null then
    raise exception 'delivery not found' using errcode = 'P0002';
  end if;
  if not v_needs_followup then
    raise exception 'follow-up claims are only available for customer-follow-up statuses (got %)', v_status
      using errcode = '22023';
  end if;

  select * into v_existing
    from public.delivery_followups
   where delivery_id = p_delivery_id
   for update;

  -- Someone else already holds it, and caller did not pass takeover.
  if found and v_existing.user_id <> v_user and not p_takeover then
    return query
      select v_existing.user_id, u.display_name, v_existing.claimed_at, false
        from public.users u where u.id = v_existing.user_id;
    return;
  end if;

  -- Decide whether this call actually hands the claim to v_user. A brand-new
  -- claim or a takeover from someone else is a real hand-off worth telling the
  -- agent about; re-claiming a row the caller already holds is just a refresh.
  if not found then
    v_is_new_claim := true;
  elsif v_existing.user_id <> v_user and p_takeover then
    v_is_new_claim := true;
    -- Take-over: audit the swap before we overwrite.
    perform public.write_audit(
      'delivery_followup', p_delivery_id,
      jsonb_build_object('held_by', v_existing.user_id),
      jsonb_build_object('held_by', v_user),
      'takeover', null
    );
  end if;

  insert into public.delivery_followups (delivery_id, user_id)
    values (p_delivery_id, v_user)
    on conflict (delivery_id)
      do update set user_id = excluded.user_id, claimed_at = now();

  -- Tell the assigned agent an ops teammate is now on it. The delivery_messages
  -- insert trigger (notify_delivery_message) handles the push + thread entry.
  -- author_role is the caller's real role so the trigger routes ops -> agent.
  if v_is_new_claim and v_assigned_agent is not null then
    select role into v_role from public.users where id = v_user;
    insert into public.delivery_messages (
      delivery_id, author_id, author_role, note, client_uuid
    ) values (
      p_delivery_id, v_user, v_role, 'On it — I''ll handle this.', gen_random_uuid()
    );
  end if;

  -- Claiming is taking ownership, so clear the agent's unread for this delivery
  -- (ops caller → mark_messages_read clears agent-authored messages). Runs for
  -- every claim, even a re-claim with no new "On it" message.
  perform public.mark_messages_read(p_delivery_id);

  return query
    select v_user, u.display_name, now(), true
      from public.users u where u.id = v_user;
end $$;


--
-- Name: clear_client_ceiling(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_client_ceiling(p_id uuid, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old public.clients;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  select * into v_old from public.clients where id = p_id;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;

  update public.clients set max_charge_per_delivery = null where id = p_id;

  perform public.write_audit(
    'client', p_id,
    jsonb_build_object('max_charge_per_delivery', v_old.max_charge_per_delivery),
    jsonb_build_object('max_charge_per_delivery', null),
    coalesce(p_reason, 'clear charge ceiling')
  );
end;
$$;


--
-- Name: clear_delivery_location(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_delivery_location(p_delivery_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$

declare

  v_actor       uuid := auth.uid();

  v_row         public.deliveries%rowtype;

  v_is_terminal boolean;

begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);

  if not public.is_manager() then

    raise exception 'clear location requires admin or dispatcher role'

      using errcode = '42501';

  end if;



  if p_reason is null or btrim(p_reason) = '' then

    raise exception 'reason required for clear_location' using errcode = '22023';

  end if;



  select * into v_row from public.deliveries where id = p_delivery_id for update;

  if not found then

    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';

  end if;

  if v_row.deleted_at is not null then

    raise exception 'cannot clear location on a deleted delivery' using errcode = '22023';

  end if;



  select category = 'terminal' into v_is_terminal

    from public.delivery_status_defs

   where status = v_row.current_status;

  if v_is_terminal is true then

    raise exception 'cannot clear location on a terminal delivery (status=%)', v_row.current_status

      using errcode = '22023',

            hint   = 'use correct_delivery_location to repoint a delivered row''s zone';

  end if;



  if v_row.location_id is null then

    raise exception 'delivery location is already unset' using errcode = '22023';

  end if;



  update public.deliveries

     set location_id = null,

         updated_at  = now()

   where id = p_delivery_id;



  perform public.write_audit(

    p_actor_id    := v_actor,

    p_entity_type := 'delivery',

    p_entity_id   := p_delivery_id,

    p_old         := jsonb_build_object('location_id', v_row.location_id),

    p_new         := jsonb_build_object('location_id', null),

    p_reason      := 'clear_location: ' || btrim(p_reason)

  );

end;

$$;


--
-- Name: FUNCTION clear_delivery_location(p_delivery_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.clear_delivery_location(p_delivery_id uuid, p_reason text) IS 'Admin/dispatcher/rep: clear location_id on a non-terminal delivery so admin can wait for clarification. Reason required; audit-logged with reason ''clear_location: <text>''. Snapshots stay until the next location set re-snapshots them via update_delivery_fields.';


--
-- Name: clear_same_customer_manual_fee(uuid, uuid, bigint, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.clear_same_customer_manual_fee(p_request_id uuid, p_delivery_id uuid, p_expected_revision bigint, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare e public.same_customer_earnings%rowtype; r public.same_customer_fee_decisions%rowtype;
begin
  if not public.is_admin() then raise exception 'admin role required for manual-pay correction' using errcode='42501'; end if;
  if p_request_id is null or p_delivery_id is null or p_expected_revision is null or nullif(btrim(p_reason),'') is null or length(btrim(p_reason))>2000 then
    raise exception 'request, delivery, revision and reason required' using errcode='22023'; end if;
  perform public._same_customer_lock_orders(array[p_delivery_id]);
  perform pg_advisory_xact_lock(hashtextextended('same-customer-fee-decision:'||p_request_id::text,0));
  select * into r from public.same_customer_fee_decisions where request_id=p_request_id;
  if found then
    if (r.actor_id,r.delivery_id,r.expected_revision,r.reason,r.source)
      is distinct from (auth.uid(),p_delivery_id,p_expected_revision,btrim(p_reason),'clear_exception'::text) then
      raise exception 'request id already used for another correction' using errcode='22023'; end if;
    return;
  end if;
  perform id from public.deliveries where id=p_delivery_id for update;
  select * into e from public.same_customer_earnings where delivery_id=p_delivery_id;
  if not found or not e.active then raise exception 'active earning required' using errcode='22023'; end if;
  if e.revision<>p_expected_revision then raise exception 'earning changed; refresh before correcting' using errcode='40001'; end if;
  if e.manual_amount is null then raise exception 'there is no manual exception to clear' using errcode='22023'; end if;
  if exists(select 1 from public.same_customer_earnings x join public.settlements s
    on s.subject_type='agent' and s.subject_id=x.rider_id and s.period_date=x.accounting_date and s.voided_at is null
    where x.active and (x.delivery_id=e.delivery_id or x.group_id=e.group_id)) then
    raise exception 'affected rider period is settled; resolve settlement before clearing the exception' using errcode='22023'; end if;
  insert into public.same_customer_fee_decisions(delivery_id,amount,reason,actor_id,source,request_id,expected_revision)
    values(p_delivery_id,null,btrim(p_reason),auth.uid(),'clear_exception',p_request_id,p_expected_revision);
  perform public._sync_same_customer_shadow(p_delivery_id);
end $$;


--
-- Name: client_account_balances(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.client_account_balances(p_from date, p_to date) RETURNS TABLE(client_id uuid, is_initialized boolean, effective_date date, configured_opening_balance numeric, balance_before_period numeric, period_activity numeric, payouts_in_period numeric, current_balance numeric, payments_in_period numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  if p_from is null or p_to is null or p_from > p_to then
    raise exception 'valid from/to dates required' using errcode = '22023';
  end if;

  return query
  with recursive openings as (
    select c.id as client_id, o.effective_date, o.opening_balance
      from public.clients c
      left join public.client_balance_openings o on o.client_id = c.id
  ), payout_events as (
    select p.client_id, p.payout_date as event_date, p.amount
      from public.client_payouts p
     where p.voided_at is null
    union all
    -- Before this ledger existed, a positive client settlement represented an
    -- actual bank transfer. Preserve it as a payout during incremental cutover.
    select s.subject_id, s.period_date, s.expected_amount
      from public.settlements s
     where s.subject_type = 'client'
       and s.voided_at is null
       and s.expected_amount > 0
  ), payment_events as (
    -- Money the vendor sent Reda. Reduces their debt on the day it arrived.
    select p.client_id, p.payment_date as event_date, p.amount
      from public.client_payments p
     where p.voided_at is null
  ), daily_events as (
    select
      e.client_id,
      e.event_date,
      sum(e.activity) as activity,
      sum(e.payout) as payout,
      sum(e.payment) as payment
    from (
      select a.client_id, a.activity_date as event_date,
             a.amount as activity, 0::numeric as payout, 0::numeric as payment
        from public.client_financial_activity a
        join openings o on o.client_id = a.client_id
       where o.effective_date is not null
         and a.activity_date between o.effective_date and p_to
      union all
      select pe.client_id, pe.event_date, 0::numeric, pe.amount, 0::numeric
        from payout_events pe
        join openings o on o.client_id = pe.client_id
       where o.effective_date is not null
         and pe.event_date between o.effective_date and p_to
      union all
      select pm.client_id, pm.event_date, 0::numeric, 0::numeric, pm.amount
        from payment_events pm
        join openings o on o.client_id = pm.client_id
       where o.effective_date is not null
         and pm.event_date between o.effective_date and p_to
    ) e
    group by e.client_id, e.event_date
  ), daily_ledger(client_id, balance_date, closing_balance) as (
    select
      o.client_id,
      o.effective_date,
      o.opening_balance
        + coalesce(e.activity, 0) - coalesce(e.payout, 0) + coalesce(e.payment, 0)
    from openings o
    left join daily_events e
      on e.client_id = o.client_id and e.event_date = o.effective_date
    where o.effective_date is not null and o.effective_date <= p_to

    union all

    -- Only a negative close carries: a positive close is paid out through the
    -- external Kuda batch the same evening.
    select
      l.client_id,
      l.balance_date + 1,
      least(l.closing_balance, 0)
        + coalesce(e.activity, 0) - coalesce(e.payout, 0) + coalesce(e.payment, 0)
    from daily_ledger l
    left join daily_events e
      on e.client_id = l.client_id and e.event_date = l.balance_date + 1
    where l.balance_date < p_to
  ), period_activity_totals as (
    select
      o.client_id,
      coalesce(sum(a.amount), 0) as amount
    from openings o
    left join public.client_financial_activity a
      on a.client_id = o.client_id
     and a.activity_date between greatest(o.effective_date, p_from) and p_to
    where o.effective_date <= p_to
    group by o.client_id
  ), period_payout_totals as (
    select
      o.client_id,
      coalesce(sum(pe.amount), 0) as amount
    from openings o
    left join payout_events pe
      on pe.client_id = o.client_id
     and pe.event_date between greatest(o.effective_date, p_from) and p_to
    where o.effective_date <= p_to
    group by o.client_id
  ), period_payment_totals as (
    select
      o.client_id,
      coalesce(sum(pm.amount), 0) as amount
    from openings o
    left join payment_events pm
      on pm.client_id = o.client_id
     and pm.event_date between greatest(o.effective_date, p_from) and p_to
    where o.effective_date <= p_to
    group by o.client_id
  )
  select
    o.client_id,
    (o.effective_date is not null and o.effective_date <= p_to),
    o.effective_date,
    case when o.effective_date <= p_to then o.opening_balance else null end,
    case
      when o.effective_date is null or o.effective_date > p_to then 0
      when o.effective_date = p_from then o.opening_balance
      when o.effective_date > p_from then 0
      else coalesce((
        select least(l.closing_balance, 0)
          from daily_ledger l
         where l.client_id = o.client_id and l.balance_date = p_from - 1
      ), 0)
    end,
    case when o.effective_date <= p_to then coalesce(a.amount, 0) else 0 end,
    case when o.effective_date <= p_to then coalesce(pt.amount, 0) else 0 end,
    case when o.effective_date <= p_to then coalesce((
      select l.closing_balance
        from daily_ledger l
       where l.client_id = o.client_id and l.balance_date = p_to
    ), 0) else 0 end,
    case when o.effective_date <= p_to then coalesce(pm.amount, 0) else 0 end
  from openings o
  left join period_activity_totals a on a.client_id = o.client_id
  left join period_payout_totals pt on pt.client_id = o.client_id
  left join period_payment_totals pm on pm.client_id = o.client_id;
end;
$$;


--
-- Name: client_payment_limit(uuid, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.client_payment_limit(p_client_id uuid, p_date date) RETURNS numeric
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_opening_date date;
  v_before numeric;
  v_charges numeric;
  v_paid numeric;
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  if p_client_id is null or p_date is null then
    raise exception 'client and date required' using errcode = '22023';
  end if;

  select o.effective_date into v_opening_date
    from public.client_balance_openings o where o.client_id = p_client_id;
  if v_opening_date is null or p_date < v_opening_date then
    return 0;
  end if;

  select b.balance_before_period into v_before
    from public.client_account_balances(p_date, p_date) b
   where b.client_id = p_client_id;

  select coalesce(-sum(a.amount), 0) into v_charges
    from public.client_financial_activity a
   where a.client_id = p_client_id
     and a.activity_date = p_date
     and a.amount < 0;

  select coalesce(sum(p.amount), 0) into v_paid
    from public.client_payments p
   where p.client_id = p_client_id
     and p.payment_date = p_date
     and p.voided_at is null;

  return greatest(0, greatest(0, -coalesce(v_before, 0)) + v_charges - v_paid);
end;
$$;


--
-- Name: client_remit_detail(uuid, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.client_remit_detail(p_client_id uuid, p_from date, p_to date) RETURNS TABLE(delivery_id uuid, scheduled_date date, customer_name text, customer_phone text, product_name text, location_name text, quantity_ordered numeric, quantity_delivered numeric, customer_price numeric, paid numeric, payment_method text, reda_fee numeric, cash_pos_fee numeric, remit numeric, agent_name text, products jsonb, client_rep text, order_type text, note text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select
    d.id, d.scheduled_date, d.customer_name, d.customer_phone,
    p.product_name, l.name,
    d.quantity_ordered,
    d.quantity_delivered,
    d.customer_price,
    d.paid,
    d.payment_method,
    coalesce(d.charged_snapshot, 0)                                 as reda_fee,
    coalesce(d.cash_pos_fee_snapshot, 0)                            as cash_pos_fee,
    coalesce(d.paid, 0)
      - coalesce(d.charged_snapshot, 0)
      - coalesce(d.cash_pos_fee_snapshot, 0)                        as remit,
    u.display_name                                                  as agent_name,
    coalesce(
      (select jsonb_agg(
                jsonb_build_object(
                  'product_name', pc.product_name,
                  'quantity_ordered', di.quantity_ordered,
                  'quantity_delivered', coalesce(di.quantity_delivered, di.quantity_ordered)
                )
                order by di.created_at, pc.product_name)
       from public.delivery_items di
       join public.product_catalog pc on pc.id = di.product_catalog_id
       where di.delivery_id = d.id),
      case when d.order_type = 'waybill' then '[]'::jsonb
           else jsonb_build_array(
             jsonb_build_object(
               'product_name', p.product_name,
               'quantity_ordered', d.quantity_ordered,
               'quantity_delivered', d.quantity_delivered
             ))
      end
    )                                                              as products,
    d.client_rep,
    d.order_type,
    case when d.order_type = 'waybill' then (
      select dm.note
        from public.delivery_messages dm
       where dm.delivery_id = d.id
         and nullif(btrim(dm.note), '') is not null
       order by dm.created_at asc
       limit 1
    ) else null end                                                as note
  from public.deliveries d
  left join public.product_catalog p on p.id = d.product_catalog_id
  left join public.locations       l on l.id = d.location_id
  left join public.users           u on u.id = d.assigned_agent_id
  where d.client_id      = p_client_id
    and d.current_status = 'delivered'
    and d.scheduled_date >= p_from
    and d.scheduled_date <= p_to
    and d.deleted_at is null
    and public.is_admin_or_dispatcher()
  order by d.scheduled_date desc, d.created_at desc;
$$;


--
-- Name: client_remit_detail_rep(uuid, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.client_remit_detail_rep(p_client_id uuid, p_from date, p_to date) RETURNS TABLE(delivery_id uuid, scheduled_date date, customer_name text, customer_phone text, product_name text, location_name text, quantity_ordered numeric, quantity_delivered numeric, outstanding numeric, remit numeric, agent_name text, products jsonb, payment_method text, cash_pos_fee numeric, client_rep text, order_type text, note text, paid numeric, reda_fee numeric)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select
    delivery_id, scheduled_date, customer_name, customer_phone,
    product_name, location_name,
    quantity_ordered, quantity_delivered,
    case when payment_method = 'vendor_direct' then 0
         else coalesce(customer_price, 0) - coalesce(paid, 0) end as outstanding,
    remit, agent_name, products,
    payment_method,
    coalesce(cash_pos_fee, 0) as cash_pos_fee,
    client_rep,
    order_type,
    note,
    -- Karami only ('2acf7d84…' = Karami). NULL for every other client keeps
    -- Reda's delivery fee hidden from reps.
    case when p_client_id = '2acf7d84-3a5c-4532-b47c-568b7f4928f3' then paid end as paid,
    case when p_client_id = '2acf7d84-3a5c-4532-b47c-568b7f4928f3' then reda_fee end as reda_fee
  from public.client_remit_detail(p_client_id, p_from, p_to);
$$;


--
-- Name: client_remit_summary(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.client_remit_summary(p_from date, p_to date) RETURNS TABLE(client_id uuid, client_name text, deliveries_count bigint, total_quantity numeric, total_customer_price numeric, total_paid numeric, outstanding numeric, total_reda_fee numeric, total_cash_pos_fee numeric, total_remit numeric)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select
    c.id   as client_id,
    c.name as client_name,
    count(d.id) filter (where d.id is not null)               as deliveries_count,
    coalesce(sum(d.quantity_delivered), 0)                    as total_quantity,
    coalesce(sum(d.customer_price), 0)                        as total_customer_price,
    coalesce(sum(d.paid), 0)                                  as total_paid,
    coalesce(sum(
      case when d.payment_method = 'vendor_direct' then 0
           else coalesce(d.customer_price, 0) - coalesce(d.paid, 0) end
    ), 0)                                                     as outstanding,
    coalesce(sum(d.charged_snapshot), 0)                      as total_reda_fee,
    coalesce(sum(d.cash_pos_fee_snapshot), 0)                 as total_cash_pos_fee,
    coalesce(sum(d.paid), 0)
      - coalesce(sum(d.charged_snapshot), 0)
      - coalesce(sum(d.cash_pos_fee_snapshot), 0)             as total_remit
  from public.clients c
  left join public.deliveries d
    on d.client_id        = c.id
   and d.current_status   = 'delivered'
   and d.scheduled_date  >= p_from
   and d.scheduled_date  <= p_to
   and d.deleted_at is null
  where public.is_admin_or_dispatcher()
  group by c.id, c.name
  having count(d.id) > 0
  order by c.name;
$$;


--
-- Name: client_remit_summary_rep(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.client_remit_summary_rep(p_from date, p_to date) RETURNS TABLE(client_id uuid, client_name text, deliveries_count bigint, total_quantity numeric, total_remit numeric)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select client_id, client_name, deliveries_count, total_quantity, total_remit
  from public.client_remit_summary(p_from, p_to)
  where deliveries_count > 0;
$$;


--
-- Name: complete_replacement(text, uuid, jsonb, text, numeric, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.complete_replacement(p_client_uuid text, p_delivery_id uuid, p_return_outcomes jsonb, p_notes text DEFAULT NULL::text, p_customer_paid numeric DEFAULT 0, p_payment_method text DEFAULT NULL::text, p_payment_received_by text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_delivery record;
  v_job record;
  v_line record;
  v_return record;
  v_payload jsonb;
  v_outcome text;
  v_qty integer;
  v_state text;
  v_condition text;
  v_on_hand integer;
  v_total integer := 0;
  v_fee numeric;
begin
  if nullif(trim(p_client_uuid), '') is null then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  perform 1 from public.deliveries where id=p_delivery_id for update;
  if exists (select 1 from public.replacement_attempts where client_uuid = p_client_uuid) then
    return;
  end if;
  v_fee := public._validate_replacement_payment(p_customer_paid, p_payment_method, p_payment_received_by);
  if public.current_user_role()='agent' and p_customer_paid>0 and p_payment_received_by<>'rider' then
    raise exception 'Riders may only record money they received' using errcode='42501';
  end if;
  select d.* into v_delivery from public.deliveries d
   where d.id = p_delivery_id for update;
  select * into v_job from public.replacement_jobs where delivery_id = p_delivery_id;
  if v_delivery.id is null or v_job.delivery_id is null then
    raise exception 'replacement not found' using errcode = 'P0002';
  end if;
  if not (public.is_manager() or (
    public.current_user_role() = 'agent' and v_delivery.assigned_agent_id = v_actor
  )) then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  if v_delivery.assigned_agent_id is null then
    raise exception 'assign an agent before completing this replacement' using errcode = '23514';
  end if;
  if v_delivery.current_status = 'replacement_completed' then return; end if;
  if exists (select 1 from public.settlements where voided_at is null
    and period_date=(now() at time zone 'Africa/Lagos')::date
    and ((subject_type='client' and subject_id=v_delivery.client_id) or
         (subject_type='agent' and subject_id=v_delivery.assigned_agent_id))) then
    raise exception 'This date is already settled; void the settlement before completing the replacement' using errcode='22023';
  end if;

  if exists (
    select 1 from public.delivery_status_defs
     where status = v_delivery.current_status and category = 'terminal'
  ) then
    raise exception 'replacement is closed; reopen it before completing'
      using errcode = '22023';
  end if;
  if jsonb_typeof(p_return_outcomes) <> 'array' then
    raise exception 'return outcomes must be an array' using errcode = '23514';
  end if;
  if (select count(*) from public.replacement_return_items where delivery_id = p_delivery_id)
     <> jsonb_array_length(p_return_outcomes) then
    raise exception 'record an outcome for every expected returned item' using errcode = '23514';
  end if;

  -- Validate every outbound line before moving any stock.
  for v_line in select * from public.delivery_items where delivery_id = p_delivery_id
  loop
    select coalesce(quantity_on_hand, 0) into v_on_hand
      from public.current_stock
     where agent_id = v_delivery.assigned_agent_id
       and product_catalog_id = v_line.product_catalog_id;
    if coalesce(v_on_hand, 0) < v_line.quantity_ordered then
      raise exception 'insufficient_stock: rider has % units, replacement needs %',
        coalesce(v_on_hand, 0), v_line.quantity_ordered
        using errcode = 'P0001',
              hint = jsonb_build_object(
                'code','insufficient_stock', 'product_catalog_id', v_line.product_catalog_id,
                'on_hand',coalesce(v_on_hand,0), 'needed',v_line.quantity_ordered
              )::text;
    end if;
  end loop;

  for v_return in
    select * from public.replacement_return_items where delivery_id = p_delivery_id for update
  loop
    select value into v_payload from jsonb_array_elements(p_return_outcomes)
     where value->>'return_item_id' = v_return.id::text limit 1;
    if v_payload is null then
      raise exception 'missing return outcome for %', v_return.id using errcode = '23514';
    end if;
    v_outcome := v_payload->>'outcome';
    v_qty := coalesce(nullif(v_payload->>'quantity', '')::integer, 0);
    if v_outcome not in ('usable_collected','damaged_collected','left_with_customer','discarded') then
      raise exception 'invalid return outcome' using errcode = '23514';
    end if;
    if v_qty < 0 or v_qty > v_return.quantity_expected then
      raise exception 'return quantity must be between 0 and %', v_return.quantity_expected using errcode = '23514';
    end if;
    if v_outcome in ('usable_collected','damaged_collected') and v_qty = 0 then
      raise exception 'collected return quantity must be positive' using errcode = '23514';
    end if;
    if v_outcome = 'usable_collected' then
      v_state := 'with_rider_usable_pending_inspection'; v_condition := 'usable';
    elsif v_outcome = 'damaged_collected' then
      v_state := 'with_rider_damaged_hold'; v_condition := 'damaged';
    elsif v_outcome = 'left_with_customer' then
      v_state := 'left_with_customer'; v_condition := 'unknown';
    else
      v_state := 'discarded'; v_condition := 'damaged';
    end if;
    update public.replacement_return_items
       set actual_quantity = v_qty,
           reported_condition = v_condition,
           outcome = v_outcome,
           custody_state = v_state,
           current_holder_id = case
             when v_outcome in ('usable_collected','damaged_collected')
               then v_delivery.assigned_agent_id else null end,
           rider_notes = nullif(trim(v_payload->>'notes'), ''),
           collected_at = now(), updated_at = now()
     where id = v_return.id;
    insert into public.replacement_return_events(
      client_uuid, return_item_id, event_type, from_holder_id, to_holder_id, quantity,
      condition, notes, actor_user_id
    ) values (
      p_client_uuid || ':return:' || v_return.id::text, v_return.id,
      case when v_outcome in ('usable_collected','damaged_collected') then 'collected'
           when v_outcome = 'discarded' then 'discarded' else 'not_collected' end,
      null,
      case when v_outcome in ('usable_collected','damaged_collected')
           then v_delivery.assigned_agent_id else null end,
      v_qty, v_condition, nullif(trim(v_payload->>'notes'), ''), v_actor
    );
  end loop;

  for v_line in select * from public.delivery_items where delivery_id = p_delivery_id
  loop
    insert into public.stock_adjustments(
      agent_id, product_catalog_id, quantity_delta, reason, notes,
      client_uuid, created_by_user_id, delivery_id
    ) values (
      v_delivery.assigned_agent_id, v_line.product_catalog_id,
      -v_line.quantity_ordered, 'replacement_outbound',
      'Replacement sent to ' || v_delivery.customer_name,
      p_client_uuid || ':out:' || v_line.product_catalog_id::text,
      v_actor, p_delivery_id
    );
    update public.delivery_items set quantity_delivered = quantity_ordered
     where id = v_line.id;
    v_total := v_total + v_line.quantity_ordered;
  end loop;

  insert into public.replacement_attempts(
    delivery_id, client_uuid, outcome, status_after, notes,
    customer_paid, payment_method, payment_received_by, cash_pos_fee,
    client_charge, agent_payment, assigned_agent_id, attempted_by_user_id
  ) values (
    p_delivery_id, p_client_uuid, 'completed', 'replacement_completed',
    nullif(trim(p_notes), ''), p_customer_paid,
    case when p_customer_paid > 0 then p_payment_method
         when p_payment_method = 'vendor_direct' then 'vendor_direct' end,
    case when p_customer_paid > 0 then p_payment_received_by end,
    v_fee,
    v_job.success_client_charge,
    v_job.success_agent_payment, v_delivery.assigned_agent_id, v_actor
  );
  insert into public.delivery_status_history(
    delivery_id, from_status, to_status, changed_by_user_id, client_uuid,
    effective_at, reason, notes
  ) values (
    p_delivery_id, v_delivery.current_status, 'replacement_completed', v_actor,
    p_client_uuid, now(), 'replacement_completed', nullif(trim(p_notes), '')
  );
  update public.deliveries
     set current_status = 'replacement_completed',
         quantity_delivered = v_total,
         paid = 0, -- Replacement payments live on the attempt, not the product-sale ledger.
         payment_method = null,
         charged_snapshot = coalesce(charged_snapshot, 0) + v_job.success_client_charge,
         agent_payment_snapshot = coalesce(agent_payment_snapshot, 0) + v_job.success_agent_payment
   where id = p_delivery_id;
end;
$$;


--
-- Name: configure_same_customer_pay(text, date, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.configure_same_customer_pay(p_action text, p_day date, p_release_reference text, p_reason text) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
declare v_before jsonb; v_after jsonb; v_start date;
begin
  if p_action is null or p_action not in ('schedule','suspend')
    or p_day is null or p_day<=(clock_timestamp() at time zone 'Africa/Lagos')::date
    or nullif(btrim(p_release_reference),'') is null or nullif(btrim(p_reason),'') is null then
    raise exception 'future Lagos day, release reference and reason required' using errcode='22023';
  end if;
  select to_jsonb(p),active_from into strict v_before,v_start
    from public.same_customer_pay_policy p where singleton for update;
  if p_action='schedule' then
    if v_start is not null or exists(select 1 from public.same_customer_pay_policy_days where enabled) then
      raise exception 'payment policy was already scheduled; do not reprice enrolled days' using errcode='22023';
    end if;
    update public.same_customer_pay_policy set active_from=p_day,inactive_from=null where singleton;
  else
    if v_start is null or p_day<=v_start then
      raise exception 'suspension must follow the scheduled start' using errcode='22023';
    end if;
    update public.same_customer_pay_policy set inactive_from=p_day where singleton;
  end if;
  select to_jsonb(p) into v_after from public.same_customer_pay_policy p where singleton;
  insert into public.same_customer_policy_audit(action,effective_day,release_reference,reason,before_policy,after_policy)
    values(p_action,p_day,btrim(p_release_reference),btrim(p_reason),v_before,v_after);
end $$;


--
-- Name: correct_delivery_charge(uuid, numeric, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.correct_delivery_charge(p_delivery_id uuid, p_charged numeric, p_agent_payment numeric, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor          uuid := auth.uid();
  v_row            public.deliveries%rowtype;
  v_charge_changed boolean;
  v_agent_changed  boolean;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if not public.is_admin() then
    raise exception 'correcting delivery charges requires admin role'
      using errcode = '42501';
  end if;

  if p_charged is null or p_agent_payment is null then
    raise exception 'both charge and agent payment are required' using errcode = '22023';
  end if;
  if p_charged < 0 or p_agent_payment < 0 then
    raise exception 'charge and agent payment must be >= 0' using errcode = '23514';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required for a charge correction' using errcode = '22023';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_row.deleted_at is not null then
    raise exception 'cannot correct a deleted delivery' using errcode = '22023';
  end if;

  v_charge_changed := p_charged       is distinct from v_row.charged_snapshot;
  v_agent_changed  := p_agent_payment is distinct from v_row.agent_payment_snapshot;

  -- No-op guard: nothing to change.
  if not v_charge_changed and not v_agent_changed then
    raise exception 'charges are unchanged' using errcode = '22023';
  end if;

  -- Settled-side guard: refuse to edit a snapshot whose settlement is frozen.
  -- The figures were remitted from the old value; correcting them here would
  -- desync the live reconcile view from what was actually settled/paid.
  if v_charge_changed and exists (
    select 1 from public.settlements s
     where s.subject_type = 'client'
       and s.subject_id   = v_row.client_id
       and s.period_date  = v_row.scheduled_date
       and s.voided_at is null
  ) then
    raise exception
      'cannot change the Reda charge: the client is already settled for %', v_row.scheduled_date
      using errcode = '23505',
            hint   = 'void the client settlement for this day, then correct and re-settle';
  end if;

  if v_agent_changed and exists (
    select 1 from public.settlements s
     where s.subject_type = 'agent'
       and s.subject_id   = v_row.assigned_agent_id
       and s.period_date  = v_row.scheduled_date
       and s.voided_at is null
  ) then
    raise exception
      'cannot change the agent payout: the agent is already settled for %', v_row.scheduled_date
      using errcode = '23505',
            hint   = 'void the agent settlement for this day, then correct and re-settle';
  end if;

  if v_agent_changed then
    perform public._same_customer_record_manual_fee(p_delivery_id,p_agent_payment,p_reason);
  end if;
  update public.deliveries
     set charged_snapshot       = p_charged,
         agent_payment_snapshot = p_agent_payment,
         agent_payment_base_snapshot = case when v_agent_changed and public._same_customer_track_manual_fee(v_row) then public._same_customer_normal_fee(v_row) else agent_payment_base_snapshot end,
         agent_payment_base_captured_at = case when v_agent_changed and public._same_customer_track_manual_fee(v_row) then clock_timestamp() else agent_payment_base_captured_at end,
         updated_at             = now()
   where id = p_delivery_id;

  perform public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := jsonb_build_object(
      'charged_snapshot',       v_row.charged_snapshot,
      'agent_payment_snapshot', v_row.agent_payment_snapshot
    ),
    p_new         := jsonb_build_object(
      'charged_snapshot',       p_charged,
      'agent_payment_snapshot', p_agent_payment
    ),
    p_reason      := 'charge_correction: ' || btrim(p_reason)
  );
end;
$$;


--
-- Name: correct_delivery_customer_match(uuid, text, jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.correct_delivery_customer_match(p_request_id uuid, p_action text, p_orders jsonb, p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_ids uuid[]; v_key uuid:=gen_random_uuid(); v_row record; v_prior record; v_result jsonb; v_before jsonb;
begin
  if not public.is_manager() then raise exception 'manager role required' using errcode='42501'; end if;
  if p_request_id is null or p_action is null or p_action not in ('link','split','reset')
    or nullif(btrim(p_reason),'') is null or jsonb_typeof(p_orders) is distinct from 'array' then
    raise exception 'request, action, orders and reason required' using errcode='22023'; end if;
  if jsonb_array_length(p_orders)<1 or jsonb_array_length(p_orders)>100 then
    raise exception 'select between 1 and 100 orders' using errcode='22023'; end if;
  if exists(select 1 from jsonb_array_elements(p_orders) o
      where o->>'id' is null or o->>'revision' is null) then
    raise exception 'order id and expected revision required' using errcode='22023'; end if;
  select array_agg(distinct (o->>'id')::uuid order by (o->>'id')::uuid) into v_ids
    from jsonb_array_elements(p_orders) o;
  if cardinality(v_ids)<>jsonb_array_length(p_orders) or (p_action='link' and cardinality(v_ids)<2) then
    raise exception 'select distinct orders; linking requires at least two' using errcode='22023'; end if;
  perform public._same_customer_lock_orders(v_ids); perform pg_advisory_xact_lock(hashtextextended('same-customer-request:' || p_request_id::text,0));
  select * into v_prior from public.same_customer_decisions where request_id=p_request_id;
  if found then
    if v_prior.actor_id<>auth.uid() or v_prior.action<>p_action or v_prior.delivery_ids<>v_ids
      or v_prior.request_orders<>p_orders or v_prior.reason<>btrim(p_reason) then
      raise exception 'request id already used for a different decision' using errcode='23505'; end if;
    return v_prior.result;
  end if;
  if (select count(*) from public.deliveries where id=any(v_ids) and deleted_at is null and order_type='delivery')<>cardinality(v_ids) then
    raise exception 'an order is missing, deleted or unsupported' using errcode='22023'; end if;
  for v_row in select d.* from public.deliveries d where d.id=any(v_ids) order by d.id for update loop
    if v_row.deleted_at is not null or v_row.order_type<>'delivery' then
      raise exception 'an order changed; refresh before trying again' using errcode='40001'; end if;
    if v_row.same_customer_match_revision<>(select (o->>'revision')::bigint from jsonb_array_elements(p_orders) o where (o->>'id')::uuid=v_row.id) then
      raise exception 'customer match changed; refresh before trying again' using errcode='40001'; end if;
    if v_row.current_status='delivered' and exists(select 1 from public.settlements s
      where s.subject_type='agent' and s.subject_id=v_row.assigned_agent_id
        and s.period_date=v_row.scheduled_date and s.voided_at is null) then
      raise exception 'rider period is settled; void and correct the settlement first' using errcode='23505'; end if;
  end loop;
  select jsonb_agg(jsonb_build_object('id',id,'key_override',same_customer_key_override,
    'mode',same_customer_match_mode,'revision',same_customer_match_revision) order by id)
    into v_before from public.deliveries where id=any(v_ids);
  if to_regprocedure('public._lock_same_customer_shadow_for_orders(uuid[])') is not null then
    perform public._lock_same_customer_shadow_for_orders(v_ids);
  end if;
  update public.deliveries set
    same_customer_key_override=case p_action when 'link' then v_key when 'split' then gen_random_uuid() else null end,
    same_customer_match_mode=case p_action when 'link' then 'linked' when 'split' then 'separate' else 'auto' end,
    same_customer_match_revision=same_customer_match_revision+1
  where id=any(v_ids);
  v_result:=jsonb_build_object('updated_count',cardinality(v_ids));
  insert into public.same_customer_decisions(request_id,actor_id,action,delivery_ids,request_orders,reason,result)
    values(p_request_id,auth.uid(),p_action,v_ids,p_orders,btrim(p_reason),v_result);
  perform public.write_audit(p_actor_id:=auth.uid(),p_entity_type:='same_customer',p_entity_id:=p_request_id,
    p_old:=jsonb_build_object('orders',v_before),
    p_new:=jsonb_build_object('action',p_action,'delivery_ids',v_ids,'orders',
      (select jsonb_agg(jsonb_build_object('id',id,'key_override',same_customer_key_override,
        'mode',same_customer_match_mode,'revision',same_customer_match_revision) order by id)
        from public.deliveries where id=any(v_ids))),p_reason:=btrim(p_reason));
  return v_result;
end $$;


--
-- Name: correct_delivery_location(uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.correct_delivery_location(p_delivery_id uuid, p_location_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor          uuid := auth.uid();
  v_row            public.deliveries%rowtype;
  v_charged        numeric;
  v_agent_payment  numeric;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if not public.is_admin() then
    raise exception 'correcting a delivered location requires admin role'
      using errcode = '42501';
  end if;

  if p_location_id is null then
    raise exception 'a target location is required' using errcode = '22023';
  end if;

  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required for location correction' using errcode = '22023';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_row.deleted_at is not null then
    raise exception 'cannot correct a deleted delivery' using errcode = '22023';
  end if;

  -- Status gate: this RPC exists ONLY for the locked delivered case. Anything
  -- still editable goes through the Edit screen (update_delivery_fields);
  -- other terminal states never feed remit so there is nothing to correct.
  if v_row.current_status <> 'delivered' then
    raise exception
      'location correction only applies to delivered rows (status=%); edit pre-delivery rows via the Edit screen',
      v_row.current_status
      using errcode = '22023';
  end if;

  if p_location_id = v_row.location_id then
    raise exception 'location is unchanged' using errcode = '22023';
  end if;

  -- Re-snapshot from the corrected location. Keyed on (location, client, agent)
  -- exactly like update_delivery_fields; passing assigned_agent_id reapplies
  -- the agent bonus. Raise loudly if the new combo has no active rate card so
  -- we never overwrite a real snapshot with NULL.
  select er.charged, er.agent_payment
    into v_charged, v_agent_payment
    from public.effective_rate(p_location_id, v_row.client_id, v_row.assigned_agent_id) er;
  if v_charged is null then
    raise exception
      'no active rate card for (location=%, client=%); add one before correcting',
      p_location_id, v_row.client_id
      using errcode = '22023',
            hint   = 'add a rate_card row for this location/client first';
  end if;

  update public.deliveries
     set location_id            = p_location_id,
         charged_snapshot       = v_charged,
         agent_payment_snapshot = v_agent_payment,
         agent_payment_base_snapshot = v_agent_payment,
         agent_payment_base_captured_at = clock_timestamp(),
         updated_at             = now()
   where id = p_delivery_id;

  perform public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := jsonb_build_object(
      'location_id',            v_row.location_id,
      'charged_snapshot',       v_row.charged_snapshot,
      'agent_payment_snapshot', v_row.agent_payment_snapshot
    ),
    p_new         := jsonb_build_object(
      'location_id',            p_location_id,
      'charged_snapshot',       v_charged,
      'agent_payment_snapshot', v_agent_payment
    ),
    p_reason      := 'location_correction: ' || btrim(p_reason)
  );
end;
$$;


--
-- Name: FUNCTION correct_delivery_location(p_delivery_id uuid, p_location_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.correct_delivery_location(p_delivery_id uuid, p_location_id uuid, p_reason text) IS 'Admin: correct the location on a DELIVERED row and re-snapshot charged_snapshot + agent_payment_snapshot from the new location''s rate. Reason required; audit-logged with reason ''location_correction: <text>''.';


--
-- Name: correct_delivery_reda_charge(uuid, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.correct_delivery_reda_charge(p_delivery_id uuid, p_charged numeric, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_row public.deliveries%rowtype;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if not public.is_manager() then
    raise exception 'correcting a Reda charge requires admin or dispatcher role'
      using errcode = '42501';
  end if;
  if p_charged is null or p_charged < 0 then
    raise exception 'Reda charge must be a non-negative number' using errcode = '23514';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required for a Reda charge correction' using errcode = '22023';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_row.deleted_at is not null then
    raise exception 'cannot correct a deleted delivery' using errcode = '22023';
  end if;
  if p_charged is not distinct from v_row.charged_snapshot then
    raise exception 'Reda charge is unchanged' using errcode = '22023';
  end if;
  if exists (
    select 1 from public.settlements s
     where s.subject_type = 'client'
       and s.subject_id = v_row.client_id
       and s.period_date = v_row.scheduled_date
       and s.voided_at is null
  ) then
    raise exception 'cannot change the Reda charge: the client is already settled for %',
      v_row.scheduled_date
      using errcode = '23505',
            hint = 'void the client settlement for this day, then correct and re-settle';
  end if;

  update public.deliveries
     set charged_snapshot = p_charged,
         updated_at = now()
   where id = p_delivery_id;

  perform public.write_audit(
    p_actor_id := v_actor,
    p_entity_type := 'delivery',
    p_entity_id := p_delivery_id,
    p_old := jsonb_build_object('charged_snapshot', v_row.charged_snapshot),
    p_new := jsonb_build_object('charged_snapshot', p_charged),
    p_reason := 'reda_charge_correction: ' || btrim(p_reason)
  );
end;
$$;


--
-- Name: correct_replacement_payment(uuid, numeric, numeric, text, numeric, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.correct_replacement_payment(p_attempt_id uuid, p_client_charge numeric, p_agent_payment numeric, p_reason text, p_customer_paid numeric, p_payment_method text, p_payment_received_by text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  old_payment jsonb;
  v_fee numeric;
begin
  if not public.is_admin() then raise exception 'Admin only' using errcode='42501'; end if;
  select jsonb_build_object('customer_paid',customer_paid,'payment_method',payment_method,
                            'payment_received_by',payment_received_by,'cash_pos_fee',cash_pos_fee)
    into old_payment from replacement_attempts where id=p_attempt_id for update;
  if old_payment is null then raise exception 'attempt not found' using errcode='P0002'; end if;
  v_fee := public._validate_replacement_payment(p_customer_paid, p_payment_method, p_payment_received_by);
  perform public.update_replacement_attempt_fees(p_attempt_id,p_client_charge,p_agent_payment,p_reason);
  update replacement_attempts
     set customer_paid=p_customer_paid,
         payment_method=case when p_customer_paid>0 then p_payment_method
                             when p_payment_method='vendor_direct' then 'vendor_direct' end,
         payment_received_by=case when p_customer_paid>0 then p_payment_received_by end,
         cash_pos_fee=v_fee
   where id=p_attempt_id;
  perform public.write_audit('replacement_attempt',p_attempt_id,old_payment,
    jsonb_build_object('customer_paid',p_customer_paid,'payment_method',
      case when p_customer_paid>0 then p_payment_method when p_payment_method='vendor_direct' then 'vendor_direct' end,
      'payment_received_by',case when p_customer_paid>0 then p_payment_received_by end,
      'cash_pos_fee',v_fee),
    p_reason);
end; $$;


--
-- Name: correct_same_customer_normal_fee(uuid, uuid, bigint, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.correct_same_customer_normal_fee(p_request_id uuid, p_delivery_id uuid, p_expected_revision bigint, p_normal_fee numeric, p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare d public.deliveries%rowtype; e public.same_customer_earnings%rowtype;
  r public.same_customer_normal_fee_reviews%rowtype; v_after jsonb;
begin
  if not public.is_admin() then raise exception 'admin role required for normal-fee correction' using errcode='42501'; end if;
  if p_request_id is null or p_delivery_id is null or p_expected_revision is null or p_normal_fee is null
    or p_normal_fee::text in ('NaN','Infinity','-Infinity') or p_normal_fee<0 or p_normal_fee>99999999.99
    or round(p_normal_fee,2)<>p_normal_fee or nullif(btrim(p_reason),'') is null or length(btrim(p_reason))>2000 then
    raise exception 'request, delivery, revision, finite non-negative fee with at most two decimals, and reason required' using errcode='22023';
  end if;
  perform public._same_customer_lock_orders(array[p_delivery_id]);
  perform pg_advisory_xact_lock(hashtextextended('same-customer-normal-fee-review:'||p_request_id::text,0));
  select * into r from public.same_customer_normal_fee_reviews where request_id=p_request_id;
  if found then
    if (r.actor_id,r.delivery_id,r.expected_revision,r.normal_fee,r.reason)
      is distinct from (auth.uid(),p_delivery_id,p_expected_revision,p_normal_fee,btrim(p_reason)) then
      raise exception 'request id already used for a different normal-fee correction' using errcode='22023'; end if;
    return r.after_value;
  end if;
  select * into d from public.deliveries where id=p_delivery_id for update;
  if not found then raise exception 'delivery not found' using errcode='P0002'; end if;
  select * into e from public.same_customer_earnings where delivery_id=p_delivery_id for update;
  if not found or not e.active or d.current_status<>'delivered' or d.deleted_at is not null or d.order_type<>'delivery' then
    raise exception 'an active successful earning is required' using errcode='22023'; end if;
  if e.revision<>p_expected_revision then raise exception 'earning changed; refresh before correcting its normal fee' using errcode='40001'; end if;
  if e.base_fee is not distinct from p_normal_fee then raise exception 'normal fee is unchanged' using errcode='22023'; end if;
  if exists(select 1 from public.same_customer_earnings x join public.settlements s
    on s.subject_type='agent' and s.subject_id=x.rider_id and s.period_date=x.accounting_date and s.voided_at is null
    where x.active and (x.delivery_id=e.delivery_id or x.group_id=e.group_id)) then
    raise exception 'affected rider period is settled; resolve settlement before correcting the normal fee' using errcode='22023'; end if;
  -- Existing triggers preserve explicit provenance and recalculate every affected
  -- earning. This never creates, clears or overwrites a manual fee decision.
  update public.deliveries set agent_payment_base_snapshot=p_normal_fee,
    agent_payment_base_captured_at=clock_timestamp() where id=p_delivery_id;
  select to_jsonb(x) into v_after from public.same_customer_earnings x where delivery_id=p_delivery_id;
  insert into public.same_customer_normal_fee_reviews(request_id,delivery_id,actor_id,completion_event_id,
    expected_revision,normal_fee,reason,before_value,after_value)
  values(p_request_id,p_delivery_id,auth.uid(),e.completion_event_id,p_expected_revision,p_normal_fee,btrim(p_reason),to_jsonb(e),v_after);
  return v_after;
end $$;


--
-- Name: count_pending_location_changes(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.count_pending_location_changes() RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select count(*)
  from public.delivery_location_changes c
  where public.is_manager()
    and c.state = 'pending';
$$;


--
-- Name: create_app_user(text, text, text, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_app_user(p_email text, p_password text, p_role text, p_display_name text, p_phone text DEFAULT NULL::text, p_warehouse_id uuid DEFAULT NULL::uuid) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth', 'extensions'
    AS $_$
declare
  v_id    uuid;
  v_email text := lower(trim(p_email));
  v_name  text := nullif(trim(p_display_name), '');
  v_phone text := nullif(trim(p_phone), '');
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if v_email is null or v_email = '' or v_email !~ '^[^@]+@[^@]+\.[^@]+$' then
    raise exception 'valid email required' using errcode = '23514';
  end if;
  if p_password is null or length(p_password) < 8 then
    raise exception 'password must be at least 8 characters' using errcode = '23514';
  end if;
  if p_role not in ('admin','dispatcher','agent','warehouse','rep') then
    raise exception 'invalid role' using errcode = '23514';
  end if;
  if v_name is null then
    raise exception 'display_name required' using errcode = '23514';
  end if;

  -- Warehouse-staff link validation.
  if p_warehouse_id is not null then
    if p_role <> 'warehouse' then
      raise exception 'warehouse_id can only be set on a warehouse user' using errcode = '23514';
    end if;
    if not exists (
      select 1 from public.users
       where id = p_warehouse_id and role = 'warehouse'
         and warehouse_id is null and is_active = true
    ) then
      raise exception 'warehouse_id must reference an active warehouse place' using errcode = '23514';
    end if;
  end if;

  if exists (select 1 from auth.users where email = v_email) then
    raise exception 'email already in use' using errcode = '23505';
  end if;

  v_id := gen_random_uuid();

  insert into auth.users (
    id, instance_id, aud, role, email, encrypted_password,
    email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
    created_at, updated_at, is_sso_user, is_anonymous,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    email_change_token_current, phone_change, phone_change_token, reauthentication_token
  ) values (
    v_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
    v_email, extensions.crypt(p_password, extensions.gen_salt('bf')),
    now(), '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb,
    now(), now(), false, false,
    '', '', '', '', '', '', '', ''
  );

  insert into auth.identities (
    id, provider_id, user_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    gen_random_uuid(), v_id::text, v_id,
    jsonb_build_object('sub', v_id::text, 'email', v_email, 'email_verified', true),
    'email', now(), now(), now()
  );

  insert into public.users (id, email, display_name, role, phone, is_active, warehouse_id)
  values (v_id, v_email, v_name, p_role, v_phone, true, p_warehouse_id);

  if p_role = 'agent' then
    insert into public.agent_profiles (user_id, delivery_capacity)
    values (v_id, 10);
  end if;

  perform public.write_audit(
    'user', v_id, null,
    jsonb_build_object(
      'email',        v_email,
      'display_name', v_name,
      'role',         p_role,
      'phone',        v_phone,
      'warehouse_id', p_warehouse_id,
      'is_active',    true
    )
  );

  return v_id;
end;
$_$;


--
-- Name: create_client(text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_client(p_name text, p_contact_phone text DEFAULT NULL::text, p_contact_email text DEFAULT NULL::text, p_notes text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_id    uuid;
  v_name  text := nullif(trim(p_name), '');
  v_phone text := nullif(trim(p_contact_phone), '');
  v_email text := nullif(trim(p_contact_email), '');
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if v_name is null then
    raise exception 'name required' using errcode = '23514';
  end if;

  insert into public.clients (name, contact_phone, contact_email, notes)
  values (v_name, v_phone, v_email, p_notes)
  returning id into v_id;

  perform public.write_audit(
    'client', v_id,
    null,
    jsonb_build_object(
      'name', v_name,
      'contact_phone', v_phone,
      'contact_email', v_email,
      'notes', p_notes,
      'is_active', true
    )
  );

  return v_id;
end;
$$;


--
-- Name: create_delivery(text, uuid, uuid, text, text, text, integer, numeric, uuid, date, uuid, text, text, text, jsonb, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_delivery(p_client_uuid text, p_client_id uuid, p_product_catalog_id uuid, p_customer_name text, p_customer_phone text, p_raw_address text, p_quantity_ordered integer, p_customer_price numeric, p_location_id uuid DEFAULT NULL::uuid, p_scheduled_date date DEFAULT CURRENT_DATE, p_assigned_agent_id uuid DEFAULT NULL::uuid, p_created_via text DEFAULT 'manual'::text, p_bot_raw_message text DEFAULT NULL::text, p_customer_phone_alt text DEFAULT NULL::text, p_items jsonb DEFAULT NULL::jsonb, p_delivery_instructions text DEFAULT NULL::text, p_client_rep text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_existing       uuid;
  v_delivery_id    uuid;
  v_charged        numeric;
  v_agent_payment  numeric;
  v_customer_name  text := nullif(trim(p_customer_name), '');
  v_customer_phone text := nullif(trim(p_customer_phone), '');
  v_customer_phone_alt text := nullif(trim(p_customer_phone_alt), '');
  v_raw_address    text := nullif(trim(p_raw_address), '');
  v_delivery_instructions text := nullif(trim(p_delivery_instructions), '');
  v_client_rep     text := nullif(trim(p_client_rep), '');
  v_actor          uuid := auth.uid();
  v_fingerprint    text := public._text_fingerprint(p_bot_raw_message);
  v_phone_norm     text := public._norm_phone(p_customer_phone);
  v_original_date  date := p_scheduled_date;
  v_bumped         boolean := false;
  v_items          jsonb;
  v_items_fp       text;
begin
  if not public.is_manager() then
    raise exception 'permission denied: admin or dispatcher only' using errcode = '42501';
  end if;
  if p_client_uuid is null or trim(p_client_uuid) = '' then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;

  select delivery_id into v_existing
    from public.delivery_status_history where client_uuid = p_client_uuid limit 1;
  if v_existing is not null then return v_existing; end if;

  if v_customer_name  is null then raise exception 'customer_name required'  using errcode = '23514'; end if;
  if v_customer_phone is null then raise exception 'customer_phone required' using errcode = '23514'; end if;
  if v_raw_address    is null then raise exception 'raw_address required'    using errcode = '23514'; end if;
  if p_quantity_ordered is null or p_quantity_ordered <= 0 then
    raise exception 'quantity_ordered must be > 0' using errcode = '23514';
  end if;
  if p_customer_price is null or p_customer_price < 0 then
    raise exception 'customer_price must be >= 0' using errcode = '23514';
  end if;
  if p_created_via not in ('manual', 'bot') then
    raise exception 'invalid created_via' using errcode = '23514';
  end if;

  -- Customer blacklist: refuse before anything is written (structured P0001).
  perform public._assert_customer_not_blacklisted(p_customer_phone, p_customer_phone_alt);

  p_scheduled_date := public._effective_scheduled_date(p_scheduled_date, p_created_via);
  v_bumped := (p_scheduled_date is distinct from v_original_date);

  if not exists (select 1 from public.clients where id = p_client_id and is_active = true) then
    raise exception 'client is inactive or not found' using errcode = '23514';
  end if;

  v_items := coalesce(p_items, jsonb_build_array(jsonb_build_object(
    'product_catalog_id', p_product_catalog_id, 'quantity_ordered', p_quantity_ordered,
    'customer_price', p_customer_price)));

  if exists (
    select 1 from jsonb_array_elements(v_items) e
     where not exists (
       select 1 from public.product_catalog pc
        where pc.id = (e->>'product_catalog_id')::uuid
          and pc.client_id = p_client_id and pc.is_active = true)
  ) then
    raise exception 'a line item product is inactive or does not belong to client' using errcode = '23514';
  end if;

  v_items_fp := public._delivery_items_sig(v_items);   -- [Feature A] dedup identity

  -- Same-agent sibling guard — manual creates only, re-keyed to items_fingerprint.
  if p_created_via = 'manual'
     and p_assigned_agent_id is not null
     and v_phone_norm is not null
     and exists (
       select 1
         from public.deliveries d
         join public.delivery_status_defs sd on sd.status = d.current_status
        where d.assigned_agent_id          = p_assigned_agent_id
          and d.customer_phone_normalized  = v_phone_norm
          and d.items_fingerprint          = v_items_fp           -- [Feature A]
          and (d.scheduled_date = p_scheduled_date or d.current_status = 'postponed')
          and d.deleted_at is null
          and sd.category <> 'terminal'
          and (
            (v_fingerprint is not null and d.text_fingerprint is not null and d.text_fingerprint = v_fingerprint)
            or
            ((v_fingerprint is null or d.text_fingerprint is null)
             and public._norm_address(d.raw_address) = public._norm_address(v_raw_address))
          )
     )
  then
    raise exception 'agent % already has an open delivery matching this customer + items + date',
      coalesce((select u.display_name from public.users u where u.id = p_assigned_agent_id), p_assigned_agent_id::text)
      using errcode = '23505', hint = 'reassign to a different agent';
  end if;

  if p_location_id is not null then
    select er.charged, er.agent_payment into v_charged, v_agent_payment
      from public.effective_rate(p_location_id, p_client_id, null) er;
  end if;

  insert into public.deliveries (
    client_id, product_catalog_id, location_id,
    customer_name, customer_phone, customer_phone_alt, raw_address,
    quantity_ordered, customer_price, charged_snapshot, agent_payment_snapshot,
    scheduled_date, assigned_agent_id, created_by_user_id,
    current_status, created_via, bot_raw_message, text_fingerprint,
    delivery_instructions, client_rep
  ) values (
    p_client_id, p_product_catalog_id, p_location_id,
    v_customer_name, v_customer_phone, v_customer_phone_alt, v_raw_address,
    p_quantity_ordered, p_customer_price, v_charged, v_agent_payment,
    p_scheduled_date, p_assigned_agent_id, v_actor,
    'pending', p_created_via, p_bot_raw_message, v_fingerprint,
    v_delivery_instructions, v_client_rep
  ) returning id into v_delivery_id;

  v_items_fp := public._apply_delivery_items(v_delivery_id, v_items);

  insert into public.delivery_status_history (
    delivery_id, from_status, to_status, changed_by_user_id, client_uuid, effective_at
  ) values (v_delivery_id, null, 'pending', v_actor, p_client_uuid, now());

  perform public.write_audit(
    'delivery', v_delivery_id, null,
    jsonb_build_object(
      'client_id', p_client_id, 'product_catalog_id', p_product_catalog_id,
      'location_id', p_location_id, 'customer_name', v_customer_name,
      'customer_phone', v_customer_phone, 'customer_phone_alt', v_customer_phone_alt,
      'raw_address', v_raw_address, 'quantity_ordered', p_quantity_ordered,
      'customer_price', p_customer_price, 'charged_snapshot', v_charged,
      'agent_payment_snapshot', v_agent_payment, 'assigned_agent_id', p_assigned_agent_id,
      'scheduled_date', p_scheduled_date, 'created_via', p_created_via,
      'current_status', 'pending', 'text_fingerprint', v_fingerprint,
      'items', v_items, 'items_fingerprint', v_items_fp,
      'delivery_instructions', v_delivery_instructions,
      'client_rep', v_client_rep,
      'auto_bumped_after_hours', v_bumped,
      'original_scheduled_date', case when v_bumped then v_original_date else null end
    ), null);

  return v_delivery_id;
end;
$$;


--
-- Name: create_location(text, text[], numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_location(p_name text, p_aliases text[] DEFAULT '{}'::text[], p_latitude numeric DEFAULT NULL::numeric, p_longitude numeric DEFAULT NULL::numeric) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_id    uuid;
  v_name  text := nullif(trim(p_name), '');
  v_aliases text[] := coalesce(p_aliases, '{}'::text[]);
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if v_name is null then
    raise exception 'name required' using errcode = '23514';
  end if;

  -- Strip empty aliases, trim whitespace
  v_aliases := array(
    select trim(a) from unnest(v_aliases) a
     where nullif(trim(a), '') is not null
  );

  insert into public.locations (name, aliases, latitude, longitude)
  values (v_name, v_aliases, p_latitude, p_longitude)
  returning id into v_id;

  perform public.write_audit(
    'location', v_id,
    null,
    jsonb_build_object(
      'name', v_name,
      'aliases', to_jsonb(v_aliases),
      'latitude', p_latitude,
      'longitude', p_longitude,
      'is_active', true
    )
  );

  return v_id;
end;
$$;


--
-- Name: create_product(uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_product(p_client_id uuid, p_product_name text, p_description text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_id   uuid;
  v_name text := nullif(trim(p_product_name), '');
  v_client_active boolean;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if v_name is null then
    raise exception 'product_name required' using errcode = '23514';
  end if;

  select is_active into v_client_active from public.clients where id = p_client_id;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;
  if not v_client_active then
    raise exception 'client is inactive — reactivate it before adding products' using errcode = '23514';
  end if;

  insert into public.product_catalog (client_id, product_name, description)
  values (p_client_id, v_name, nullif(trim(p_description), ''))
  returning id into v_id;

  perform public.write_audit(
    'product', v_id,
    null,
    jsonb_build_object(
      'client_id', p_client_id,
      'product_name', v_name,
      'description', p_description,
      'is_active', true
    )
  );

  return v_id;
end;
$$;


--
-- Name: create_replacement(text, uuid, text, text, text, text, uuid, date, uuid, jsonb, jsonb, text, text, numeric, numeric, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_replacement(p_client_uuid text, p_client_id uuid, p_customer_name text, p_customer_phone text, p_customer_phone_alt text, p_raw_address text, p_location_id uuid, p_scheduled_date date, p_assigned_agent_id uuid, p_outbound_items jsonb, p_return_items jsonb, p_reason text, p_notes text DEFAULT NULL::text, p_success_client_charge numeric DEFAULT 0, p_success_agent_payment numeric DEFAULT 0, p_original_delivery_id uuid DEFAULT NULL::uuid) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_existing uuid;
  v_delivery_id uuid;
  v_first_product uuid;
  v_total integer;
  v_item jsonb;
  v_product uuid;
  v_qty integer;
  v_instruction text;
begin
  if not public.is_manager() then
    raise exception 'permission denied: admin or dispatcher only' using errcode = '42501';
  end if;
  if p_original_delivery_id is not null and not exists (
    select 1 from public.deliveries where id = p_original_delivery_id
      and deleted_at is null and order_type = 'delivery' and client_id = p_client_id
  ) then
    raise exception 'Original delivery must exist and belong to the same client' using errcode = '22023';
  end if;
  if nullif(trim(p_client_uuid), '') is null then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  select delivery_id into v_existing
    from public.delivery_status_history where client_uuid = p_client_uuid limit 1;
  if v_existing is not null then return v_existing; end if;

  if nullif(trim(p_customer_name), '') is null
     or nullif(trim(p_customer_phone), '') is null
     or nullif(trim(p_raw_address), '') is null then
    raise exception 'customer name, phone and address are required' using errcode = '23514';
  end if;
  if p_location_id is null then
    raise exception 'location required' using errcode = '23514';
  end if;
  if nullif(trim(p_reason), '') is null then
    raise exception 'replacement reason required' using errcode = '23514';
  end if;
  if coalesce(p_success_client_charge, -1) < 0 or coalesce(p_success_agent_payment, -1) < 0 then
    raise exception 'charges must be >= 0' using errcode = '23514';
  end if;
  if jsonb_typeof(p_outbound_items) <> 'array' or jsonb_array_length(p_outbound_items) = 0 then
    raise exception 'at least one outbound item is required' using errcode = '23514';
  end if;
  if jsonb_typeof(p_return_items) <> 'array' or jsonb_array_length(p_return_items) = 0 then
    raise exception 'at least one expected return item is required' using errcode = '23514';
  end if;
  if exists (
    select 1 from jsonb_array_elements(p_outbound_items) item
     group by item->>'product_catalog_id' having count(*) > 1
  ) then
    raise exception 'combine duplicate outbound products into one quantity'
      using errcode = '23514';
  end if;
  if exists (
    select 1 from jsonb_array_elements(p_return_items) item
     group by item->>'product_catalog_id' having count(*) > 1
  ) then
    raise exception 'combine duplicate returned products into one quantity'
      using errcode = '23514';
  end if;
  if not exists (select 1 from public.clients where id = p_client_id and is_active) then
    raise exception 'client is inactive or not found' using errcode = '23514';
  end if;
  if not exists (select 1 from public.locations where id = p_location_id) then
    raise exception 'location not found' using errcode = '23514';
  end if;
  if p_assigned_agent_id is not null and not exists (
    select 1 from public.users where id = p_assigned_agent_id and role = 'agent' and is_active
  ) then
    raise exception 'assigned agent is inactive or invalid' using errcode = '23514';
  end if;

  v_total := 0;
  for v_item in select value from jsonb_array_elements(p_outbound_items)
  loop
    v_product := nullif(v_item->>'product_catalog_id', '')::uuid;
    v_qty := nullif(v_item->>'quantity', '')::integer;
    if v_product is null or coalesce(v_qty, 0) <= 0 then
      raise exception 'every outbound item needs a product and positive quantity' using errcode = '23514';
    end if;
    if not exists (
      select 1 from public.product_catalog
       where id = v_product and client_id = p_client_id and is_active
    ) then
      raise exception 'outbound product does not belong to this client' using errcode = '23514';
    end if;
    v_first_product := coalesce(v_first_product, v_product);
    v_total := v_total + v_qty;
  end loop;

  insert into public.deliveries(
    client_id, product_catalog_id, location_id,
    customer_name, customer_phone, customer_phone_alt, raw_address,
    quantity_ordered, customer_price, charged_snapshot, agent_payment_snapshot,
    scheduled_date, assigned_agent_id, created_by_user_id,
    current_status, created_via, order_type, delivery_instructions
  ) values (
    p_client_id, v_first_product, p_location_id,
    trim(p_customer_name), trim(p_customer_phone), nullif(trim(p_customer_phone_alt), ''),
    trim(p_raw_address), v_total, 0, 0, 0,
    coalesce(p_scheduled_date, (now() at time zone 'Africa/Lagos')::date),
    p_assigned_agent_id, v_actor, 'pending', 'manual', 'replacement', nullif(trim(p_notes), '')
  ) returning id into v_delivery_id;

  for v_item in select value from jsonb_array_elements(p_outbound_items)
  loop
    insert into public.delivery_items(delivery_id, product_catalog_id, quantity_ordered, customer_price)
    values (
      v_delivery_id,
      (v_item->>'product_catalog_id')::uuid,
      (v_item->>'quantity')::integer,
      0
    );
  end loop;

  insert into public.replacement_jobs(
    delivery_id, original_delivery_id, reason, notes,
    success_client_charge, success_agent_payment, created_by_user_id
  ) values (
    v_delivery_id, p_original_delivery_id, trim(p_reason), nullif(trim(p_notes), ''),
    p_success_client_charge, p_success_agent_payment, v_actor
  );

  for v_item in select value from jsonb_array_elements(p_return_items)
  loop
    v_product := nullif(v_item->>'product_catalog_id', '')::uuid;
    v_qty := nullif(v_item->>'quantity', '')::integer;
    v_instruction := coalesce(nullif(v_item->>'vendor_instruction', ''), 'ask_if_damaged');
    if v_product is null or coalesce(v_qty, 0) <= 0 then
      raise exception 'every return item needs a product and positive quantity' using errcode = '23514';
    end if;
    if v_instruction not in ('ask_if_damaged', 'collect_and_hold', 'do_not_collect_damaged') then
      raise exception 'invalid vendor instruction' using errcode = '23514';
    end if;
    if not exists (
      select 1 from public.product_catalog
       where id = v_product and client_id = p_client_id and is_active
    ) then
      raise exception 'return product does not belong to this client' using errcode = '23514';
    end if;
    insert into public.replacement_return_items(
      delivery_id, product_catalog_id, quantity_expected, vendor_instruction
    ) values (v_delivery_id, v_product, v_qty, v_instruction);
  end loop;

  insert into public.delivery_status_history(
    delivery_id, from_status, to_status, changed_by_user_id, client_uuid, effective_at, reason
  ) values (v_delivery_id, null, 'pending', v_actor, p_client_uuid, now(), 'replacement_created');

  perform public.write_audit(
    'delivery', v_delivery_id, null,
    jsonb_build_object(
      'order_type', 'replacement',
      'client_id', p_client_id,
      'outbound_items', p_outbound_items,
      'return_items', p_return_items,
      'reason', trim(p_reason),
      'success_client_charge', p_success_client_charge,
      'success_agent_payment', p_success_agent_payment,
      'assigned_agent_id', p_assigned_agent_id
    ), null
  );
  return v_delivery_id;
end;
$$;


--
-- Name: create_stock_adjustment(text, uuid, uuid, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_stock_adjustment(p_client_uuid text, p_agent_id uuid, p_product_catalog_id uuid, p_quantity_delta integer, p_reason text, p_notes text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_id           uuid;
  v_existing     uuid;
  v_actor        uuid := auth.uid();
  v_role         text;
  v_warehouse_id uuid;
  v_on_hand      int;
begin
  if v_actor is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;

  select role, warehouse_id into v_role, v_warehouse_id from public.users where id = v_actor;

  -- Permission gate (admin first, then warehouse-scoped, else deny).
  if v_role = 'admin' then
    null;  -- allow all paths (unchanged)
  elsif v_role = 'warehouse'
        and p_reason in ('bulk_intake','loss','theft','damaged','found')
        and p_agent_id = coalesce(v_warehouse_id, v_actor) then
    null;  -- warehouse acts on its place's holdings (staff → linked place; place → self), except correction
  else
    raise exception 'permission denied'
      using errcode = '42501',
            hint    = 'admin can adjust any holder; warehouse can adjust only their place''s holdings (no correction).';
  end if;

  if p_client_uuid is null or trim(p_client_uuid) = '' then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  if p_quantity_delta is null or p_quantity_delta = 0 then
    raise exception 'quantity_delta must be non-zero' using errcode = '23514';
  end if;
  if p_reason not in ('loss','theft','damaged','found','correction','bulk_intake') then
    raise exception 'invalid reason for single-row adjustment: %', p_reason using errcode = '23514';
  end if;
  if p_reason in ('loss','theft','damaged') and p_quantity_delta >= 0 then
    raise exception '% requires a negative quantity_delta', p_reason using errcode = '23514';
  end if;
  if p_reason in ('found','bulk_intake') and p_quantity_delta <= 0 then
    raise exception '% requires a positive quantity_delta', p_reason using errcode = '23514';
  end if;
  -- correction: either sign OK; explicit "books were wrong" escape hatch.

  -- Idempotency.
  select id into v_existing
    from public.stock_adjustments
   where client_uuid = p_client_uuid
   limit 1;
  if v_existing is not null then
    return v_existing;
  end if;

  if not exists (select 1 from public.users where id = p_agent_id and is_active = true) then
    raise exception 'user not found or inactive' using errcode = '23514';
  end if;
  -- The product must EXIST. Whether it must be ACTIVE depends on the reason.
  if not exists (select 1 from public.product_catalog where id = p_product_catalog_id) then
    raise exception 'product not found' using errcode = '23514';
  end if;
  -- Writing DOWN a deactivated product has to stay possible: units already out
  -- there get lost, stolen or damaged after the product is retired, and
  -- deactivate_user's 'loss' disposition lands here. Only the two reasons that
  -- bring NEW units in stay closed -- nobody should be receiving more of a
  -- product the catalog has retired.
  if p_reason in ('bulk_intake','found')
     and not exists (select 1 from public.product_catalog
                      where id = p_product_catalog_id and is_active = true) then
    raise exception 'product is inactive - cannot receive more units of a deactivated product'
      using errcode = '23514',
            hint = jsonb_build_object(
              'code',               'inactive_product',
              'product_catalog_id', p_product_catalog_id,
              'attempted_reason',   p_reason
            )::text;
  end if;

  if p_reason in ('loss','theft','damaged') then
    select coalesce(quantity_on_hand, 0) into v_on_hand
      from public.current_stock
     where agent_id           = p_agent_id
       and product_catalog_id = p_product_catalog_id;

    if coalesce(v_on_hand, 0) < (-p_quantity_delta) then
      raise exception
        'insufficient_stock: user has % units, % needs %',
        coalesce(v_on_hand, 0), p_reason, (-p_quantity_delta)
      using errcode = 'P0001',
            hint = jsonb_build_object(
              'code',    'insufficient_stock',
              'on_hand', coalesce(v_on_hand, 0),
              'needed',  (-p_quantity_delta)
            )::text;
    end if;
  end if;

  insert into public.stock_adjustments (
    agent_id, product_catalog_id, quantity_delta, reason, notes,
    client_uuid, created_by_user_id
  ) values (
    p_agent_id, p_product_catalog_id, p_quantity_delta, p_reason, p_notes,
    p_client_uuid, v_actor
  ) returning id into v_id;

  perform public.write_audit(
    'stock_adjustment', v_id, null,
    jsonb_build_object(
      'agent_id',           p_agent_id,
      'product_catalog_id', p_product_catalog_id,
      'quantity_delta',     p_quantity_delta,
      'reason',             p_reason,
      'notes',              p_notes
    )
  );

  return v_id;
end;
$$;


--
-- Name: FUNCTION create_stock_adjustment(p_client_uuid text, p_agent_id uuid, p_product_catalog_id uuid, p_quantity_delta integer, p_reason text, p_notes text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.create_stock_adjustment(p_client_uuid text, p_agent_id uuid, p_product_catalog_id uuid, p_quantity_delta integer, p_reason text, p_notes text) IS 'Single-row stock adjustment. A deactivated product can still be written down (loss/theft/damaged/correction); only bulk_intake and found are refused for an inactive product.';


--
-- Name: create_stock_transfer(text, uuid, uuid, uuid, integer, text, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_stock_transfer(p_client_uuid text, p_from_user_id uuid, p_to_user_id uuid, p_product_catalog_id uuid, p_quantity integer, p_reason text, p_notes text DEFAULT NULL::text, p_allow_inactive_from boolean DEFAULT false) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_source_id    uuid;
  v_target_id    uuid;
  v_existing     uuid;
  v_actor        uuid := auth.uid();
  v_role         text;
  v_warehouse_id uuid;
  v_from_active  boolean;
  v_on_hand      int;
begin
  if v_actor is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;

  select role, warehouse_id into v_role, v_warehouse_id from public.users where id = v_actor;

  -- Permission gate (admin + dispatcher = any paired reason; warehouse only as
  -- a participant — and staff participate as their linked place).
  if v_role = 'admin' then
    null;  -- allow all paired reasons
  elsif v_role = 'dispatcher' then
    null;  -- dispatcher coordinates rider stock — same powers as admin here
  elsif v_role = 'warehouse'
        and p_reason = 'warehouse_issue'
        and p_from_user_id = coalesce(v_warehouse_id, v_actor) then
    null;  -- warehouse place is the source (issuing to an agent)
  elsif v_role = 'warehouse'
        and p_reason = 'warehouse_return'
        and p_to_user_id = coalesce(v_warehouse_id, v_actor) then
    null;  -- warehouse place is the destination (receiving from an agent)
  else
    raise exception 'permission denied'
      using errcode = '42501',
            hint    = 'admin or dispatcher runs any paired transfer; warehouse can only do warehouse_issue (from=their place) or warehouse_return (to=their place).';
  end if;

  if p_client_uuid is null or trim(p_client_uuid) = '' then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'quantity must be > 0' using errcode = '23514';
  end if;
  if p_reason not in ('transfer','warehouse_return','warehouse_issue') then
    raise exception 'invalid paired reason: %', p_reason using errcode = '23514';
  end if;
  if p_from_user_id = p_to_user_id then
    raise exception 'from and to users must differ' using errcode = '23514';
  end if;

  select id into v_existing
    from public.stock_adjustments
   where client_uuid = p_client_uuid
   limit 1;
  if v_existing is not null then
    return v_existing;
  end if;

  select is_active into v_from_active from public.users where id = p_from_user_id;
  if v_from_active is null then
    raise exception 'from user not found' using errcode = '23514';
  end if;
  if not v_from_active and not p_allow_inactive_from then
    raise exception 'from user is inactive' using errcode = '23514';
  end if;

  if not exists (select 1 from public.users where id = p_to_user_id and is_active = true) then
    raise exception 'to user not found or inactive' using errcode = '23514';
  end if;
  -- The product must EXIST. Whether it must be ACTIVE depends on direction.
  if not exists (select 1 from public.product_catalog where id = p_product_catalog_id) then
    raise exception 'product not found' using errcode = '23514';
  end if;
  -- A deactivated product legitimately sits in the warehouse when a vendor has
  -- not collected their goods yet, and an agent can be left holding units when
  -- a product is retired mid-round. Draining that stock has to stay possible --
  -- agent -> warehouse to return it, agent -> agent to consolidate before a
  -- return -- otherwise deactivation strands the units with no legal move, and
  -- deactivate_user cannot offboard the rider at all (its 'warehouse' and
  -- 'transfer:<uuid>' dispositions both land here).
  -- Only warehouse_issue stays closed: putting a retired product back into a
  -- rider's bag to sell is the exact thing deactivation exists to prevent.
  if p_reason = 'warehouse_issue'
     and not exists (select 1 from public.product_catalog
                      where id = p_product_catalog_id and is_active = true) then
    raise exception 'product is inactive - cannot issue a deactivated product to an agent'
      using errcode = '23514',
            hint = jsonb_build_object(
              'code',               'inactive_product',
              'product_catalog_id', p_product_catalog_id,
              'attempted_reason',   p_reason
            )::text;
  end if;

  if v_from_active then
    select coalesce(quantity_on_hand, 0) into v_on_hand
      from public.current_stock
     where agent_id           = p_from_user_id
       and product_catalog_id = p_product_catalog_id;

    if coalesce(v_on_hand, 0) < p_quantity then
      raise exception
        'insufficient_stock: source has % units, transfer needs %',
        coalesce(v_on_hand, 0), p_quantity
      using errcode = 'P0001',
            hint = jsonb_build_object(
              'code',    'insufficient_stock',
              'on_hand', coalesce(v_on_hand, 0),
              'needed',  p_quantity
            )::text;
    end if;
  end if;

  insert into public.stock_adjustments (
    agent_id, product_catalog_id, quantity_delta, reason, notes,
    client_uuid, created_by_user_id
  ) values (
    p_from_user_id, p_product_catalog_id, -p_quantity, p_reason, p_notes,
    p_client_uuid, v_actor
  ) returning id into v_source_id;

  insert into public.stock_adjustments (
    agent_id, product_catalog_id, quantity_delta, reason, notes,
    client_uuid, created_by_user_id, related_adjustment_id
  ) values (
    p_to_user_id, p_product_catalog_id, p_quantity, p_reason, p_notes,
    p_client_uuid || ':paired', v_actor, v_source_id
  ) returning id into v_target_id;

  update public.stock_adjustments
     set related_adjustment_id = v_target_id
   where id = v_source_id;

  perform public.write_audit(
    'stock_transfer', v_source_id, null,
    jsonb_build_object(
      'from_user_id',          p_from_user_id,
      'to_user_id',            p_to_user_id,
      'product_catalog_id',    p_product_catalog_id,
      'quantity',              p_quantity,
      'reason',                p_reason,
      'notes',                 p_notes,
      'related_adjustment_id', v_target_id
    )
  );

  return v_source_id;
end;
$$;


--
-- Name: FUNCTION create_stock_transfer(p_client_uuid text, p_from_user_id uuid, p_to_user_id uuid, p_product_catalog_id uuid, p_quantity integer, p_reason text, p_notes text, p_allow_inactive_from boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.create_stock_transfer(p_client_uuid text, p_from_user_id uuid, p_to_user_id uuid, p_product_catalog_id uuid, p_quantity integer, p_reason text, p_notes text, p_allow_inactive_from boolean) IS 'Paired stock move. A deactivated product can still be returned to the warehouse or moved between agents so its units can be drained; only warehouse_issue is refused for an inactive product.';


--
-- Name: create_waybill(uuid, numeric, numeric, text, text, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_waybill(p_client_id uuid, p_charged numeric, p_paid numeric, p_note text DEFAULT NULL::text, p_label text DEFAULT 'Waybill'::text, p_scheduled_date date DEFAULT NULL::date) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_id    uuid;
  v_role  text;
  v_date  date := coalesce(p_scheduled_date, (now() at time zone 'Africa/Lagos')::date);
  v_label text := coalesce(nullif(btrim(p_label), ''), 'Waybill');
begin
  if not public.is_manager() then
    raise exception 'permission denied: admin or dispatcher only' using errcode = '42501';
  end if;
  if p_client_id is null then
    raise exception 'a client is required for a waybill' using errcode = '23514';
  end if;
  if p_charged is null or p_charged < 0 then
    raise exception 'charged must be a non-negative number' using errcode = '23514';
  end if;
  if p_paid is null or p_paid < 0 then
    raise exception 'paid out must be a non-negative number' using errcode = '23514';
  end if;

  select role into v_role from public.users where id = v_actor;
  v_role := case when v_role in ('admin','dispatcher') then v_role else 'admin' end;

  insert into public.deliveries (
    client_id, order_type,
    customer_name, quantity_ordered, quantity_delivered, customer_price,
    charged_snapshot, agent_payment_snapshot, paid,
    current_status, created_via, created_date, scheduled_date, created_by_user_id
  ) values (
    p_client_id, 'waybill',
    v_label, 1, 1, 0,
    p_charged, p_paid, 0,
    'delivered', 'manual', v_date, v_date, v_actor
  ) returning id into v_id;

  insert into public.delivery_status_history (
    delivery_id, from_status, to_status, changed_by_user_id, client_uuid, effective_at
  ) values (v_id, null, 'delivered', v_actor, gen_random_uuid(), now());

  if nullif(btrim(p_note), '') is not null then
    insert into public.delivery_messages (delivery_id, author_id, author_role, note)
      values (v_id, v_actor, v_role, btrim(p_note));
  end if;

  perform public.write_audit(
    'delivery', v_id, null,
    jsonb_build_object(
      'order_type',             'waybill',
      'client_id',              p_client_id,
      'customer_name',          v_label,
      'charged_snapshot',       p_charged,
      'agent_payment_snapshot', p_paid,
      'paid',                   0,
      'waybill_paid_out',       p_paid,
      'note',                   nullif(btrim(p_note), ''),
      'current_status',         'delivered'
    ),
    'create_waybill'
  );

  return v_id;
end;
$$;


--
-- Name: current_rate_for_location(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.current_rate_for_location(p_location_id uuid) RETURNS TABLE(charged numeric, agent_payment numeric)
    LANGUAGE sql STABLE
    AS $$
    select charged, agent_payment
    from public.rate_card
    where location_id = p_location_id
        and effective_until is null
    order by effective_from desc
    limit 1;
$$;


--
-- Name: current_user_role(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.current_user_role() RETURNS text
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    select role from public.users where id = auth.uid();
$$;


--
-- Name: deactivate_client(uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deactivate_client(p_id uuid, p_reason text, p_force boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_active boolean;
  v_blocked    jsonb;
  v_pid        uuid;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if nullif(trim(p_reason), '') is null then
    raise exception 'reason required for deactivation' using errcode = '23514';
  end if;

  select is_active into v_was_active from public.clients where id = p_id for update;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;
  if not v_was_active then return; end if;

  if not p_force then
    select jsonb_agg(x order by x->>'product_name') into v_blocked
      from (
        select jsonb_build_object(
                 'product_id',   p.id,
                 'product_name', p.product_name,
                 'blockers',     b.j) as x
          from public.product_catalog p
          cross join lateral public._product_deactivation_blockers(p.id) as b(j)
         where p.client_id = p_id
           and p.is_active = true
           and ((b.j->>'agent_units')::int > 0 or (b.j->>'open_deliveries')::int > 0)
      ) t;

    if v_blocked is not null then
      raise exception 'client_products_in_use: % product(s) still in use',
        jsonb_array_length(v_blocked)
        using errcode = '23514',
              hint = jsonb_build_object(
                'code',      'client_deactivation_blocked',
                'client_id', p_id,
                'products',  v_blocked
              )::text;
    end if;
  end if;

  update public.clients set is_active = false where id = p_id;

  perform public.write_audit(
    'client', p_id,
    jsonb_build_object('is_active', true),
    jsonb_build_object('is_active', false),
    p_reason
  );

  -- Per-product, so each gets its own guard evaluation and its own audit row.
  for v_pid in
    select id
      from public.product_catalog
     where client_id = p_id and is_active = true
     order by product_name
  loop
    perform public.deactivate_product(v_pid, p_reason, p_force);
  end loop;
end;
$$;


--
-- Name: FUNCTION deactivate_client(p_id uuid, p_reason text, p_force boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.deactivate_client(p_id uuid, p_reason text, p_force boolean) IS 'Admin-only. Refuses if any of the client''s active products is blocked (agent-held stock or open deliveries), naming them all; otherwise cascades through deactivate_product so each product is guarded and audited individually.';


--
-- Name: deactivate_location(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deactivate_location(p_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_active boolean;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if nullif(trim(p_reason), '') is null then
    raise exception 'reason required for deactivation' using errcode = '23514';
  end if;

  select is_active into v_was_active from public.locations where id = p_id;
  if not found then
    raise exception 'location not found' using errcode = 'P0002';
  end if;
  if not v_was_active then return; end if;

  update public.locations set is_active = false where id = p_id;

  perform public.write_audit(
    'location', p_id,
    jsonb_build_object('is_active', true),
    jsonb_build_object('is_active', false),
    p_reason
  );
end;
$$;


--
-- Name: deactivate_product(uuid, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deactivate_product(p_id uuid, p_reason text, p_force boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_active boolean;
  v_blockers   jsonb;
  v_agent      int;
  v_open       int;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if nullif(trim(p_reason), '') is null then
    raise exception 'reason required for deactivation' using errcode = '23514';
  end if;

  select is_active into v_was_active from public.product_catalog where id = p_id for update;
  if not found then
    raise exception 'product not found' using errcode = 'P0002';
  end if;
  if not v_was_active then return; end if;

  v_blockers := public._product_deactivation_blockers(p_id);
  v_agent    := (v_blockers->>'agent_units')::int;
  v_open     := (v_blockers->>'open_deliveries')::int;

  -- warehouse_units is deliberately not consulted.
  if not p_force and (v_agent > 0 or v_open > 0) then
    raise exception 'product_in_use: % unit(s) still held by agents, % open deliver%',
      v_agent, v_open, case when v_open = 1 then 'y' else 'ies' end
      using errcode = '23514', hint = v_blockers::text;
  end if;

  -- product_catalog has no updated_at column.
  update public.product_catalog set is_active = false where id = p_id;

  perform public.write_audit(
    'product', p_id,
    jsonb_build_object('is_active', true),
    jsonb_build_object('is_active', false)
      || case when p_force and (v_agent > 0 or v_open > 0)
              then jsonb_build_object('forced_over_blockers', v_blockers)
              else '{}'::jsonb end,
    p_reason
  );
end;
$$;


--
-- Name: FUNCTION deactivate_product(p_id uuid, p_reason text, p_force boolean); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.deactivate_product(p_id uuid, p_reason text, p_force boolean) IS 'Admin-only. Refuses while agents hold units or open (non-terminal) deliveries reference the product; warehouse-held stock never blocks. p_force overrides and records the blocker snapshot on the audit row.';


--
-- Name: deactivate_user(uuid, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.deactivate_user(p_id uuid, p_reason text, p_stock_disposition text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old        public.users;
  v_action     text;
  v_target     uuid;
  v_warehouse  uuid;
  v_stock      record;
  v_qty        int;
  v_uuid_seed  text;
  v_i          int := 0;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if nullif(trim(p_reason), '') is null then
    raise exception 'reason required for deactivation' using errcode = '23514';
  end if;

  select * into v_old from public.users where id = p_id;
  if not found then
    raise exception 'user not found' using errcode = 'P0002';
  end if;
  if not v_old.is_active then return; end if;
  if p_id = auth.uid() then
    raise exception 'cannot deactivate yourself' using errcode = '42501';
  end if;

  if v_old.role = 'agent' and nullif(trim(p_stock_disposition), '') is not null then
    v_uuid_seed := 'deactivate-' || v_old.id::text || '-' || extract(epoch from now())::bigint::text;

    if p_stock_disposition like 'transfer:%' then
      v_action := 'transfer';
      begin
        v_target := substring(p_stock_disposition from 10)::uuid;
      exception when others then
        raise exception 'invalid transfer target in disposition: %', p_stock_disposition using errcode = '23514';
      end;
      if not exists (select 1 from public.users where id = v_target and role = 'agent' and is_active = true) then
        raise exception 'transfer target is not an active agent' using errcode = '23514';
      end if;
    elsif p_stock_disposition = 'warehouse' then
      v_action := 'warehouse';
      select id into v_warehouse from public.users where role = 'warehouse' and is_active = true limit 1;
      if v_warehouse is null then
        raise exception 'no active warehouse user found to receive returned stock' using errcode = '23514';
      end if;
    elsif p_stock_disposition = 'loss' then
      v_action := 'loss';
    else
      raise exception 'invalid stock disposition: %', p_stock_disposition using errcode = '23514';
    end if;

    for v_stock in
      select product_catalog_id, quantity_on_hand
        from public.current_stock
       where agent_id = v_old.id
         and quantity_on_hand > 0
    loop
      v_i := v_i + 1;
      v_qty := v_stock.quantity_on_hand::int;     -- cast bigint -> int

      if v_action = 'transfer' then
        perform public.create_stock_transfer(
          v_uuid_seed || ':' || v_i::text,
          v_old.id, v_target, v_stock.product_catalog_id,
          v_qty, 'transfer',
          'Auto-moved on deactivation of ' || v_old.display_name
        );
      elsif v_action = 'warehouse' then
        perform public.create_stock_transfer(
          v_uuid_seed || ':' || v_i::text,
          v_old.id, v_warehouse, v_stock.product_catalog_id,
          v_qty, 'warehouse_return',
          'Auto-returned on deactivation of ' || v_old.display_name
        );
      elsif v_action = 'loss' then
        perform public.create_stock_adjustment(
          v_uuid_seed || ':' || v_i::text,
          v_old.id, v_stock.product_catalog_id,
          -v_qty, 'loss',
          'Written off on deactivation of ' || v_old.display_name
        );
      end if;
    end loop;
  end if;

  update public.users
     set is_active      = false,
         deactivated_at = now()
   where id = p_id;

  perform public.write_audit(
    'user', p_id,
    jsonb_build_object('is_active', true),
    case
      when p_stock_disposition is not null then
        jsonb_build_object('is_active', false, 'stock_disposition_applied', p_stock_disposition)
      else jsonb_build_object('is_active', false)
    end,
    p_reason
  );
end;
$$;


--
-- Name: decline_call(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.decline_call(p_call_id uuid, p_reason text) RETURNS public.calls
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user uuid := auth.uid();
  v_row  public.calls%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;

  update public.calls
     set status   = 'declined',
         ended_at = now()
   where id              = p_call_id
     and callee_id       = v_user
     and status          = 'ringing'
     and callee_audience = 'user'
   returning * into v_row;

  if found then
    perform public.write_audit(
      'call', v_row.id,
      jsonb_build_object('status', 'ringing'),
      jsonb_build_object('status', 'declined', 'ended_at', v_row.ended_at),
      coalesce(nullif(trim(coalesce(p_reason,'')), ''), 'declined by callee'),
      v_user
    );
    return v_row;
  end if;

  select * into v_row from public.calls where id = p_call_id;
  if not found then
    raise exception 'call not found' using errcode = 'P0002';
  end if;

  -- Callee dismissing a call that already ended (caller gave up first,
  -- ring-timeout fired, double-tap on Decline) -> no-op success.
  if v_row.callee_id = v_user
     and v_row.status in ('cancelled','declined','missed','completed','failed') then
    return v_row;
  end if;

  raise exception 'call not available to decline (wrong callee, wrong audience, or call already answered)'
    using errcode = '55000';
end $$;


--
-- Name: delete_delivery(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delete_delivery(p_delivery_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_row   public.deliveries%rowtype;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if not public.is_manager() then
    raise exception 'delete requires admin or dispatcher role' using errcode = '42501';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required for delete' using errcode = '22023';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;

  -- Idempotent re-call: already deleted is a no-op (not an error).
  if v_row.deleted_at is not null then
    return;
  end if;

  -- FINAL_STATUSES gate. delivered/rolled_over need surgical handling we
  -- haven't built (stock release, parent/child chain). Refuse here — EXCEPT for
  -- waybills/pickups/failed-deliveries, which are money-only records (no stock,
  -- no rollover chain) created directly as 'delivered'. Soft-deleting one is the
  -- clean way to undo a mistaken charge — it simply drops out of reconciliation
  -- (which filters deleted_at). Reverting them to 'pending' is blocked elsewhere
  -- because it poisons the EOD rollover, so delete is their only undo path.
  if v_row.current_status in ('delivered', 'rolled_over')
     and v_row.order_type <> 'waybill' then
    raise exception 'cannot delete a delivery in status % — correct via the state machine first', v_row.current_status
      using errcode = '22023';
  end if;

  update public.deliveries
     set deleted_at = now(),
         updated_at = now()
   where id = p_delivery_id;

  -- Resolve the delivery's open issues/threads: a deleted order has nothing to
  -- action. read_at is the existing resolution signal the ops issue feed and
  -- unread badges key off, so this clears the phantom everywhere at once.
  update public.delivery_messages
     set read_at = now()
   where delivery_id = p_delivery_id
     and read_at is null;

  perform public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := jsonb_build_object(
                       'deleted_at', null,
                       'current_status', v_row.current_status,
                       'assigned_agent_id', v_row.assigned_agent_id
                     ),
    p_new         := jsonb_build_object('deleted_at', now()),
    p_reason      := btrim(p_reason)
  );
end;
$$;


--
-- Name: FUNCTION delete_delivery(p_delivery_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.delete_delivery(p_delivery_id uuid, p_reason text) IS 'Manager (admin + dispatcher) soft delete. Sets deleted_at; refuses delivered/rolled_over. Idempotent on already-deleted rows.';


--
-- Name: delivery_rate_history(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.delivery_rate_history(p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date) RETURNS TABLE(day date, delivered integer, available integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_to   date := coalesce(p_to, (now() at time zone 'Africa/Lagos')::date);
  v_from date := coalesce(p_from, v_to - 29);
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'delivery rate requires admin or dispatcher role' using errcode = '42501';
  end if;
  if v_from > v_to then
    raise exception 'from date % is after to date %', v_from, v_to using errcode = '22007';
  end if;
  if v_to - v_from > 92 then
    raise exception 'range too large (% days); max 92', (v_to - v_from) using errcode = '22003';
  end if;

  return query
  with grp as (
    select scheduled_date,
           sibling_group_key,
           bool_or(is_delivered) as dl,
           bool_or(is_available) as av
      from public._delivery_rate_base
     where scheduled_date between v_from and v_to
     group by scheduled_date, sibling_group_key
  )
  select
    scheduled_date as day,
    count(*) filter (where dl)::int,
    count(*) filter (where av)::int
  from grp
  group by scheduled_date
  order by scheduled_date;
end;
$$;


--
-- Name: discard_inbound(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.discard_inbound(p_inbound_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$

begin

  if not public.is_manager() then

    raise exception 'permission denied' using errcode = '42501';

  end if;

  perform public._assert_holds_lock('bot_inbound', p_inbound_id);



  update public.bot_inbound_messages

     set status = 'error',

         error_text = 'discarded: ' || coalesce(nullif(trim(p_reason), ''), 'no reason given'),

         processed_at = now()

   where id = p_inbound_id;

  if not found then

    raise exception 'inbound not found' using errcode = 'P0002';

  end if;



  delete from public.edit_locks

   where entity_type='bot_inbound' and entity_id=p_inbound_id;

end $$;


--
-- Name: effective_rate(uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.effective_rate(p_location_id uuid, p_client_id uuid, p_agent_id uuid DEFAULT NULL::uuid) RETURNS TABLE(charged numeric, agent_payment numeric)
    LANGUAGE plpgsql STABLE
    SET search_path TO 'public'
    AS $$
declare
  v_base_charged       numeric;
  v_base_agent_payment numeric;
  v_client_ceiling     numeric;
  v_agent_bonus        numeric := 0;
begin
  select rc.charged, rc.agent_payment
    into v_base_charged, v_base_agent_payment
    from public.rate_card rc
   where rc.location_id     = p_location_id
     and rc.effective_until is null
   order by rc.effective_from desc
   limit 1;

  if v_base_charged is null then
    return;
  end if;

  if p_client_id is not null then
    select c.max_charge_per_delivery into v_client_ceiling
      from public.clients c
     where c.id = p_client_id;
    if v_client_ceiling is not null and v_base_charged > v_client_ceiling then
      v_base_charged := v_client_ceiling;
    end if;
  end if;

  if p_agent_id is not null then
    select coalesce(u.agent_payment_bonus, 0) into v_agent_bonus
      from public.users u
     where u.id = p_agent_id;
  end if;

  charged       := v_base_charged;
  agent_payment := v_base_agent_payment + coalesce(v_agent_bonus, 0);
  return next;
end;
$$;


--
-- Name: end_call(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.end_call(p_call_id uuid) RETURNS public.calls
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user uuid := auth.uid();
  v_row  public.calls%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;

  update public.calls
     set status           = 'completed',
         ended_at         = now(),
         duration_seconds = greatest(0,
           extract(epoch from (now() - started_at))::int
         )
   where id      = p_call_id
     and status  = 'accepted'
     and (caller_id = v_user or callee_id = v_user)
   returning * into v_row;

  if found then
    perform public.write_audit(
      'call', v_row.id,
      jsonb_build_object('status', 'accepted'),
      jsonb_build_object(
        'status',           'completed',
        'ended_at',         v_row.ended_at,
        'duration_seconds', v_row.duration_seconds
      ),
      'ended by ' || (case when v_row.caller_id = v_user then 'caller' else 'callee' end),
      v_user
    );
    return v_row;
  end if;

  select * into v_row from public.calls where id = p_call_id;
  if not found then
    raise exception 'call not found' using errcode = 'P0002';
  end if;

  -- Participant hanging up a call that already ended -> no-op success.
  if (v_row.caller_id = v_user or v_row.callee_id = v_user)
     and v_row.status in ('cancelled','declined','missed','completed','failed') then
    return v_row;
  end if;

  raise exception 'call not available to end (not a participant, or call is not in progress)'
    using errcode = '55000';
end $$;


--
-- Name: expire_ringing_calls(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.expire_ringing_calls() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_count integer;
begin
  with expired as (
    update public.calls
       set status   = 'missed',
           ended_at = now()
     where status        = 'ringing'
       and ringing_until < now()
    returning id
  )
  select count(*) into v_count from expired;
  return v_count;
end $$;


--
-- Name: delivery_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    delivery_id uuid NOT NULL,
    author_id uuid NOT NULL,
    author_role text NOT NULL,
    issue_type text,
    note text,
    client_uuid uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    read_at timestamp with time zone,
    CONSTRAINT delivery_messages_author_role_check CHECK ((author_role = ANY (ARRAY['agent'::text, 'admin'::text, 'dispatcher'::text, 'rep'::text]))),
    CONSTRAINT delivery_messages_issue_type_check CHECK ((issue_type = ANY (ARRAY['wrong_address'::text, 'cant_reach_client'::text, 'payment_dispute'::text, 'product_issue'::text, 'not_my_route'::text, 'no_product'::text, 'other'::text])))
);


--
-- Name: flag_delivery_issue(uuid, text, text, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.flag_delivery_issue(p_delivery_id uuid, p_issue_type text, p_note text, p_new_status text, p_client_uuid uuid) RETURNS public.delivery_messages
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user     uuid := auth.uid();
  v_status   text;
  v_agent    uuid;
  v_existing public.delivery_messages%rowtype;
  v_new      public.delivery_messages%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if p_client_uuid is null then
    raise exception 'p_client_uuid is required' using errcode = '22023';
  end if;

  if p_issue_type is null or p_issue_type not in (
    'wrong_address','cant_reach_client','payment_dispute',
    'product_issue','not_my_route','other'
  ) then
    raise exception 'invalid issue_type: %', coalesce(p_issue_type, 'null')
      using errcode = '22023';
  end if;

  -- Idempotency: if this client_uuid already produced a message, return it.
  select * into v_existing
    from public.delivery_messages
   where client_uuid = p_client_uuid;
  if found then
    return v_existing;
  end if;

  select current_status, assigned_agent_id
    into v_status, v_agent
    from public.deliveries
   where id = p_delivery_id;
  if v_status is null then
    raise exception 'delivery not found' using errcode = 'P0002';
  end if;
  if v_agent is null or v_agent <> v_user then
    raise exception 'only the assigned agent can flag this delivery'
      using errcode = '42501';
  end if;
  if public._dm_is_terminal_status(v_status) then
    raise exception 'cannot flag a terminal delivery (status %)', v_status
      using errcode = '22023';
  end if;

  if p_new_status is not null then
    perform public.change_delivery_status(
      p_client_uuid => p_client_uuid::text,
      p_delivery_id => p_delivery_id,
      p_to_status   => p_new_status,
      p_reason      => p_issue_type,
      p_notes       => p_note
    );
  end if;

  insert into public.delivery_messages (
    delivery_id, author_id, author_role, issue_type, note, client_uuid
  ) values (
    p_delivery_id, v_user, 'agent', p_issue_type,
    nullif(trim(coalesce(p_note,'')), ''), p_client_uuid
  ) returning * into v_new;

  perform public.write_audit(
    'delivery_message', v_new.id,
    null,
    jsonb_build_object(
      'issue_type', p_issue_type, 'note', p_note, 'new_status', p_new_status
    ),
    'flag', null
  );

  return v_new;
end $$;


--
-- Name: get_ai_config(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_ai_config(p_key text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select value from public.ai_config where key = p_key;
$$;


--
-- Name: get_delivery_handoff_state(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_delivery_handoff_state(p_delivery_id uuid) RETURNS TABLE(handed_at timestamp with time zone, handed_by_name text, from_agent_name text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  with latest_handoff as (
    select
      a.id,
      a.changed_at,
      a.changed_by_user_id,
      nullif(a.old_value, '')::uuid as old_agent_id
    from public.audit_log a
    where a.entity_type = 'delivery'
      and a.entity_id = p_delivery_id
      and a.field_name = 'assigned_agent_id'
      and a.new_value = auth.uid()::text
      and exists (
        select 1
        from public.audit_log prior
        where prior.entity_type = 'delivery'
          and prior.entity_id = a.entity_id
          and prior.field_name = 'assigned_agent_id'
          and (prior.changed_at, prior.id) < (a.changed_at, a.id)
      )
    order by a.changed_at desc, a.id desc
    limit 1
  )
  select
    r.changed_at as handed_at,
    actor.display_name as handed_by_name,
    previous_agent.display_name as from_agent_name
  from public.deliveries d
  join latest_handoff r on true
  left join public.users actor on actor.id = r.changed_by_user_id
  left join public.users previous_agent on previous_agent.id = r.old_agent_id
  where d.id = p_delivery_id
    and d.assigned_agent_id = auth.uid()
    and d.deleted_at is null
    and r.changed_at > coalesce(
      (
        select max(h.changed_at)
        from public.delivery_status_history h
        where h.delivery_id = d.id
          and h.changed_by_user_id = auth.uid()
      ),
      '-infinity'::timestamptz
    );
$$;


--
-- Name: get_delivery_pay_state(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_delivery_pay_state(p_delivery_ids uuid[]) RETURNS TABLE(delivery_id uuid, mode text, state text, amount numeric, margin numeric, business_date date, multiplier numeric, manual_exception boolean)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_admin boolean:=public.is_admin(); v_actor uuid:=auth.uid();
begin
  if v_actor is null or not (v_admin or exists(select 1 from public.users where id=v_actor and role='agent')) then
    raise exception 'admin or agent role required' using errcode='42501'; end if;
  if p_delivery_ids is null or cardinality(p_delivery_ids)>500 then
    raise exception 'provide at most 500 delivery ids' using errcode='22023'; end if;
  return query
  with visible as (
    select d.id,d.charged_snapshot,d.agent_payment_snapshot,e.policy_applied,e.active,
      e.final_state,e.final_amount,e.business_date,e.multiplier,e.manual_amount,
      (v_admin or e.rider_id=v_actor) owns_earning
    from public.deliveries d left join public.same_customer_earnings e on e.delivery_id=d.id
    where d.id=any(p_delivery_ids) and d.deleted_at is null
      and (v_admin or d.assigned_agent_id=v_actor or (e.policy_applied and e.rider_id=v_actor))
  ), classified as (
    select *,case
      when coalesce(policy_applied,false) and not owns_earning then 'not_earned'
      when coalesce(policy_applied,false) and not active then 'reversed'
      when coalesce(policy_applied,false) and final_state='ready' and final_amount is not null then 'ready'
      when coalesce(policy_applied,false) then 'pending'
      else 'legacy' end resolved_state
    from visible
  ), priced as (
    select *,case when resolved_state='ready' then final_amount
      when resolved_state='legacy' then agent_payment_snapshot end payable
    from classified
  )
  select id,case when coalesce(policy_applied,false) then 'final' else 'legacy' end,
    resolved_state,payable,
    case when v_admin and resolved_state in ('ready','legacy') then coalesce(charged_snapshot,0)-coalesce(payable,0) end,
    case when owns_earning and policy_applied then priced.business_date end,
    case when owns_earning and policy_applied then priced.multiplier end,
    coalesce(owns_earning and policy_applied and manual_amount is not null,false)
  from priced order by id;
end $$;


--
-- Name: get_delivery_reda_charge(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_delivery_reda_charge(p_delivery_id uuid) RETURNS TABLE(charged_snapshot numeric, recommended_charge numeric, client_day_settled boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_row public.deliveries%rowtype;
begin
  if not public.is_manager() then
    raise exception 'viewing a delivery charge requires admin or dispatcher role'
      using errcode = '42501';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id;
  if not found or v_row.deleted_at is not null then
    raise exception 'delivery not found' using errcode = 'P0002';
  end if;

  return query
  select
    v_row.charged_snapshot,
    (
      select er.charged
        from public.effective_rate(
          v_row.location_id, v_row.client_id, v_row.assigned_agent_id
        ) er
       limit 1
    ),
    exists (
      select 1 from public.settlements s
       where s.subject_type = 'client'
         and s.subject_id = v_row.client_id
         and s.period_date = v_row.scheduled_date
         and s.voided_at is null
    );
end;
$$;


--
-- Name: get_flag(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_flag(p_key text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('enabled', enabled, 'value', value)
  from public.feature_flags where key = p_key;
$$;


--
-- Name: get_negative_margin_delivery_ids(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_negative_margin_delivery_ids(p_limit integer DEFAULT 200) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_result jsonb;
begin
  if not public.is_admin() then raise exception 'admin role required' using errcode='42501'; end if;
  with priced as (
    select d.id,d.created_at,coalesce(d.charged_snapshot,0)-case
      when coalesce(e.policy_applied,false) then case when e.active and e.final_state='ready' then e.final_amount end
      else coalesce(d.agent_payment_snapshot,0) end margin
    from public.deliveries d left join public.same_customer_earnings e on e.delivery_id=d.id
    where d.deleted_at is null and d.order_type='delivery'
  ), negative as (
    select * from priced where margin<0
  ), page as (
    select * from negative order by created_at desc,id desc limit greatest(0,least(coalesce(p_limit,200),200))
  )
  select jsonb_build_object('total_count',(select count(*) from negative),
    'delivery_ids',coalesce((select jsonb_agg(id order by created_at desc,id desc) from page),'[]'::jsonb)) into v_result;
  return v_result;
end $$;


--
-- Name: get_replacement_details(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_replacement_details(p_delivery_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_delivery record;
  v_result jsonb;
begin
  select * into v_delivery from public.deliveries where id = p_delivery_id and deleted_at is null;
  if not found or v_delivery.order_type <> 'replacement' then return null; end if;
  if not (
    public.is_admin_or_dispatcher()
    or public.current_user_role() = 'warehouse'
    or (public.current_user_role() = 'agent' and v_delivery.assigned_agent_id = auth.uid())
  ) then raise exception 'permission denied' using errcode = '42501'; end if;

  select jsonb_build_object(
    'job', jsonb_build_object(
      'delivery_id', r.delivery_id,
      'original_delivery_id', r.original_delivery_id,
      'reason', r.reason,
      'notes', r.notes,
      'success_client_charge', case when public.is_admin() then r.success_client_charge else null end,
      'success_agent_payment', case
        when public.is_manager() or v_delivery.assigned_agent_id = auth.uid()
          then r.success_agent_payment else null end
    ),
    'returns', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', ri.id,
        'product_catalog_id', ri.product_catalog_id,
        'product_name', pc.product_name,
        'quantity_expected', ri.quantity_expected,
        'vendor_instruction', ri.vendor_instruction,
        'actual_quantity', ri.actual_quantity,
        'reported_condition', ri.reported_condition,
        'outcome', ri.outcome,
        'custody_state', ri.custody_state,
        'current_holder_id', ri.current_holder_id,
        'current_holder_name', h.display_name,
        'rider_notes', ri.rider_notes,
        'collected_at', ri.collected_at,
        'warehouse_received_at', ri.warehouse_received_at
      ) order by ri.created_at)
      from public.replacement_return_items ri
      join public.product_catalog pc on pc.id = ri.product_catalog_id
      left join public.users h on h.id = ri.current_holder_id
      where ri.delivery_id = p_delivery_id
    ), '[]'::jsonb),
    'attempts', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', a.id,
        'outcome', a.outcome,
        'status_after', a.status_after,
        'notes', a.notes,
        'next_attempt_date', a.next_attempt_date,
        'customer_paid', a.customer_paid, 'payment_method', a.payment_method,
        'payment_received_by', a.payment_received_by, 'cash_pos_fee', a.cash_pos_fee,
        'client_charge', case when public.is_admin() then a.client_charge else null end,
        'agent_payment', case
          when public.is_manager() or a.assigned_agent_id = auth.uid()
            then a.agent_payment else null end,
        'attempted_at', a.attempted_at,
        'attempted_by_name', u.display_name
      ) order by a.attempted_at desc)
      from public.replacement_attempts a
      join public.users u on u.id = a.attempted_by_user_id
      where a.delivery_id = p_delivery_id
    ), '[]'::jsonb)
  ) into v_result
  from public.replacement_jobs r where r.delivery_id = p_delivery_id;
  return v_result;
end;
$$;


--
-- Name: get_same_customer_config(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_same_customer_config() RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ begin
  if auth.uid() is null then raise exception 'authentication required' using errcode='42501'; end if;
  return jsonb_build_object('discovery_enabled',
    (public.is_manager() and coalesce((select enabled from public.feature_flags where key='same_customer_discovery'),false)),
    'normalization_version',1,'shadow_review_enabled',public.is_admin() and (
      coalesce((select enabled from public.feature_flags where key='same_customer_pay_shadow'),false)
      or exists(select 1 from public.same_customer_earnings)));
end $$;


--
-- Name: get_same_customer_orders(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_same_customer_orders(p_day date, p_group_id text) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $_$ declare v_ids uuid[]; v_kind text; v_orders jsonb;
begin
  if not public.is_manager() then raise exception 'admin or dispatcher role required' using errcode='42501'; end if;
  if not coalesce((select enabled from public.feature_flags where key='same_customer_discovery'),false) then
    return null; end if;
  select g.delivery_ids,g.match_kind into v_ids,v_kind
    from public._same_customer_day_groups(p_day) g where g.group_id=p_group_id;
  -- A detail-screen entry keeps split/standalone orders reachable for reset.
  if v_ids is null and p_group_id ~ '^order:[0-9a-f-]{36}$' then
    select array[d.id],'single' into v_ids,v_kind from public.deliveries d
      where d.id=substring(p_group_id from 7)::uuid and d.scheduled_date=p_day
        and d.deleted_at is null and d.order_type='delivery';
  end if;
  if v_ids is null then return null; end if;
  select jsonb_agg(jsonb_build_object(
    'id',d.id,'customer_name',d.customer_name,'customer_phone',d.customer_phone,
    'customer_phone_alt',d.customer_phone_alt,'raw_address',d.raw_address,
    'scheduled_date',d.scheduled_date,'status',d.current_status,
    'client_name',c.name,'agent_id',d.assigned_agent_id,'agent_name',u.display_name,
    'revision',d.same_customer_match_revision,'match_mode',d.same_customer_match_mode,'instructions',d.delivery_instructions,
    'customer_price',d.customer_price,
    'agent_payment',case when public.is_admin() then d.agent_payment_snapshot end,
    'items',coalesce((select jsonb_agg(jsonb_build_object('product_name',p.product_name,
      'quantity',i.quantity_ordered) order by p.product_name,i.id)
      from public.delivery_items i join public.product_catalog p on p.id=i.product_catalog_id
      where i.delivery_id=d.id),'[]'::jsonb)) order by d.id) into v_orders
  from public.deliveries d join public.clients c on c.id=d.client_id
  left join public.users u on u.id=d.assigned_agent_id where d.id=any(v_ids);
  return jsonb_build_object('group_id',p_group_id,'day',p_day,'match_kind',v_kind,'orders',v_orders);
end $_$;


--
-- Name: get_same_customer_pay_group(uuid, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_same_customer_pay_group(p_group_id uuid, p_after uuid DEFAULT NULL::uuid, p_limit integer DEFAULT 50) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare g public.same_customer_pay_groups%rowtype; v_rows jsonb; v_count integer; v_total numeric;
  v_next uuid; v_name text; v_limit integer:=greatest(1,least(coalesce(p_limit,50),100));
begin
  if not public.is_admin() then raise exception 'admin role required for pay-group review' using errcode='42501'; end if;
  select * into g from public.same_customer_pay_groups where id=p_group_id;
  if not found then return null; end if;
  select display_name into v_name from public.users where id=g.rider_id;
  with ranked as (
    select e.*,row_number() over(order by recorded_at,completion_event_id,delivery_id) position
    from public.same_customer_earnings e where group_id=p_group_id and active
  ), amounts as (
    select *,case when g.state<>'rate_mismatch' then coalesce(manual_amount,round(base_fee*case when position=1 then 1 else 0.5 end,2)) end proposal
    from ranked
  ), page as (
    select * from amounts where p_after is null or delivery_id>p_after order by delivery_id limit v_limit
  )
  select (select count(*) from amounts),(select sum(proposal) from amounts),
    coalesce(jsonb_agg(jsonb_build_object('delivery_id',p.delivery_id,'customer_name',d.customer_name,'vendor_name',c.name,
      'normal_fee',p.base_fee,'multiplier',case when p.position=1 then 1 else 0.5 end,'current_payable',case when p.policy_applied then p.final_amount else d.agent_payment_snapshot end,
      'manual_amount',p.manual_amount,'manual_reason',p.manual_reason,'proposed_amount',p.proposal,'accounting_date',p.accounting_date)
      order by p.delivery_id),'[]'::jsonb),
    case when exists(select 1 from amounts where delivery_id>(select delivery_id from page order by delivery_id desc limit 1))
      then (select delivery_id from page order by delivery_id desc limit 1) end
    into v_count,v_total,v_rows,v_next from page p join public.deliveries d on d.id=p.delivery_id join public.clients c on c.id=d.client_id;
  return jsonb_build_object('group_id',g.id,'revision',g.revision,'state',g.state,'rider_name',v_name,'business_date',g.business_date,
    'mode',case when exists(select 1 from public.same_customer_earnings where group_id=g.id and active and policy_applied) then 'final' else 'shadow' end,'total_count',v_count,'proposed_total',v_total,'orders',v_rows,'next_cursor',v_next);
end $$;


--
-- Name: get_same_customer_shadow_pay(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_same_customer_shadow_pay(p_delivery_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_result jsonb;
begin
  if not public.is_admin() then raise exception 'admin role required for shadow pay' using errcode='42501'; end if;
  select jsonb_build_object('mode',case when e.policy_applied then 'final' when e.final_state='legacy' then 'legacy' else 'shadow' end,'delivery_id',e.delivery_id,'normal_fee',e.base_fee,
    'multiplier',e.multiplier,'expected_amount',case when e.policy_applied or e.final_state='legacy' then e.final_amount else e.expected_amount end,'current_payable_amount',case when e.policy_applied then e.final_amount else d.agent_payment_snapshot end,
    'business_date',e.business_date,'accounting_date',e.accounting_date,'state',case when e.policy_applied then e.final_state when e.final_state='legacy' then 'ready' else e.pay_state end,
    'review_reason',case when e.policy_applied then e.final_review_reason else e.review_reason end,'active',e.active,'revision',e.revision,'group_id',e.group_id,'manual_amount',e.manual_amount,'manual_reason',e.manual_reason,
    'reported_occurred_at',e.occurred_at,'recorded_at',e.recorded_at,'rider_name',u.display_name,
    'last_normal_fee_review',(select jsonb_build_object('normal_fee',r.normal_fee,'reason',r.reason,
      'reviewed_by',a.display_name,'reviewed_at',r.created_at) from public.same_customer_normal_fee_reviews r
      join public.users a on a.id=r.actor_id where r.delivery_id=e.delivery_id and r.completion_event_id=e.completion_event_id
      order by r.created_at desc,r.request_id desc limit 1),'last_date_review',(select jsonb_build_object('accepted_day',r.accepted_day,'reason',r.reason,
      'reviewed_by',a.display_name,'reviewed_at',r.created_at) from public.same_customer_completion_reviews r
      join public.users a on a.id=r.actor_id where r.delivery_id=e.delivery_id and r.completion_event_id=e.completion_event_id
      order by r.created_at desc,r.request_id desc limit 1))
    into v_result from public.same_customer_earnings e join public.deliveries d on d.id=e.delivery_id
    join public.users u on u.id=e.rider_id where e.delivery_id=p_delivery_id;
  return v_result;
end $$;


--
-- Name: get_sibling_contact(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_sibling_contact(p_delivery_id uuid) RETURNS TABLE(sibling_delivery_id uuid, agent_id uuid, agent_name text, status text, status_label text, category text, worked_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_d public.deliveries%rowtype;
begin
  select * into v_d from public.deliveries where id = p_delivery_id;
  if not found then return; end if;

  -- Only the delivery's own assigned agent, or ops, may ask about its siblings.
  -- Mirrors who can see the delivery itself; the function is SECURITY DEFINER so
  -- it can read the sibling row RLS hides from the agent.
  if not (public.is_admin_or_dispatcher() or v_d.assigned_agent_id = auth.uid()) then
    raise exception 'not authorised' using errcode = '42501';
  end if;

  return query
  select s.id,
         s.assigned_agent_id,
         coalesce(u.display_name, 'another agent')::text,
         s.current_status,
         coalesce(sd.label, s.current_status)::text,
         sd.category,
         coalesce(h.last_at, s.updated_at)
    from public._find_sibling_deliveries(p_delivery_id) s
    join public.delivery_status_defs sd on sd.status = s.current_status
    left join public.users u on u.id = s.assigned_agent_id
    left join lateral (
      select max(changed_at) as last_at
        from public.delivery_status_history
       where delivery_id = s.id
    ) h on true
   where s.deleted_at is null
     -- only OTHER agents' work (a row this same agent holds isn't a coordination
     -- risk and would read as a confusing self-reference)
     and s.assigned_agent_id is distinct from v_d.assigned_agent_id
     -- contacted/active or already fulfilled — never a dead duplicate
     and (sd.category in ('active', 'soft_failure')
          or s.current_status in ('delivered', 'picked_up', 'waybilled'))
   order by coalesce(h.last_at, s.updated_at) desc
   limit 1;
end;
$$;


--
-- Name: get_vendor_example_messages(uuid, integer, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_vendor_example_messages(p_client_id uuid, p_limit integer DEFAULT 5, p_exclude_delivery uuid DEFAULT NULL::uuid) RETURNS TABLE(raw_text text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select m.raw_text
    from public.bot_inbound_messages m
    join public.deliveries d on d.id = m.delivery_id
   where m.status = 'created_delivery'
     and d.client_id = p_client_id
     and d.deleted_at is null
     and m.raw_text is not null
     and length(btrim(m.raw_text)) > 0
     and (p_exclude_delivery is null or m.delivery_id <> p_exclude_delivery)
   order by m.received_at desc
   limit greatest(coalesce(p_limit, 5), 0);
$$;


--
-- Name: guard_replacement_delivery_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.guard_replacement_delivery_mutation() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
begin
  if tg_op = 'DELETE' then
    if old.order_type = 'replacement' and old.current_status = 'replacement_completed' then
      raise exception 'completed replacements cannot be deleted; reverse stock and custody explicitly'
        using errcode = '22023';
    end if;
    return old;
  end if;

  if old.order_type = 'replacement'
     and old.current_status = 'replacement_completed'
     and new.deleted_at is distinct from old.deleted_at then
    raise exception 'completed replacements cannot be deleted; reverse stock and custody explicitly'
      using errcode = '22023';
  end if;

  if new.order_type = 'replacement'
     and new.current_status in ('delivered','picked_up','waybilled','rolled_over') then
    raise exception 'use the replacement attempt/completion workflow for replacement jobs'
      using errcode = '22023';
  end if;
  if new.order_type <> 'replacement' and new.current_status = 'replacement_completed' then
    raise exception 'replacement_completed is only valid for replacement jobs'
      using errcode = '22023';
  end if;
  if old.order_type = 'replacement'
     and old.current_status = 'replacement_completed'
     and new.current_status is distinct from old.current_status then
    raise exception 'a completed replacement requires an explicit reversal workflow'
      using errcode = '22023';
  end if;
  return new;
end;
$$;


--
-- Name: heartbeat_edit_lock(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.heartbeat_edit_lock(p_entity_type text, p_entity_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  update public.edit_locks
     set acquired_at = now()
   where entity_type = p_entity_type
     and entity_id   = p_entity_id
     and user_id     = auth.uid();
end $$;


--
-- Name: initiate_call(uuid, uuid, uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.initiate_call(p_callee_id uuid, p_caller_device_uuid uuid, p_related_delivery_id uuid, p_client_uuid uuid, p_callee_audience text DEFAULT 'user'::text) RETURNS public.calls
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_caller   uuid := auth.uid();
  v_role     text;
  v_active   boolean;
  v_existing public.calls%rowtype;
  v_new      public.calls%rowtype;
begin
  if v_caller is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if p_caller_device_uuid is null then
    raise exception 'p_caller_device_uuid is required' using errcode = '22023';
  end if;
  if p_callee_audience not in ('user','ops_team') then
    raise exception 'invalid p_callee_audience: %', p_callee_audience using errcode = '22023';
  end if;

  -- Audience-specific input shape.
  if p_callee_audience = 'user' then
    if p_callee_id is null then
      raise exception 'p_callee_id is required for user audience' using errcode = '22023';
    end if;
    if v_caller = p_callee_id then
      raise exception 'cannot call yourself' using errcode = '22023';
    end if;
  else
    if p_callee_id is not null then
      raise exception 'p_callee_id must be null for ops_team audience' using errcode = '22023';
    end if;
  end if;

  -- Caller must be active. Role gate: agents may only call the team.
  select role, is_active into v_role, v_active
    from public.users where id = v_caller;
  if not coalesce(v_active, false) then
    raise exception 'caller is not an active user' using errcode = '42501';
  end if;
  if v_role = 'agent' and p_callee_audience <> 'ops_team' then
    raise exception 'agents may only place team calls' using errcode = '42501';
  end if;

  -- Idempotency: same client_uuid → return prior row.
  if p_client_uuid is not null then
    select * into v_existing from public.calls where client_uuid = p_client_uuid;
    if found then return v_existing; end if;
  end if;

  -- For user audience, callee must exist and be active.
  if p_callee_audience = 'user' then
    select is_active into v_active from public.users where id = p_callee_id;
    if not coalesce(v_active, false) then
      raise exception 'callee is not an active user' using errcode = '42501';
    end if;
  end if;

  -- Optional delivery FK must resolve to a real, non-deleted row.
  if p_related_delivery_id is not null then
    if not exists (
      select 1 from public.deliveries
       where id = p_related_delivery_id and deleted_at is null
    ) then
      raise exception 'related delivery not found' using errcode = 'P0002';
    end if;
  end if;

  begin
    insert into public.calls (
      caller_id, callee_id, callee_audience, caller_device_uuid,
      status, related_delivery_id, client_uuid, ringing_until
    ) values (
      v_caller, p_callee_id, p_callee_audience, p_caller_device_uuid,
      'ringing', p_related_delivery_id, p_client_uuid,
      now() + interval '45 seconds'
    ) returning * into v_new;
  exception when unique_violation then
    -- calls_one_ringing_per_caller or _per_callee partial unique index.
    raise exception 'caller or callee already has a ringing call'
      using errcode = '55000';
  end;

  perform public.write_audit(
    'call', v_new.id,
    null,
    jsonb_build_object(
      'status',              'ringing',
      'caller_id',           v_caller,
      'callee_id',           p_callee_id,
      'callee_audience',     p_callee_audience,
      'related_delivery_id', p_related_delivery_id
    ),
    case when p_callee_audience = 'ops_team' then 'team-call initiated' else 'initiated by caller' end,
    v_caller
  );

  return v_new;
end $$;


--
-- Name: is_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_admin() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    select coalesce((select role from public.users where id = auth.uid()) = 'admin', false);
$$;


--
-- Name: is_admin_or_dispatcher(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_admin_or_dispatcher() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
    select coalesce((select role from public.users where id = auth.uid())
                    in ('admin','dispatcher','rep'), false);
$$;


--
-- Name: FUNCTION is_admin_or_dispatcher(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.is_admin_or_dispatcher() IS 'True for operational-coordinator roles: admin, dispatcher, rep. Despite the legacy name, rep is included because rep is a stock-less dispatcher variant — every dispatcher capability EXCEPT stock access. Stock-only checks use is_admin() or the stricter stock_adjustments SELECT policy.';


--
-- Name: is_manager(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_manager() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce((select role from public.users where id = auth.uid())
                  in ('admin','dispatcher'), false);
$$;


--
-- Name: FUNCTION is_manager(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.is_manager() IS 'True for managers: admin + dispatcher. Excludes rep. Used for the review queue and all order-mutation paths, which Uzo restricted to managers (2026-06-10). Contrast is_admin_or_dispatcher(), which includes rep for the capabilities reps keep (deliveries read, follow-ups, comms, audit, calls).';


--
-- Name: is_warehouse(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_warehouse() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select coalesce(
    (select role from public.users where id = auth.uid()) = 'warehouse',
    false
  );
$$;


--
-- Name: list_agent_count_products(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_agent_count_products() RETURNS TABLE(id uuid, product_name text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select p.id, p.product_name::text from public.product_catalog p
  where p.is_active and exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'agent' and u.is_active)
  order by p.product_name;
$$;


--
-- Name: list_client_payments(uuid, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_client_payments(p_client_id uuid, p_from date, p_to date) RETURNS TABLE(payment_id uuid, payment_date date, amount numeric, received_at timestamp with time zone, received_by_name text, note text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin() then
    raise exception 'only admin can view payment records' using errcode = '42501';
  end if;
  return query
  select p.id, p.payment_date, p.amount, p.received_at, u.display_name, p.note
    from public.client_payments p
    left join public.users u on u.id = p.received_by
   where p.client_id = p_client_id
     and p.payment_date between p_from and p_to
     and p.voided_at is null
   order by p.payment_date desc, p.received_at desc;
end;
$$;


--
-- Name: list_client_payouts(uuid, date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_client_payouts(p_client_id uuid, p_from date, p_to date) RETURNS TABLE(payout_id uuid, payout_date date, amount numeric, paid_at timestamp with time zone, paid_by_name text, note text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin() then
    raise exception 'only admin can view payout records' using errcode = '42501';
  end if;
  return query
  select p.id, p.payout_date, p.amount, p.paid_at, u.display_name, p.note
    from public.client_payouts p
    left join public.users u on u.id = p.paid_by
   where p.client_id = p_client_id
     and p.payout_date between p_from and p_to
     and p.voided_at is null
   order by p.payout_date desc, p.paid_at desc;
end;
$$;


--
-- Name: list_customer_blacklist(boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_customer_blacklist(p_include_removed boolean DEFAULT false) RETURNS TABLE(id uuid, phone_normalized text, phone_display text, reason text, source_delivery_id uuid, added_by uuid, added_by_name text, added_at timestamp with time zone, removed_by uuid, removed_by_name text, removed_at timestamp with time zone, removal_note text, blocked_count integer, last_blocked_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select b.id, b.phone_normalized, b.phone_display, b.reason, b.source_delivery_id,
         b.added_by, a.display_name::text, b.added_at,
         b.removed_by, r.display_name::text, b.removed_at, b.removal_note,
         coalesce(m.n, 0)::integer, m.last_at
    from public.customer_blacklist b
    left join public.users a on a.id = b.added_by
    left join public.users r on r.id = b.removed_by
    left join lateral (
      select count(*) as n, max(i.received_at) as last_at
        from public.bot_inbound_messages i
       where i.status = 'blocked'
         and i.parse_result->'blacklist'->>'entry_id' = b.id::text
    ) m on true
   where coalesce(p_include_removed, false) or b.removed_at is null
   order by (b.removed_at is null) desc, b.added_at desc;
end;
$$;


--
-- Name: list_delivery_history_chain(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_delivery_history_chain(p_delivery_id uuid) RETURNS TABLE(id uuid, delivery_id uuid, scheduled_date date, is_current boolean, chain_depth integer, from_status text, to_status text, reason text, notes text, changed_at timestamp with time zone, effective_at timestamp with time zone, changed_by_user_id uuid, changed_by_name text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  with recursive chain as (
    select d.id, d.scheduled_date, d.parent_delivery_id, 0 as depth
      from public.deliveries d
     where d.id = p_delivery_id
       and auth.uid() is not null
    union all
    select p.id, p.scheduled_date, p.parent_delivery_id, c.depth + 1
      from public.deliveries p
      join chain c on p.id = c.parent_delivery_id
     where c.depth < 20   -- defensive: parent chains can't cycle, but never loop
  )
  select
    h.id,
    h.delivery_id,
    c.scheduled_date,
    (c.depth = 0)            as is_current,
    c.depth                  as chain_depth,
    h.from_status,
    h.to_status,
    h.reason,
    h.notes,
    h.changed_at,
    h.effective_at,
    h.changed_by_user_id,
    u.display_name           as changed_by_name
  from chain c
  join public.delivery_status_history h on h.delivery_id = c.id
  left join public.users u on u.id = h.changed_by_user_id
  -- Oldest delivery first (highest depth), then chronological within each
  -- delivery. Depth-first (not pure effective_at) keeps each delivery's rows
  -- contiguous — the child's 'pending' and the parent's 'rolled_over' share the
  -- same rollover instant and would otherwise interleave.
  order by c.depth desc, h.effective_at asc, h.changed_at asc;
$$;


--
-- Name: list_failed_delivery_outcomes(date, date, text, uuid, uuid, text, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_failed_delivery_outcomes(p_from date, p_to date, p_kind text DEFAULT 'attempted'::text, p_agent_id uuid DEFAULT NULL::uuid, p_client_id uuid DEFAULT NULL::uuid, p_search text DEFAULT NULL::text, p_limit integer DEFAULT 500) RETURNS TABLE(id uuid, client_id uuid, product_catalog_id uuid, location_id uuid, assigned_agent_id uuid, parent_delivery_id uuid, customer_name text, customer_phone text, raw_address text, quantity_ordered integer, customer_price numeric, agent_payment_snapshot numeric, current_status text, created_via text, created_by_user_id uuid, created_date date, scheduled_date date, created_at timestamp with time zone, updated_at timestamp with time zone, latest_history_id uuid, latest_changed_at timestamp with time zone, latest_notified boolean, rolled_from_status text, rolled_from_date date, rollover_count integer, order_type text, product_label text, sibling_group_key text, activity_at timestamp with time zone, client_name text, client_auto_cancel_soft_fails boolean, product_name text, location_name text, assigned_agent_name text, margin numeric, delivery_instructions text, assigned_at timestamp with time zone, latest_message_at timestamp with time zone, failure_kind text, failure_status text, failure_reason text, failed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_limit integer := least(greatest(coalesce(p_limit, 500), 1), 500);
  v_search text := nullif(trim(coalesce(p_search, '')), '');
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'failed-delivery outcomes require an operations role' using errcode = '42501';
  end if;
  if p_from is null or p_to is null or p_from > p_to then
    raise exception 'invalid failed-delivery date range' using errcode = '22007';
  end if;
  if p_to - p_from > 92 then
    raise exception 'failed-delivery date range cannot exceed 93 days' using errcode = '22003';
  end if;
  if p_kind not in ('attempted', 'auto_closed') then
    raise exception 'invalid failed-delivery outcome kind' using errcode = '22023';
  end if;

  return query
  with latest_terminal as (
    select distinct on (h.delivery_id)
      h.id as history_id,
      h.delivery_id,
      h.to_status,
      h.reason,
      h.notes,
      h.changed_at
    from public.delivery_status_history h
    join public.deliveries d on d.id = h.delivery_id
    where h.to_status in ('failed_delivery', 'cancelled', 'not_around', 'unserious', 'abandoned')
      and h.to_status = d.current_status
      and h.changed_at >= (p_from::timestamp at time zone 'Africa/Lagos')
      and h.changed_at < ((p_to + 1)::timestamp at time zone 'Africa/Lagos')
    order by h.delivery_id, h.changed_at desc, h.id desc
  ),
  candidates as (
    select
      d.*,
      case
        when public._norm_phone(d.customer_phone) is null
          or d.scheduled_date is null
          or d.items_fingerprint is null
          then 'solo:' || d.id::text
        else md5(
          public._norm_phone(d.customer_phone) || '|' ||
          d.items_fingerprint || '|' ||
          d.scheduled_date::text || '|' ||
          trim(both from regexp_replace(
            regexp_replace(lower(coalesce(d.raw_address, '')), '[^a-z0-9 ]+', ' ', 'g'),
            '\s+', ' ', 'g'
          ))
        )
      end as sibling_group_key,
      lt.history_id,
      lt.to_status as failure_status,
      lt.reason as stored_reason,
      lt.notes as stored_notes,
      lt.changed_at as failed_at,
      (
        (
          lt.to_status = 'failed_delivery'
          and (
            coalesce(lt.reason, '') like 'eod_auto_cancel:%'
            or lower(coalesce(lt.reason, '')) like 'postponed order came due%auto-cancelled%client policy%'
          )
        )
        or (
          lt.to_status = 'unserious'
          and (
            coalesce(lt.reason, '') like 'eod_disinterest_close:%'
            or lower(coalesce(lt.reason, '')) like 'carry-cap reached%'
          )
        )
      ) as is_auto_closed,
      (
        coalesce(lt.reason, '') = 'race lost, deduped on rollover'
        or lower(coalesce(lt.reason, '')) like 'duplicate not completed,%deduped on rollover'
        or lower(coalesce(lt.reason, '')) like '%handled the same order (%). closed as duplicate.%'
        or lower(coalesce(lt.reason, '')) like 'another agent already handled this order (%). closed as duplicate.%'
      ) as is_duplicate_closed
    from latest_terminal lt
    join public.deliveries d on d.id = lt.delivery_id
    where d.deleted_at is null
      and d.order_type = 'delivery'
      and (p_agent_id is null or d.assigned_agent_id = p_agent_id)
      and (p_client_id is null or d.client_id = p_client_id)
      and (
        v_search is null
        or d.customer_name ilike '%' || v_search || '%'
        or (
          length(regexp_replace(v_search, '\D', '', 'g')) >= 3
          and d.customer_phone ilike '%' || regexp_replace(v_search, '\D', '', 'g') || '%'
        )
      )
  ),
  candidate_groups as (
    select distinct c.sibling_group_key from candidates c
  ),
  group_state as (
    select
      member.sibling_group_key,
      bool_or(
        member.current_status = 'delivered'
        or exists (
          select 1
          from public.delivery_status_history available_history
          where available_history.delivery_id = member.id
            and available_history.to_status in ('available', 'available_evening')
        )
      ) as reached_available,
      bool_or(member.current_status = 'delivered') as was_delivered
    from (
      select
        d.id,
        d.current_status,
        case
          when public._norm_phone(d.customer_phone) is null
            or d.scheduled_date is null
            or d.items_fingerprint is null
            then 'solo:' || d.id::text
          else md5(
            public._norm_phone(d.customer_phone) || '|' ||
            d.items_fingerprint || '|' ||
            d.scheduled_date::text || '|' ||
            trim(both from regexp_replace(
              regexp_replace(lower(coalesce(d.raw_address, '')), '[^a-z0-9 ]+', ' ', 'g'),
              '\s+', ' ', 'g'
            ))
          )
        end as sibling_group_key
      from public.deliveries d
      where d.deleted_at is null
        and d.order_type = 'delivery'
    ) member
    join candidate_groups cg on cg.sibling_group_key = member.sibling_group_key
    group by member.sibling_group_key
  ),
  classified as (
    select
      c.*,
      case when c.is_auto_closed then 'auto_closed' else 'attempted' end as failure_kind,
      row_number() over (
        partition by c.sibling_group_key, c.is_auto_closed
        order by c.failed_at desc, c.id
      ) as group_rank
    from candidates c
    join group_state gs on gs.sibling_group_key = c.sibling_group_key
    where not c.is_duplicate_closed
      and not gs.was_delivered
      and (c.is_auto_closed or gs.reached_available)
  )
  select
    c.id,
    c.client_id,
    c.product_catalog_id,
    c.location_id,
    c.assigned_agent_id,
    c.parent_delivery_id,
    c.customer_name,
    c.customer_phone,
    c.raw_address,
    c.quantity_ordered,
    c.customer_price,
    null::numeric as agent_payment_snapshot,
    c.current_status,
    c.created_via,
    c.created_by_user_id,
    c.created_date,
    c.scheduled_date,
    c.created_at,
    c.updated_at,
    c.history_id as latest_history_id,
    c.failed_at as latest_changed_at,
    exists (
      select 1
      from public.delivery_client_notifications n
      where n.status_history_id = c.history_id
    ) as latest_notified,
    c.rolled_from_status,
    c.rolled_from_date,
    c.rollover_count,
    c.order_type,
    case
      when coalesce(items.item_count, 0) > 1 then items.item_count::text || ' items'
      when items.item_count = 1 then coalesce(items.first_item_name, 'Product')
      else coalesce(legacy_product.product_name, '—')
    end as product_label,
    c.sibling_group_key,
    c.failed_at as activity_at,
    client.name as client_name,
    client.auto_cancel_soft_fails as client_auto_cancel_soft_fails,
    null::text as product_name,
    location.name as location_name,
    agent.display_name as assigned_agent_name,
    null::numeric as margin,
    c.delivery_instructions,
    c.assigned_at,
    null::timestamptz as latest_message_at,
    c.failure_kind,
    c.failure_status,
    case
      when c.failure_kind = 'auto_closed' and c.failure_status = 'failed_delivery'
        then 'Auto-closed by client policy'
      when c.failure_kind = 'auto_closed' and lower(coalesce(c.stored_reason, '')) like 'carry-cap reached%'
        then 'Auto-closed after the maximum carry-over attempts'
      when c.failure_kind = 'auto_closed' and coalesce(c.stored_reason, '') like 'eod_disinterest_close:%'
        then 'Auto-closed after repeated customer disinterest'
      when c.failure_kind = 'auto_closed' then 'Automatically closed by end-of-day policy'
      when nullif(trim(c.stored_notes), '') is not null then trim(c.stored_notes)
      when nullif(trim(c.stored_reason), '') is not null
        and c.stored_reason not in ('cant_reach_client', 'wrong_address', 'payment_dispute', 'product_issue', 'other')
        then trim(c.stored_reason)
      when c.failure_status = 'cancelled' then 'Customer cancelled the order'
      when c.failure_status = 'not_around' then 'Customer was not around'
      when c.failure_status = 'unserious' then 'Customer was not ready to complete the order'
      when c.failure_status = 'abandoned' then 'Delivery attempt was abandoned'
      else 'Delivery could not be completed'
    end as failure_reason,
    c.failed_at
  from classified c
  join public.clients client on client.id = c.client_id
  left join public.locations location on location.id = c.location_id
  left join public.users agent on agent.id = c.assigned_agent_id
  left join public.product_catalog legacy_product on legacy_product.id = c.product_catalog_id
  left join lateral (
    select
      count(*)::integer as item_count,
      (array_agg(pc.product_name order by di.created_at))[1] as first_item_name
    from public.delivery_items di
    left join public.product_catalog pc on pc.id = di.product_catalog_id
    where di.delivery_id = c.id
  ) items on true
  where c.group_rank = 1
    and c.failure_kind = p_kind
  order by c.failed_at desc, c.id
  limit v_limit;
end;
$$;


--
-- Name: FUNCTION list_failed_delivery_outcomes(p_from date, p_to date, p_kind text, p_agent_id uuid, p_client_id uuid, p_search text, p_limit integer); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.list_failed_delivery_outcomes(p_from date, p_to date, p_kind text, p_agent_id uuid, p_client_id uuid, p_search text, p_limit integer) IS 'One ops-visible row per failed logical order. Attempted requires prior Available and no delivered sibling; auto_closed contains only known EOD client-policy closures. Range is failure-event date in Africa/Lagos.';


--
-- Name: list_location_changes(text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_location_changes(p_states text[] DEFAULT NULL::text[]) RETURNS TABLE(change_id uuid, delivery_id uuid, state text, customer_name text, raw_address text, current_status text, scheduled_date date, agent_id uuid, agent_name text, from_location_id uuid, from_location_name text, to_location_id uuid, to_location_name text, from_charged numeric, to_charged numeric, from_agent_payment numeric, to_agent_payment numeric, reason text, created_at timestamp with time zone, decided_at timestamp with time zone)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select c.id, c.delivery_id, c.state,
         d.customer_name, d.raw_address, d.current_status, d.scheduled_date,
         c.requested_by_agent_id, u.display_name,
         c.from_location_id, fl.name, c.to_location_id, tl.name,
         c.from_charged, c.to_charged, c.from_agent_payment, c.to_agent_payment,
         c.reason, c.created_at, c.decided_at
    from public.delivery_location_changes c
    join public.deliveries d on d.id = c.delivery_id
    left join public.users u on u.id = c.requested_by_agent_id
    left join public.locations fl on fl.id = c.from_location_id
    left join public.locations tl on tl.id = c.to_location_id
   where public.is_manager()
     and (p_states is null or c.state = any(p_states))
   order by c.created_at desc
   limit 200;
$$;


--
-- Name: list_movement_actors(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_movement_actors(p_holder_id uuid) RETURNS TABLE(actor_id uuid, actor_name text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not (
       coalesce(public.is_admin_or_dispatcher(), false)
    or coalesce(p_holder_id = auth.uid(), false)
    or coalesce(p_holder_id = (select u.warehouse_id from public.users u where u.id = auth.uid()), false)
  ) then
    raise exception 'not authorised to view this holder''s stock history' using errcode = '42501';
  end if;

  return query
  select distinct sa.created_by_user_id as actor_id, u.display_name as actor_name
    from public.stock_adjustments sa
    join public.users u on u.id = sa.created_by_user_id
   where sa.agent_id = p_holder_id and sa.created_by_user_id is not null
   order by u.display_name asc nulls last;
end;
$$;


--
-- Name: list_movement_counterparties(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_movement_counterparties(p_holder_id uuid) RETURNS TABLE(counterparty_id uuid, counterparty_name text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not (
       coalesce(public.is_admin_or_dispatcher(), false)
    or coalesce(p_holder_id = auth.uid(), false)
    or coalesce(p_holder_id = (select u.warehouse_id from public.users u where u.id = auth.uid()), false)
  ) then
    raise exception 'not authorised to view this holder''s stock history'
      using errcode = '42501';
  end if;

  return query
  select distinct cp.agent_id as counterparty_id, cu.display_name as counterparty_name
    from public.stock_adjustments sa
    join public.stock_adjustments cp on cp.id = sa.related_adjustment_id
    join public.users cu on cu.id = cp.agent_id
   where sa.agent_id = p_holder_id
     and sa.related_adjustment_id is not null
   order by cu.display_name asc nulls last;
end;
$$;


--
-- Name: list_movement_products(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_movement_products(p_holder_id uuid) RETURNS TABLE(product_catalog_id uuid, product_name text, movement_count integer, last_moved_at timestamp with time zone, on_hand integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not (
       coalesce(public.is_admin_or_dispatcher(), false)
    or coalesce(p_holder_id = auth.uid(), false)
    or coalesce(p_holder_id = (select u.warehouse_id from public.users u where u.id = auth.uid()), false)
  ) then
    raise exception 'not authorised to view this holder''s stock history' using errcode = '42501';
  end if;
  return query
  select sa.product_catalog_id, p.product_name::text, count(*)::integer,
         max(sa.created_at), coalesce(sum(sa.quantity_delta), 0)::integer
    from public.stock_adjustments sa
    join public.product_catalog p on p.id = sa.product_catalog_id
   where sa.agent_id = p_holder_id
   group by sa.product_catalog_id, p.product_name
   order by max(sa.created_at) desc;
end;
$$;


--
-- Name: list_my_earnings_v2(date, date, date, uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_my_earnings_v2(p_from date, p_to date, p_after_date date DEFAULT NULL::date, p_after_id uuid DEFAULT NULL::uuid, p_limit integer DEFAULT 200) RETURNS TABLE(id uuid, customer_name text, scheduled_date date, agent_payment_snapshot numeric, product_name text, pay_state text, review_reason text, business_date date, multiplier numeric, manual_exception boolean)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ begin
  if not exists(select 1 from public.users where users.id=auth.uid() and role='agent') then
    raise exception 'agent role required' using errcode='42501'; end if;
  if p_from is null or p_to is null or p_from>p_to or (p_after_date is null)<>(p_after_id is null) then
    raise exception 'valid range and cursor required' using errcode='22023'; end if;
  return query
  select f.delivery_id,d.customer_name,f.accounting_date,f.amount,p.product_name,
    f.pay_state,f.pay_reason,f.business_date,f.multiplier,f.manual
  from public._same_customer_financial_rows(p_from,p_to) f join public.deliveries d on d.id=f.delivery_id
    left join public.product_catalog p on p.id=d.product_catalog_id
  where f.rider_id=auth.uid() and (p_after_date is null or (f.accounting_date,f.delivery_id)<(p_after_date,p_after_id))
  order by f.accounting_date desc,f.delivery_id desc limit greatest(1,least(coalesce(p_limit,200),200));
end $$;


--
-- Name: list_replacement_agent_financials(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_agent_financials(p_from date, p_to date) RETURNS TABLE(attempt_id uuid, delivery_id uuid, attempted_at timestamp with time zone, agent_id uuid, agent_name text, agent_payment numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_role text := public.current_user_role();
begin
  if not (public.is_manager() or v_role = 'agent') then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select a.id, a.delivery_id, a.attempted_at, a.assigned_agent_id,
         u.display_name, a.agent_payment
    from public.replacement_attempts a
    join public.users u on u.id = a.assigned_agent_id
   where (a.attempted_at at time zone 'Africa/Lagos')::date between p_from and p_to
     and (public.is_manager() or a.assigned_agent_id = v_actor)
   order by a.attempted_at desc;
end;
$$;


--
-- Name: list_replacement_agent_financials_v2(date, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_agent_financials_v2(p_from date, p_to date) RETURNS TABLE(attempt_id uuid, delivery_id uuid, attempted_at timestamp with time zone, agent_id uuid, agent_name text, agent_payment numeric, customer_paid numeric, payment_method text, payment_received_by text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_role text := public.current_user_role();
begin
  if not (public.is_manager() or v_role = 'agent') then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select a.id, a.delivery_id, a.attempted_at, a.assigned_agent_id,
         u.display_name, a.agent_payment, a.customer_paid, a.payment_method, a.payment_received_by
    from public.replacement_attempts a
    join public.users u on u.id = a.assigned_agent_id
   where (a.attempted_at at time zone 'Africa/Lagos')::date between p_from and p_to
     and (public.is_manager() or a.assigned_agent_id = v_actor)
   order by a.attempted_at desc;
end;
$$;


--
-- Name: list_replacement_financials(date, date, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_financials(p_from date, p_to date, p_client_id uuid DEFAULT NULL::uuid) RETURNS TABLE(attempt_id uuid, delivery_id uuid, attempted_at timestamp with time zone, client_id uuid, client_name text, customer_name text, outcome text, client_charge numeric, agent_payment numeric, margin numeric, agent_id uuid, agent_name text, notes text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_manager() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select a.id, a.delivery_id, a.attempted_at, d.client_id, c.name, d.customer_name,
         a.outcome, a.client_charge, a.agent_payment,
         a.client_charge - a.agent_payment, a.assigned_agent_id, u.display_name, a.notes
    from public.replacement_attempts a
    join public.deliveries d on d.id = a.delivery_id
    join public.clients c on c.id = d.client_id
    left join public.users u on u.id = a.assigned_agent_id
   where (a.attempted_at at time zone 'Africa/Lagos')::date between p_from and p_to
     and (p_client_id is null or d.client_id = p_client_id)
   order by a.attempted_at desc;
end;
$$;


--
-- Name: list_replacement_financials_rep(date, date, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_financials_rep(p_from date, p_to date, p_client_id uuid DEFAULT NULL::uuid) RETURNS TABLE(attempt_id uuid, delivery_id uuid, attempted_at timestamp with time zone, client_id uuid, client_name text, customer_name text, outcome text, remit numeric, agent_name text, notes text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select a.id, a.delivery_id, a.attempted_at, d.client_id, c.name,
         d.customer_name, a.outcome, -a.client_charge,
         u.display_name, a.notes
    from public.replacement_attempts a
    join public.deliveries d on d.id = a.delivery_id
    join public.clients c on c.id = d.client_id
    left join public.users u on u.id = a.assigned_agent_id
   where (a.attempted_at at time zone 'Africa/Lagos')::date between p_from and p_to
     and (p_client_id is null or d.client_id = p_client_id)
   order by a.attempted_at desc;
end;
$$;


--
-- Name: list_replacement_financials_rep_v2(date, date, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_financials_rep_v2(p_from date, p_to date, p_client_id uuid DEFAULT NULL::uuid) RETURNS TABLE(attempt_id uuid, delivery_id uuid, attempted_at timestamp with time zone, client_id uuid, client_name text, customer_name text, outcome text, remit numeric, agent_name text, notes text, customer_paid numeric, payment_method text, payment_received_by text, cash_pos_fee numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select a.id, a.delivery_id, a.attempted_at, d.client_id, c.name,
         d.customer_name, a.outcome, (a.customer_paid - a.client_charge - a.cash_pos_fee),
         u.display_name, a.notes, a.customer_paid, a.payment_method, a.payment_received_by, a.cash_pos_fee
    from public.replacement_attempts a
    join public.deliveries d on d.id = a.delivery_id
    join public.clients c on c.id = d.client_id
    left join public.users u on u.id = a.assigned_agent_id
   where (a.attempted_at at time zone 'Africa/Lagos')::date between p_from and p_to
     and (p_client_id is null or d.client_id = p_client_id)
   order by a.attempted_at desc;
end;
$$;


--
-- Name: list_replacement_financials_v2(date, date, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_financials_v2(p_from date, p_to date, p_client_id uuid DEFAULT NULL::uuid) RETURNS TABLE(attempt_id uuid, delivery_id uuid, attempted_at timestamp with time zone, client_id uuid, client_name text, customer_name text, outcome text, client_charge numeric, agent_payment numeric, margin numeric, agent_id uuid, agent_name text, notes text, customer_paid numeric, payment_method text, payment_received_by text, cash_pos_fee numeric)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_manager() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select a.id, a.delivery_id, a.attempted_at, d.client_id, c.name, d.customer_name,
         a.outcome, a.client_charge, a.agent_payment,
         a.client_charge - a.agent_payment, a.assigned_agent_id, u.display_name, a.notes,
         a.customer_paid, a.payment_method, a.payment_received_by, a.cash_pos_fee
    from public.replacement_attempts a
    join public.deliveries d on d.id = a.delivery_id
    join public.clients c on c.id = d.client_id
    left join public.users u on u.id = a.assigned_agent_id
   where (a.attempted_at at time zone 'Africa/Lagos')::date between p_from and p_to
     and (p_client_id is null or d.client_id = p_client_id)
   order by a.attempted_at desc;
end;
$$;


--
-- Name: list_replacement_returns(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_replacement_returns() RETURNS TABLE(return_item_id uuid, delivery_id uuid, customer_name text, raw_address text, client_name text, product_name text, quantity integer, reported_condition text, custody_state text, vendor_instruction text, rider_name text, collected_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not (public.is_manager() or public.current_user_role() = 'warehouse') then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  return query
  select ri.id, ri.delivery_id, d.customer_name, d.raw_address,
         c.name, pc.product_name, coalesce(ri.actual_quantity, ri.quantity_expected),
         ri.reported_condition, ri.custody_state, ri.vendor_instruction,
         u.display_name, ri.collected_at
    from public.replacement_return_items ri
    join public.deliveries d on d.id = ri.delivery_id
    join public.clients c on c.id = d.client_id
    join public.product_catalog pc on pc.id = ri.product_catalog_id
    left join public.users u on u.id = ri.current_holder_id
   where ri.custody_state in (
     'with_rider_usable_pending_inspection','with_rider_damaged_hold','warehouse_hold_for_vendor'
   )
   order by ri.collected_at nulls last, ri.created_at;
end;
$$;


--
-- Name: list_same_customer_orders(date, text, integer, uuid, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_same_customer_orders(p_day date, p_after text DEFAULT NULL::text, p_limit integer DEFAULT 50, p_agent_id uuid DEFAULT NULL::uuid, p_client_id uuid DEFAULT NULL::uuid, p_search text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_result jsonb;
begin
  if not public.is_manager() then raise exception 'admin or dispatcher role required' using errcode='42501'; end if;
  if p_day is null or p_limit<0 or p_limit>100 or p_limit is null then
    raise exception 'day and limit between 0 and 100 required' using errcode='22023'; end if;
  if not coalesce((select enabled from public.feature_flags where key='same_customer_discovery'),false) then
    return jsonb_build_object('groups','[]'::jsonb,'total_groups',0,'attention_groups',0,'next_cursor',null); end if;
  with orders as materialized (select * from public._same_customer_day_orders(p_day)),
  groups as (
    select g.group_id,g.match_kind,g.delivery_ids,
      count(*)::integer as order_count,count(distinct o.client_id)::integer as vendor_count,
      count(distinct o.agent_id)::integer as rider_count,
      bool_or(o.agent_id is null) as has_unassigned,
      (bool_or(coalesce(s.category,'')<>'terminal')
        and (count(distinct o.agent_id)>1 or bool_or(o.agent_id is null))) as needs_assignment,
      count(distinct public._norm_address(o.raw_address))>1 as addresses_differ,
      min(o.customer_name) as customer_name,
      count(*) filter(where
        (p_agent_id is null or o.agent_id=p_agent_id)
        and (p_client_id is null or o.client_id=p_client_id)
        and (nullif(btrim(p_search),'') is null
          or o.customer_name ilike '%' || btrim(p_search) || '%'
          or o.phone like '%' || nullif(regexp_replace(p_search,'\D','','g'),'') || '%'
          or o.phone_alt like '%' || nullif(regexp_replace(p_search,'\D','','g'),'') || '%'))::integer as matching_order_count
    from public._same_customer_day_groups(p_day) g
    cross join lateral unnest(g.delivery_ids) member_id
    join orders o on o.delivery_id=member_id
    left join public.delivery_status_defs s on s.status=o.current_status
    group by g.group_id,g.match_kind,g.delivery_ids
  ), filtered as (select * from groups where matching_order_count>0),
  page as (select * from filtered where p_after is null or group_id>p_after order by group_id limit p_limit),
  boundary as (select max(group_id) as last_id from page)
  select jsonb_build_object('groups',coalesce((select jsonb_agg(to_jsonb(p) order by group_id) from page p),'[]'::jsonb),
    'total_groups',(select count(*) from filtered),
    'attention_groups',(select count(*) from filtered where needs_assignment),
    'next_cursor',case when p_limit>0 and exists(select 1 from filtered where group_id>(select last_id from boundary))
      then (select last_id from boundary) end) into v_result;
  return v_result;
end $$;


--
-- Name: list_settlements_for_date(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_settlements_for_date(p_period_date date) RETURNS TABLE(settlement_id uuid, subject_type text, subject_id uuid, expected_amount numeric, deliveries_count integer, settled_at timestamp with time zone, settled_by_name text, note text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select s.id, s.subject_type, s.subject_id, s.expected_amount, s.deliveries_count,
         s.settled_at, u.display_name, s.note
  from public.settlements s
  left join public.users u on u.id = s.settled_by
  where s.period_date = p_period_date
    and s.voided_at is null
    and public.is_admin_or_dispatcher();
$$;


--
-- Name: list_stock_count_batches(integer, timestamp with time zone, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_stock_count_batches(p_limit integer DEFAULT 50, p_cursor_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_cursor_batch uuid DEFAULT NULL::uuid, p_holder_id uuid DEFAULT NULL::uuid) RETURNS TABLE(batch_id uuid, holder_id uuid, counted_at timestamp with time zone, counted_by uuid, note text, items_count integer, off_count integer)
    LANGUAGE sql STABLE
    SET search_path TO 'public'
    AS $$
  select sc.batch_id,
         sc.holder_id,
         max(sc.counted_at)                                         as counted_at,
         sc.counted_by,
         sc.note,
         count(*)::int                                              as items_count,
         count(*) filter (where sc.variance <> 0)::int              as off_count
    from public.stock_counts sc
   where (p_holder_id is null or sc.holder_id = p_holder_id)
   -- holder/counted_by/note are functionally dependent on batch_id —
   -- record_stock_count writes one holder, one actor and one note per run — so
   -- grouping by them is equivalent to grouping by batch_id alone, and avoids
   -- needing an aggregate over uuid (there is no min(uuid) in Postgres).
   -- counted_at is still aggregated because each row carries its own default.
   group by sc.batch_id, sc.holder_id, sc.counted_by, sc.note
  having (
      -- Keyset: strictly older than the cursor. batch_id breaks ties so two
      -- runs recorded in the same instant can't be skipped or repeated.
      p_cursor_at is null
      or max(sc.counted_at) < p_cursor_at
      or (max(sc.counted_at) = p_cursor_at and sc.batch_id < p_cursor_batch)
    )
   order by max(sc.counted_at) desc, sc.batch_id desc
   limit least(greatest(coalesce(p_limit, 50), 1), 200);
$$;


--
-- Name: FUNCTION list_stock_count_batches(p_limit integer, p_cursor_at timestamp with time zone, p_cursor_batch uuid, p_holder_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.list_stock_count_batches(p_limit integer, p_cursor_at timestamp with time zone, p_cursor_batch uuid, p_holder_id uuid) IS 'One row per stock-count run (batch) for the count-history feed, newest first. Keyset-paginated on (counted_at, batch_id). security invoker so stock_counts RLS decides visibility. Report-only data — counts never touch the ledger.';


--
-- Name: list_stock_count_batches_v2(integer, timestamp with time zone, uuid, uuid, date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_stock_count_batches_v2(p_limit integer DEFAULT 30, p_cursor_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_cursor_batch uuid DEFAULT NULL::uuid, p_holder_id uuid DEFAULT NULL::uuid, p_week_ending date DEFAULT NULL::date) RETURNS TABLE(batch_id uuid, holder_id uuid, counted_at timestamp with time zone, counted_by uuid, note text, items_count integer, off_count integer, holder_name text, counted_by_name text, week_ending date)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare v_ops boolean := coalesce(public.is_admin_or_dispatcher() or public.is_warehouse(), false);
begin
  if auth.uid() is null or not exists (select 1 from public.users u where u.id = auth.uid() and u.is_active) then
    raise exception 'Sign in to view counts' using errcode = '42501';
  end if;
  if not v_ops and p_holder_id is not null and p_holder_id <> auth.uid() then
    raise exception 'You can only view your own counts' using errcode = '42501';
  end if;
  return query
  with batches as (
    select s.batch_id, s.agent_id as holder_id, s.counted_at, s.agent_id as counted_by,
      s.note, s.items_count, s.off_count, s.week_ending
    from public.agent_stock_count_submissions s
    where (v_ops or s.agent_id = auth.uid()) and (p_holder_id is null or s.agent_id = p_holder_id)
      and (p_week_ending is null or s.week_ending = p_week_ending)
    union all
    select c.batch_id, c.holder_id, max(c.counted_at), c.counted_by, c.note,
      count(*)::integer, count(*) filter(where c.variance <> 0)::integer, null::date
    from public.stock_counts c
    where (v_ops or c.holder_id = auth.uid()) and (p_holder_id is null or c.holder_id = p_holder_id)
      and p_week_ending is null
      and not exists (select 1 from public.agent_stock_count_submissions s where s.batch_id = c.batch_id)
    group by c.batch_id, c.holder_id, c.counted_by, c.note
  )
  select b.batch_id, b.holder_id, b.counted_at, b.counted_by, b.note, b.items_count, b.off_count,
    h.display_name::text, a.display_name::text, b.week_ending from batches b
    left join public.users h on h.id = b.holder_id left join public.users a on a.id = b.counted_by
  where p_cursor_at is null or (b.counted_at, b.batch_id) < (p_cursor_at, p_cursor_batch)
  order by b.counted_at desc, b.batch_id desc limit least(greatest(coalesce(p_limit, 30), 1), 100);
end;
$$;


--
-- Name: list_stock_count_items(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_stock_count_items(p_batch_id uuid) RETURNS TABLE(id uuid, batch_id uuid, holder_id uuid, product_catalog_id uuid, expected_qty integer, counted_qty integer, variance integer, counted_by uuid, counted_at timestamp with time zone, note text, product_name text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if auth.uid() is null or not exists (select 1 from public.users u where u.id = auth.uid() and u.is_active) then
    raise exception 'Sign in to view counts' using errcode = '42501';
  end if;
  return query select c.id, c.batch_id, c.holder_id, c.product_catalog_id, c.expected_qty,
    c.counted_qty, c.variance, c.counted_by, c.counted_at, c.note,
    coalesce(saved.item->>'product_name', p.product_name)::text
  from public.stock_counts c join public.product_catalog p on p.id = c.product_catalog_id
  left join public.agent_stock_count_submissions s on s.batch_id = c.batch_id
  left join lateral (
    select i as item from jsonb_array_elements(s.items) i where i->>'product_catalog_id' = c.product_catalog_id::text
  ) saved on true
  where c.batch_id = p_batch_id
    and (public.is_admin_or_dispatcher() or public.is_warehouse() or c.holder_id = auth.uid())
  order by p.product_name;
end;
$$;


--
-- Name: list_stock_movements(uuid, timestamp with time zone, uuid, integer, uuid, text[], uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_stock_movements(p_holder_id uuid, p_before_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_before_event_id uuid DEFAULT NULL::uuid, p_limit integer DEFAULT 50, p_actor_id uuid DEFAULT NULL::uuid, p_kinds text[] DEFAULT NULL::text[], p_counterparty_id uuid DEFAULT NULL::uuid, p_product_catalog_id uuid DEFAULT NULL::uuid) RETURNS TABLE(source text, event_id uuid, event_at timestamp with time zone, event_kind text, product_catalog_id uuid, product_name text, quantity_delta integer, quantity_ordered integer, notes text, actor_id uuid, actor_name text, counterparty_holder_id uuid, counterparty_holder_name text, related_adjustment_id uuid, delivery_id uuid, customer_name text, balance_after integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not (
       coalesce(public.is_admin_or_dispatcher(), false)
    or coalesce(p_holder_id = auth.uid(), false)
    or coalesce(p_holder_id = (select u.warehouse_id from public.users u where u.id = auth.uid()), false)
  ) then
    raise exception 'not authorised to view this holder''s stock history' using errcode = '42501';
  end if;
  if p_limit is null or p_limit < 1 or p_limit > 200 then
    raise exception 'limit must be between 1 and 200' using errcode = '22023';
  end if;
  return query
  select
    case when sa.delivery_id is not null then 'delivery' else 'adjustment' end::text,
    sa.id, sa.created_at, sa.reason, sa.product_catalog_id, p.product_name, sa.quantity_delta,
    case when sa.reason = 'delivered' then di.quantity_ordered else null end::int,
    sa.notes, sa.created_by_user_id, au.display_name,
    cp.agent_id, cu.display_name, sa.related_adjustment_id,
    sa.delivery_id, dlv.customer_name,
    -- Running balance of the traced product on this holder AFTER this event:
    -- the ledger sum up to and including the row, which is exactly how
    -- current_stock is derived. Only computed while tracing one product.
    case when p_product_catalog_id is null then null else (
      select sum(x.quantity_delta)::int
        from public.stock_adjustments x
       where x.agent_id = p_holder_id
         and x.product_catalog_id = p_product_catalog_id
         and (x.created_at, x.id) <= (sa.created_at, sa.id)
    ) end
  from public.stock_adjustments sa
  join public.product_catalog p on p.id = sa.product_catalog_id
  left join public.users au on au.id = sa.created_by_user_id
  left join public.stock_adjustments cp on cp.id = sa.related_adjustment_id
  left join public.users cu on cu.id = cp.agent_id
  left join public.deliveries dlv on dlv.id = sa.delivery_id
  left join public.delivery_items di
         on di.delivery_id = sa.delivery_id and di.product_catalog_id = sa.product_catalog_id
  where sa.agent_id = p_holder_id
    and (p_product_catalog_id is null or sa.product_catalog_id = p_product_catalog_id)
    and (p_before_at is null or (sa.created_at, sa.id) < (p_before_at, p_before_event_id))
    and (p_actor_id is null or sa.created_by_user_id = p_actor_id)
    and (p_kinds is null or sa.reason = any(p_kinds))
    and (p_counterparty_id is null or cp.agent_id = p_counterparty_id)
  order by sa.created_at desc, sa.id desc
  limit p_limit;
end;
$$;


--
-- Name: list_stock_movements_global(uuid, uuid, uuid, text[], timestamp with time zone, uuid, integer, date, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_stock_movements_global(p_client_id uuid DEFAULT NULL::uuid, p_product_catalog_id uuid DEFAULT NULL::uuid, p_holder_id uuid DEFAULT NULL::uuid, p_kinds text[] DEFAULT NULL::text[], p_before_at timestamp with time zone DEFAULT NULL::timestamp with time zone, p_before_event_id uuid DEFAULT NULL::uuid, p_limit integer DEFAULT 50, p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date, p_direction text DEFAULT NULL::text) RETURNS TABLE(source text, event_id uuid, event_at timestamp with time zone, event_kind text, product_catalog_id uuid, product_name text, quantity_delta integer, quantity_ordered integer, notes text, actor_id uuid, actor_name text, counterparty_holder_id uuid, counterparty_holder_name text, related_adjustment_id uuid, delivery_id uuid, customer_name text, holder_id uuid, holder_name text, client_id uuid, client_name text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not coalesce(public.is_admin_or_dispatcher(), false) then
    raise exception 'not authorised to view company-wide stock history' using errcode = '42501';
  end if;
  if p_limit is null or p_limit < 1 or p_limit > 200 then
    raise exception 'limit must be between 1 and 200' using errcode = '22023';
  end if;
  if p_direction is not null and p_direction not in ('in', 'out') then
    raise exception 'direction must be in, out, or null' using errcode = '22023';
  end if;

  return query
  select
    case when sa.delivery_id is not null then 'delivery' else 'adjustment' end::text,
    sa.id, sa.created_at, sa.reason, sa.product_catalog_id, p.product_name, sa.quantity_delta,
    case when sa.reason = 'delivered' then di.quantity_ordered else null end::int,
    sa.notes, sa.created_by_user_id, au.display_name,
    cp.agent_id, cu.display_name, sa.related_adjustment_id,
    sa.delivery_id, dlv.customer_name,
    sa.agent_id, hu.display_name, p.client_id, c.name
  from public.stock_adjustments sa
  join public.product_catalog p on p.id = sa.product_catalog_id
  join public.clients c on c.id = p.client_id
  left join public.users hu on hu.id = sa.agent_id
  left join public.users au on au.id = sa.created_by_user_id
  left join public.stock_adjustments cp on cp.id = sa.related_adjustment_id
  left join public.users cu on cu.id = cp.agent_id
  left join public.deliveries dlv on dlv.id = sa.delivery_id
  left join public.delivery_items di
         on di.delivery_id = sa.delivery_id and di.product_catalog_id = sa.product_catalog_id
  where not (sa.reason in ('warehouse_issue','warehouse_return','transfer') and sa.quantity_delta > 0)
    and (p_client_id is null or p.client_id = p_client_id)
    and (p_product_catalog_id is null or sa.product_catalog_id = p_product_catalog_id)
    -- Bidirectional holder filter (+ optional direction). The holder may be the
    -- source (sa.agent_id) or the recipient of a collapsed paired leg (cp.agent_id).
    and (
      p_holder_id is null
      or (p_direction is null and (sa.agent_id = p_holder_id or cp.agent_id = p_holder_id))
      or (p_direction = 'out' and sa.agent_id = p_holder_id and sa.quantity_delta < 0)
      or (p_direction = 'in'  and ((sa.agent_id = p_holder_id and sa.quantity_delta > 0) or cp.agent_id = p_holder_id))
    )
    and (p_kinds is null or sa.reason = any(p_kinds))
    -- Lagos-day date bounds (range on the indexed created_at).
    and (p_from is null or sa.created_at >= (p_from::text || ' 00:00')::timestamp at time zone 'Africa/Lagos')
    and (p_to   is null or sa.created_at <  ((p_to + 1)::text || ' 00:00')::timestamp at time zone 'Africa/Lagos')
    and (p_before_at is null or (sa.created_at, sa.id) < (p_before_at, p_before_event_id))
  order by sa.created_at desc, sa.id desc
  limit p_limit;
end;
$$;


--
-- Name: list_weekly_agent_stock_counts(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.list_weekly_agent_stock_counts(p_week_ending date) RETURNS TABLE(agent_id uuid, agent_name text, batch_id uuid, counted_at timestamp with time zone, items_count integer, off_count integer, is_late boolean)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not coalesce(public.is_admin_or_dispatcher(), false) then
    raise exception 'Operations access required' using errcode = '42501';
  end if;
  if p_week_ending is null or extract(dow from p_week_ending) <> 6 then
    raise exception 'Choose a Saturday' using errcode = '22023';
  end if;
  return query select u.id, u.display_name::text, s.batch_id, s.counted_at, s.items_count, s.off_count,
    coalesce((s.counted_at at time zone 'Africa/Lagos')::date > p_week_ending, false)
  from public.users u
  left join lateral (
    select sub.* from public.agent_stock_count_submissions sub
    where sub.agent_id = u.id and sub.week_ending = p_week_ending
    order by sub.counted_at desc, sub.batch_id desc limit 1
  ) s on true
  where u.role = 'agent' and (u.is_active or s.batch_id is not null)
    and (u.created_at at time zone 'Africa/Lagos')::date < p_week_ending + 7
  order by (s.batch_id is not null), u.display_name;
end;
$$;


--
-- Name: mark_client_notified(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mark_client_notified(p_status_history_id uuid) RETURNS TABLE(status_history_id uuid, delivery_id uuid, notified_by_user_id uuid, notified_at timestamp with time zone, holder_name text, is_self boolean)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
#variable_conflict use_column
declare
  v_user        uuid := auth.uid();
  v_delivery_id uuid;
  v_deleted_at  timestamptz;
  v_existing    public.delivery_client_notifications%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if not public.is_admin_or_dispatcher() then
    raise exception 'permission denied' using errcode = '42501';
  end if;

  -- Resolve the delivery + soft-delete guard from the history row.
  select dsh.delivery_id, d.deleted_at
    into v_delivery_id, v_deleted_at
    from public.delivery_status_history dsh
    join public.deliveries d on d.id = dsh.delivery_id
   where dsh.id = p_status_history_id;

  if v_delivery_id is null then
    raise exception 'status history row not found' using errcode = 'P0002';
  end if;
  if v_deleted_at is not null then
    raise exception 'cannot tag a deleted delivery' using errcode = '22023';
  end if;

  -- First-tap wins. ON CONFLICT DO NOTHING means a second caller falls
  -- through to the SELECT below and gets the existing holder.
  insert into public.delivery_client_notifications
    (status_history_id, delivery_id, notified_by_user_id)
  values
    (p_status_history_id, v_delivery_id, v_user)
  on conflict (status_history_id) do nothing;

  select * into v_existing
    from public.delivery_client_notifications
   where status_history_id = p_status_history_id;

  return query
    select v_existing.status_history_id,
           v_existing.delivery_id,
           v_existing.notified_by_user_id,
           v_existing.notified_at,
           u.display_name,
           (v_existing.notified_by_user_id = v_user)
      from public.users u
     where u.id = v_existing.notified_by_user_id;
end $$;


--
-- Name: mark_inbound_processed(uuid, text, jsonb, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mark_inbound_processed(p_inbound_id uuid, p_status text, p_parse jsonb, p_delivery_id uuid DEFAULT NULL::uuid, p_error text DEFAULT NULL::text) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  update public.bot_inbound_messages
     set status        = p_status,
         parse_result  = p_parse,
         delivery_id   = p_delivery_id,
         error_text    = p_error,
         processed_at  = now()
   where id = p_inbound_id;
$$;


--
-- Name: mark_messages_read(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mark_messages_read(p_delivery_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user uuid := auth.uid();
  v_role text;
begin
  if v_user is null then
    return;
  end if;
  select role into v_role from public.users where id = v_user;
  -- Role direction, not author_id: each side clears only the OTHER side's
  -- messages. An agent reads ops messages; an ops user reads agent messages.
  -- This avoids one ops user marking another ops user's message read (which
  -- would falsely drop the agent's "ops replied" badge).
  update public.delivery_messages
     set read_at = now()
   where delivery_id = p_delivery_id
     and read_at is null
     and case when v_role = 'agent' then author_role <> 'agent'
              else author_role = 'agent' end
     -- A rep can never clear a 'not my route' flag: it's reassigned by an
     -- admin/dispatcher. Clearing it (reply / Mark handled / claim) would drop
     -- it off the admin "open issues" feed (filters read_at is null) before
     -- anyone with reassign rights acted. Keep it unread for reps.
     and not (v_role = 'rep' and issue_type is not distinct from 'not_my_route');
end $$;


--
-- Name: mark_token_issued(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.mark_token_issued(p_call_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  update public.calls
     set last_token_issued_at = now()
   where id = p_call_id;
end $$;


--
-- Name: match_products_by_text(text, real); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.match_products_by_text(p_text text, p_min_similarity real DEFAULT 0.4) RETURNS TABLE(id uuid, client_id uuid, client_name text, product_name text, score real)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select id, client_id, client_name, product_name, score from (
    select pc.id, pc.client_id, c.name as client_name, pc.product_name,
      greatest(
        similarity(lower(pc.product_name), lower(coalesce(p_text,''))),
        coalesce((select max(similarity(lower(a), lower(coalesce(p_text,''))))
                    from unnest(coalesce(pc.aliases, array[]::text[])) a), 0)
      )::real as score,
      (pc.product_name ilike '%'||coalesce(p_text,'')||'%'
        or exists (select 1 from unnest(coalesce(pc.aliases, array[]::text[])) a
                     where a ilike '%'||coalesce(p_text,'')||'%')) as substr_hit
    from public.product_catalog pc join public.clients c on c.id=pc.client_id
    where pc.is_active=true and c.is_active=true
  ) s
  where s.substr_hit or s.score >= p_min_similarity
  order by s.score desc limit 10;
$$;


--
-- Name: notify_call_invite_push(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_call_invite_push() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if new.status = 'ringing' then
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'call_invite',
      'call_id',  new.id::text
    ));
  end if;
  return new;
end $$;


--
-- Name: ops_unread_agent_counts(boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ops_unread_agent_counts(p_exclude_not_my_route boolean DEFAULT false) RETURNS TABLE(delivery_id uuid, unread_count bigint)
    LANGUAGE sql STABLE
    SET search_path TO 'public', 'auth'
    AS $$
  select dm.delivery_id, count(*)::bigint as unread_count
  from public.delivery_messages dm
  join public.deliveries d on d.id = dm.delivery_id
  where dm.author_role = 'agent'
    and dm.read_at is null
    -- parent delivery still open (see TERMINAL SET above)
    and not exists (
      select 1
      from public.delivery_status_defs sd
      where sd.status = d.current_status
        and sd.category = 'terminal'
    )
    -- deliberate contact only: a plain reply (null) or an actionable flag
    and (dm.issue_type is null or dm.issue_type <> 'cant_reach_client')
    -- reps: drop the reassign-only flag
    and (not p_exclude_not_my_route or dm.issue_type is distinct from 'not_my_route')
  group by dm.delivery_id;
$$;


--
-- Name: prevent_history_modification(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_history_modification() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    raise exception 'delivery_status_history is immutable. To correct a status, insert a new history row.';
end;
$$;


--
-- Name: preview_delivery_charge(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.preview_delivery_charge(p_location_id uuid, p_client_id uuid) RETURNS TABLE(rate_card_charged numeric, effective_charged numeric, client_ceiling numeric, was_clamped boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  select
    rc.charged                                                            as rate_card_charged,
    least(rc.charged, coalesce(c.max_charge_per_delivery, rc.charged))    as effective_charged,
    c.max_charge_per_delivery                                             as client_ceiling,
    (c.max_charge_per_delivery is not null
       and rc.charged > c.max_charge_per_delivery)                        as was_clamped
  from public.rate_card rc
  cross join public.clients c
  where rc.location_id     = p_location_id
    and rc.effective_until is null
    and c.id               = p_client_id
  order by rc.effective_from desc
  limit 1;
$$;


--
-- Name: preview_eod_rollover(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.preview_eod_rollover(p_for_date date DEFAULT ((now() AT TIME ZONE 'Africa/Lagos'::text))::date) RETURNS TABLE(delivery_id uuid, customer_name text, product_name text, quantity_ordered numeric, customer_price numeric, current_status text, assigned_agent_name text, action text, to_status text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
  select
    c.delivery_id,
    d.customer_name,
    p.product_name,
    d.quantity_ordered,
    d.customer_price,
    c.current_status,
    u.display_name as assigned_agent_name,
    c.action,
    case c.action
      when 'sibling_resolved'  then 'cancelled'
      when 'dedup_same_agent'  then 'cancelled'
      when 'dedup_cross_agent' then 'cancelled'
      when 'close_disinterest' then 'unserious'
      when 'close_policy'      then 'failed_delivery'
      when 'close_followup'    then 'deferred_to_client'
      when 'cap_unserious'     then 'unserious'
      else 'rolled_over'
    end as to_status
  from public._eod_classify(p_for_date) c
  join public.deliveries d on d.id = c.delivery_id
  left join public.product_catalog p on p.id = d.product_catalog_id
  left join public.users u on u.id = d.assigned_agent_id
  where public.is_admin_or_dispatcher()
  order by c.action, d.customer_name;
$$;


--
-- Name: product_deactivation_blockers(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.product_deactivation_blockers(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if not exists (select 1 from public.product_catalog where id = p_id) then
    raise exception 'product not found' using errcode = 'P0002';
  end if;
  return public._product_deactivation_blockers(p_id);
end;
$$;


--
-- Name: FUNCTION product_deactivation_blockers(p_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.product_deactivation_blockers(p_id uuid) IS 'Admin preflight for the catalog Deactivate panel. Returns the same payload the guard ships as its error hint, so panel and server cannot disagree.';


--
-- Name: prune_net_response_log(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prune_net_response_log() RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'net'
    AS $$
declare
  v_count integer;
begin
  delete from net._http_response
   where created < now() - interval '7 days';
  get diagnostics v_count = row_count;
  return v_count;
end $$;


--
-- Name: reactivate_client(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reactivate_client(p_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_inactive boolean;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select not is_active into v_was_inactive from public.clients where id = p_id;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;
  if not v_was_inactive then return; end if;

  update public.clients set is_active = true where id = p_id;

  perform public.write_audit(
    'client', p_id,
    jsonb_build_object('is_active', false),
    jsonb_build_object('is_active', true)
  );
end;
$$;


--
-- Name: reactivate_location(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reactivate_location(p_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_inactive boolean;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select not is_active into v_was_inactive from public.locations where id = p_id;
  if not found then
    raise exception 'location not found' using errcode = 'P0002';
  end if;
  if not v_was_inactive then return; end if;

  update public.locations set is_active = true where id = p_id;

  perform public.write_audit(
    'location', p_id,
    jsonb_build_object('is_active', false),
    jsonb_build_object('is_active', true)
  );
end;
$$;


--
-- Name: reactivate_product(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reactivate_product(p_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_inactive   boolean;
  v_client_active  boolean;
  v_client_id      uuid;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select not is_active, client_id into v_was_inactive, v_client_id from public.product_catalog where id = p_id;
  if not found then
    raise exception 'product not found' using errcode = 'P0002';
  end if;
  if not v_was_inactive then return; end if;

  select is_active into v_client_active from public.clients where id = v_client_id;
  if not v_client_active then
    raise exception 'cannot reactivate: parent client is inactive' using errcode = '23514';
  end if;

  update public.product_catalog set is_active = true where id = p_id;

  perform public.write_audit(
    'product', p_id,
    jsonb_build_object('is_active', false),
    jsonb_build_object('is_active', true)
  );
end;
$$;


--
-- Name: reactivate_user(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reactivate_user(p_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_was_inactive boolean;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select not is_active into v_was_inactive from public.users where id = p_id;
  if not found then
    raise exception 'user not found' using errcode = 'P0002';
  end if;
  if not v_was_inactive then return; end if;

  update public.users
     set is_active       = true,
         deactivated_at = null
   where id = p_id;

  perform public.write_audit(
    'user', p_id,
    jsonb_build_object('is_active', false),
    jsonb_build_object('is_active', true)
  );
end;
$$;


--
-- Name: reassign_to_sub_agent(text, uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reassign_to_sub_agent(p_client_uuid text, p_delivery_id uuid, p_sub_agent_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
DECLARE
  v_actor          uuid := auth.uid();
  v_delivery       public.deliveries%ROWTYPE;
  v_target_parent  uuid;
  v_target_active  boolean;
  v_current_parent uuid;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],array[p_sub_agent_id]);
  IF v_actor IS NULL THEN
    RAISE EXCEPTION 'authentication required' USING errcode = '42501';
  END IF;
  IF p_client_uuid IS NULL OR btrim(p_client_uuid) = '' THEN
    RAISE EXCEPTION 'client_uuid required' USING errcode = '23514';
  END IF;
  IF p_sub_agent_id IS NULL THEN
    RAISE EXCEPTION 'sub_agent_id required' USING errcode = '23514';
  END IF;

  SELECT * INTO v_delivery
    FROM public.deliveries
   WHERE id = p_delivery_id AND deleted_at IS NULL
   FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'delivery not found' USING errcode = 'P0002';
  END IF;

  -- Already on target → no-op (idempotent retry).
  IF v_delivery.assigned_agent_id = p_sub_agent_id THEN
    RETURN;
  END IF;

  IF v_delivery.assigned_agent_id IS NULL THEN
    RAISE EXCEPTION 'delivery is unassigned; assignment is admin/dispatcher work'
      USING errcode = '23514';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.delivery_status_defs
     WHERE status = v_delivery.current_status AND category = 'terminal'
  ) THEN
    RAISE EXCEPTION 'delivery is terminal (status=%) — cannot reassign', v_delivery.current_status
      USING errcode = '22023';
  END IF;

  -- Validate target sub-agent.
  SELECT parent_agent_id, is_active INTO v_target_parent, v_target_active
    FROM public.users WHERE id = p_sub_agent_id;
  IF v_target_parent IS NULL THEN
    RAISE EXCEPTION 'target user is not a sub-agent' USING errcode = '23514';
  END IF;
  IF NOT v_target_active THEN
    RAISE EXCEPTION 'target sub-agent is inactive' USING errcode = '23514';
  END IF;
  IF v_target_parent <> v_actor THEN
    RAISE EXCEPTION 'permission denied: target is not your sub-agent'
      USING errcode = '42501';
  END IF;

  -- Caller must be the current assignee OR the current assignee's lead.
  -- (Lead-moves-within-team flow: caller already owns transitively, can shuffle.)
  SELECT parent_agent_id INTO v_current_parent
    FROM public.users WHERE id = v_delivery.assigned_agent_id;
  IF v_actor <> v_delivery.assigned_agent_id
     AND v_actor IS DISTINCT FROM v_current_parent THEN
    RAISE EXCEPTION 'permission denied: you do not own this delivery (directly or via your sub-agent)'
      USING errcode = '42501';
  END IF;

  -- The change. notify_assignment_push fires on this UPDATE and pushes the new
  -- assignee via the existing send-notification path. notify_pickup_needed also
  -- fires and pushes admins+dispatchers if the new assignee is short on stock.
  UPDATE public.deliveries
     SET assigned_agent_id = p_sub_agent_id,
         updated_at        = now()
   WHERE id = p_delivery_id;

  PERFORM public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := jsonb_build_object('assigned_agent_id', v_delivery.assigned_agent_id),
    p_new         := jsonb_build_object('assigned_agent_id', p_sub_agent_id),
    p_reason      := 'reassign_to_sub_agent:' || p_client_uuid
  );
END;
$$;


--
-- Name: FUNCTION reassign_to_sub_agent(p_client_uuid text, p_delivery_id uuid, p_sub_agent_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.reassign_to_sub_agent(p_client_uuid text, p_delivery_id uuid, p_sub_agent_id uuid) IS 'Team-lead handoff: moves an assigned delivery from the lead (or one of her sub-agents) to another sub-agent in her team. Permission is narrow — does NOT widen full reassignment beyond admin/dispatcher.';


--
-- Name: receive_replacement_return(text, uuid, text, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.receive_replacement_return(p_client_uuid text, p_return_item_id uuid, p_disposition text, p_warehouse_id uuid DEFAULT NULL::uuid, p_notes text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_role text := public.current_user_role();
  v_actor_warehouse uuid;
  v_target uuid;
  v_return record;
  v_adjustment_id uuid;
  v_new_state text;
  v_event text;
begin
  if nullif(trim(p_client_uuid), '') is null then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  if exists (select 1 from public.stock_adjustments where client_uuid = p_client_uuid || ':accepted')
     or exists (
       select 1 from public.replacement_return_events
        where client_uuid = p_client_uuid
     ) then return; end if;
  if not (public.is_manager() or v_role = 'warehouse') then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  select warehouse_id into v_actor_warehouse from public.users where id = v_actor;
  v_target := case when v_role = 'warehouse' then coalesce(v_actor_warehouse, v_actor)
                   else p_warehouse_id end;
  if v_target is null or not exists (
    select 1 from public.users
     where id = v_target and role = 'warehouse' and warehouse_id is null and is_active
  ) then
    raise exception 'select an active warehouse' using errcode = '23514';
  end if;
  select * into v_return from public.replacement_return_items
   where id = p_return_item_id for update;
  if not found then raise exception 'return item not found' using errcode = 'P0002'; end if;
  if v_return.custody_state not in (
    'with_rider_usable_pending_inspection','with_rider_damaged_hold','warehouse_hold_for_vendor'
  ) then
    raise exception 'return item is not awaiting warehouse action' using errcode = '22023';
  end if;
  if p_disposition not in ('accept_to_stock','hold_for_vendor','reject_damaged','returned_to_vendor') then
    raise exception 'invalid disposition' using errcode = '23514';
  end if;
  if p_disposition = 'accept_to_stock' and v_return.reported_condition <> 'usable' then
    raise exception 'damaged goods cannot be added to usable stock' using errcode = '23514';
  end if;

  if p_disposition = 'accept_to_stock' then
    insert into public.stock_adjustments(
      agent_id, product_catalog_id, quantity_delta, reason, notes,
      client_uuid, created_by_user_id, delivery_id
    ) values (
      v_target, v_return.product_catalog_id, v_return.actual_quantity,
      'replacement_return_accepted', coalesce(nullif(trim(p_notes), ''), 'Replacement return inspected and accepted'),
      p_client_uuid || ':accepted', v_actor, v_return.delivery_id
    ) returning id into v_adjustment_id;
    v_new_state := 'warehouse_accepted_stock'; v_event := 'received_and_accepted';
  elsif p_disposition = 'hold_for_vendor' then
    v_new_state := 'warehouse_hold_for_vendor'; v_event := 'received_for_vendor';
  elsif p_disposition = 'returned_to_vendor' then
    v_new_state := 'returned_to_vendor'; v_event := 'returned_to_vendor';
  else
    v_new_state := 'warehouse_rejected_damaged'; v_event := 'rejected_as_damaged';
  end if;

  update public.replacement_return_items
     set custody_state = v_new_state,
         current_holder_id = case when v_new_state = 'warehouse_hold_for_vendor' then v_target else null end,
         warehouse_received_at = coalesce(warehouse_received_at, now()),
         inspected_by_user_id = v_actor,
         stock_adjustment_id = v_adjustment_id,
         updated_at = now()
   where id = p_return_item_id;
  insert into public.replacement_return_events(
    client_uuid, return_item_id, event_type, from_holder_id, to_holder_id, quantity,
    condition, notes, actor_user_id
  ) values (
    p_client_uuid, p_return_item_id, v_event, v_return.current_holder_id,
    case when v_new_state in ('warehouse_accepted_stock','warehouse_hold_for_vendor') then v_target else null end,
    coalesce(v_return.actual_quantity, 0), v_return.reported_condition,
    coalesce(nullif(trim(p_notes), ''), p_disposition), v_actor
  );
end;
$$;


--
-- Name: record_agent_stock_count(uuid, date, jsonb, jsonb, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_agent_stock_count(p_batch_id uuid, p_week_ending date, p_items jsonb, p_expected jsonb, p_note text DEFAULT NULL::text, p_no_stock boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $_$
declare
  v_actor uuid := auth.uid();
  v_today date := (now() at time zone 'Africa/Lagos')::date;
  v_week date;
  v_actual jsonb;
  v_items jsonb;
  v_prior public.agent_stock_count_submissions%rowtype;
  v_count integer;
  v_off integer;
begin
  if not exists (select 1 from public.users where id = v_actor and role = 'agent' and is_active) then
    raise exception 'Only active agents can submit their own weekly count' using errcode = '42501';
  end if;
  if p_batch_id is null then raise exception 'Count reference required' using errcode = '22023'; end if;
  perform pg_advisory_xact_lock(hashtextextended('agent-count:' || p_batch_id::text, 0));
  select * into v_prior from public.agent_stock_count_submissions where batch_id = p_batch_id;
  if found then
    if v_prior.agent_id <> v_actor then raise exception 'Count reference belongs to another agent' using errcode = '42501'; end if;
    -- A retry returns the original receipt, even if stock or week has changed.
    return jsonb_build_object('recorded', v_prior.items_count, 'matched', v_prior.items_count - v_prior.off_count,
      'off', v_prior.off_count, 'items', v_prior.items, 'week_ending', v_prior.week_ending);
  end if;
  if exists (select 1 from public.stock_counts where batch_id = p_batch_id) then
    raise exception 'Count reference already used' using errcode = '22023';
  end if;
  v_week := v_today - ((extract(dow from v_today)::integer + 1) % 7);
  if p_week_ending is distinct from v_week then
    raise exception 'A new count week has started. Reload stock and count again.' using errcode = '22023';
  end if;
  if jsonb_typeof(p_items) is distinct from 'array' or jsonb_typeof(p_expected) is distinct from 'object' then
    raise exception 'Count items and stock snapshot required' using errcode = '22023';
  end if;
  if exists (
    select 1 from jsonb_array_elements(p_items) i
    where jsonb_typeof(i->'counted_qty') is distinct from 'number'
       or (i->>'counted_qty') !~ '^[0-9]{1,6}$'
       or i->>'product_catalog_id' is null
  ) then raise exception 'Enter a whole physical quantity of zero or more for every product' using errcode = '22023'; end if;
  if (select count(*) <> count(distinct i->>'product_catalog_id') from jsonb_array_elements(p_items) i) then
    raise exception 'A product cannot be counted twice' using errcode = '22023';
  end if;

  select coalesce(jsonb_object_agg(s.product_catalog_id::text, s.quantity_on_hand), '{}'::jsonb)
    into v_actual from public.current_stock s where s.agent_id = v_actor and s.quantity_on_hand <> 0;
  if v_actual <> p_expected then
    raise exception 'Stock changed while you were counting. Reload stock and recheck your quantities.' using errcode = '40001';
  end if;
  if exists (select 1 from jsonb_object_keys(v_actual) k where not exists (
    select 1 from jsonb_array_elements(p_items) i where i->>'product_catalog_id' = k
  )) then raise exception 'Count every product before submitting' using errcode = '22023'; end if;
  if exists (select 1 from jsonb_array_elements(p_items) i where not exists (
    select 1 from public.product_catalog p where p.id = (i->>'product_catalog_id')::uuid
      and (p.is_active or v_actual ? p.id::text)
  )) then raise exception 'A counted product is unavailable. Reload stock.' using errcode = '22023'; end if;
  if jsonb_array_length(p_items) = 0 and not coalesce(p_no_stock, false) then
    raise exception 'Confirm that you physically hold no stock' using errcode = '22023';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
    'product_catalog_id', p.id, 'product_name', p.product_name,
    'expected_qty', coalesce((v_actual->>p.id::text)::integer, 0),
    'counted_qty', (i->>'counted_qty')::integer,
    'variance', (i->>'counted_qty')::integer - coalesce((v_actual->>p.id::text)::integer, 0)
  ) order by p.product_name), '[]'::jsonb) into v_items
  from jsonb_array_elements(p_items) i join public.product_catalog p on p.id = (i->>'product_catalog_id')::uuid;
  v_count := jsonb_array_length(v_items);
  select count(*) into v_off from jsonb_array_elements(v_items) i where (i->>'variance')::integer <> 0;
  insert into public.agent_stock_count_submissions(batch_id, agent_id, week_ending, note, items_count, off_count, items)
    values (p_batch_id, v_actor, v_week, nullif(trim(p_note), ''), v_count, v_off, v_items);
  insert into public.stock_counts(batch_id, holder_id, product_catalog_id, expected_qty, counted_qty, variance, counted_by, note)
    select p_batch_id, v_actor, (i->>'product_catalog_id')::uuid, (i->>'expected_qty')::integer,
      (i->>'counted_qty')::integer, (i->>'variance')::integer, v_actor, nullif(trim(p_note), '')
    from jsonb_array_elements(v_items) i;
  perform public.write_audit('stock_count', p_batch_id, null,
    jsonb_build_object('holder_id', v_actor, 'week_ending', v_week, 'recorded', v_count, 'off', v_off),
    'agent weekly stock count', v_actor);
  return jsonb_build_object('recorded', v_count, 'matched', v_count - v_off, 'off', v_off,
    'items', v_items, 'week_ending', v_week);
end;
$_$;


--
-- Name: record_client_payment(text, uuid, date, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_client_payment(p_client_uuid text, p_client_id uuid, p_payment_date date, p_amount numeric, p_note text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_existing uuid;
  v_opening_date date;
  v_limit numeric;
  v_balance numeric;
  v_id uuid;
begin
  if not public.is_admin() then
    raise exception 'only admin can record client payments' using errcode = '42501';
  end if;
  if nullif(btrim(p_client_uuid), '') is null then
    raise exception 'client uuid required' using errcode = '22023';
  end if;
  if p_payment_date is null or p_payment_date > (now() at time zone 'Africa/Lagos')::date then
    raise exception 'payment date must be today or earlier' using errcode = '22023';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'payment amount must be greater than zero' using errcode = '22023';
  end if;

  -- Same lock key as record_client_payout so the two directions serialize
  -- per client.
  perform pg_advisory_xact_lock(hashtextextended(p_client_id::text, 0));

  select p.id into v_existing from public.client_payments p
   where p.client_uuid = p_client_uuid;
  if v_existing is not null then return v_existing; end if;

  select o.effective_date into v_opening_date
    from public.client_balance_openings o where o.client_id = p_client_id;
  if v_opening_date is null then
    raise exception 'start balance tracking for this client first' using errcode = '22023';
  end if;
  if p_payment_date < v_opening_date then
    raise exception 'payment date cannot be before balance tracking starts' using errcode = '22023';
  end if;

  v_limit := public.client_payment_limit(p_client_id, p_payment_date);
  if v_limit <= 0 then
    raise exception 'nothing was owed on %; there is no debt to settle', p_payment_date
      using errcode = '22023';
  end if;
  if p_amount > v_limit + 0.005 then
    raise exception 'payment % exceeds the % the client owed on %', p_amount, v_limit, p_payment_date
      using errcode = '22023';
  end if;

  select b.current_balance into v_balance
    from public.client_account_balances(p_payment_date, p_payment_date) b
   where b.client_id = p_client_id;
  v_balance := coalesce(v_balance, 0);

  insert into public.client_payments(
    client_uuid, client_id, payment_date, amount, balance_before, balance_after,
    note, received_by
  ) values (
    p_client_uuid, p_client_id, p_payment_date, p_amount, v_balance,
    v_balance + p_amount, nullif(btrim(p_note), ''), v_actor
  ) returning id into v_id;

  perform public.write_audit(
    'client_payment', v_id, null,
    jsonb_build_object(
      'client_id', p_client_id,
      'payment_date', p_payment_date,
      'amount', p_amount,
      'balance_before', v_balance,
      'balance_after', v_balance + p_amount,
      'note', nullif(btrim(p_note), '')
    ), 'create'
  );
  return v_id;
end;
$$;


--
-- Name: record_client_payout(text, uuid, date, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_client_payout(p_client_uuid text, p_client_id uuid, p_payout_date date, p_amount numeric, p_note text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_existing uuid;
  v_opening_date date;
  v_balance numeric;
  v_id uuid;
begin
  if not public.is_admin() then
    raise exception 'only admin can record client payouts' using errcode = '42501';
  end if;
  if nullif(btrim(p_client_uuid), '') is null then
    raise exception 'client uuid required' using errcode = '22023';
  end if;
  if p_payout_date is null or p_payout_date > (now() at time zone 'Africa/Lagos')::date then
    raise exception 'payout date must be today or earlier' using errcode = '22023';
  end if;
  if p_amount is null or p_amount <= 0 then
    raise exception 'payout amount must be greater than zero' using errcode = '22023';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(p_client_id::text, 0));

  select p.id into v_existing from public.client_payouts p
   where p.client_uuid = p_client_uuid;
  if v_existing is not null then return v_existing; end if;

  select o.effective_date into v_opening_date
    from public.client_balance_openings o where o.client_id = p_client_id;
  if v_opening_date is null then
    raise exception 'start balance tracking for this client first' using errcode = '22023';
  end if;
  if p_payout_date < v_opening_date then
    raise exception 'payout date cannot be before balance tracking starts' using errcode = '22023';
  end if;

  select b.current_balance into v_balance
    from public.client_account_balances(p_payout_date, p_payout_date) b
   where b.client_id = p_client_id;
  v_balance := coalesce(v_balance, 0);
  if v_balance <= 0 then
    raise exception 'no payout is due; the balance is %', v_balance using errcode = '22023';
  end if;
  if p_amount > v_balance + 0.005 then
    raise exception 'payout % exceeds the available balance %', p_amount, v_balance
      using errcode = '22023';
  end if;

  insert into public.client_payouts(
    client_uuid, client_id, payout_date, amount, balance_before, balance_after,
    note, paid_by
  ) values (
    p_client_uuid, p_client_id, p_payout_date, p_amount, v_balance,
    v_balance - p_amount, nullif(btrim(p_note), ''), v_actor
  ) returning id into v_id;

  perform public.write_audit(
    'client_payout', v_id, null,
    jsonb_build_object(
      'client_id', p_client_id,
      'payout_date', p_payout_date,
      'amount', p_amount,
      'balance_before', v_balance,
      'balance_after', v_balance - p_amount,
      'note', nullif(btrim(p_note), '')
    ), 'create'
  );
  return v_id;
end;
$$;


--
-- Name: record_replacement_attempt(text, uuid, text, text, date, numeric, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_replacement_attempt(p_client_uuid text, p_delivery_id uuid, p_outcome text, p_notes text DEFAULT NULL::text, p_next_attempt_date date DEFAULT NULL::date, p_client_charge numeric DEFAULT 0, p_agent_payment numeric DEFAULT 0) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_delivery record;
  v_status text;
  v_date date;
begin
  if nullif(trim(p_client_uuid), '') is null then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;
  if exists (select 1 from public.replacement_attempts where client_uuid = p_client_uuid) then
    return;
  end if;
  select d.* into v_delivery
    from public.deliveries d join public.replacement_jobs r on r.delivery_id = d.id
   where d.id = p_delivery_id for update of d;
  if not found then raise exception 'replacement not found' using errcode = 'P0002'; end if;
  if not (public.is_manager() or (
    public.current_user_role() = 'agent' and v_delivery.assigned_agent_id = v_actor
  )) then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  if v_delivery.current_status = 'replacement_completed' then
    raise exception 'replacement is already completed' using errcode = '22023';
  end if;
  if v_delivery.assigned_agent_id is null then
    raise exception 'assign an agent before recording a replacement attempt'
      using errcode = '23514';
  end if;
  if exists (
    select 1 from public.delivery_status_defs
     where status = v_delivery.current_status and category = 'terminal'
  ) then
    raise exception 'replacement is closed; reopen it before recording another attempt'
      using errcode = '22023';
  end if;
  if p_outcome not in (
    'customer_unreachable', 'customer_postponed', 'details_incorrect',
    'customer_rejected', 'cancelled', 'other'
  ) then
    raise exception 'invalid unsuccessful attempt outcome' using errcode = '23514';
  end if;
  if coalesce(p_client_charge, -1) < 0 or coalesce(p_agent_payment, -1) < 0 then
    raise exception 'attempt charges must be >= 0' using errcode = '23514';
  end if;
  if p_outcome in ('customer_postponed', 'details_incorrect') then
    if p_next_attempt_date is null or p_next_attempt_date <= (now() at time zone 'Africa/Lagos')::date then
      raise exception 'a future retry date is required' using errcode = '23514';
    end if;
    v_status := 'postponed';
    v_date := public._ensure_workday(p_next_attempt_date);
  elsif p_outcome = 'customer_unreachable' then
    v_status := 'not_answering';
    v_date := v_delivery.scheduled_date;
  elsif p_outcome = 'customer_rejected' then
    v_status := 'failed_delivery';
    v_date := v_delivery.scheduled_date;
  elsif p_outcome = 'cancelled' then
    v_status := 'cancelled';
    v_date := v_delivery.scheduled_date;
  else
    v_status := 'follow_up';
    v_date := coalesce(p_next_attempt_date, v_delivery.scheduled_date);
  end if;

  insert into public.replacement_attempts(
    delivery_id, client_uuid, outcome, status_after, notes, next_attempt_date,
    client_charge, agent_payment, assigned_agent_id, attempted_by_user_id
  ) values (
    p_delivery_id, p_client_uuid, p_outcome, v_status, nullif(trim(p_notes), ''), v_date,
    p_client_charge, p_agent_payment, v_delivery.assigned_agent_id, v_actor
  );
  insert into public.delivery_status_history(
    delivery_id, from_status, to_status, changed_by_user_id, client_uuid,
    effective_at, reason, notes
  ) values (
    p_delivery_id, v_delivery.current_status, v_status, v_actor, p_client_uuid,
    now(), 'replacement_' || p_outcome, nullif(trim(p_notes), '')
  );
  update public.deliveries
     set current_status = v_status,
         scheduled_date = v_date,
         charged_snapshot = coalesce(charged_snapshot, 0) + p_client_charge,
         agent_payment_snapshot = coalesce(agent_payment_snapshot, 0) + p_agent_payment
   where id = p_delivery_id;
end;
$$;


--
-- Name: record_stock_count(uuid, uuid, jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_stock_count(p_batch_id uuid, p_holder_id uuid, p_items jsonb, p_note text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor        uuid := auth.uid();
  v_role         text;
  v_warehouse_id uuid;
  v_item         jsonb;
  v_pid          uuid;
  v_counted      int;
  v_expected     int;
  v_recorded     int := 0;
  v_matched      int := 0;
  v_off          int := 0;
begin
  if v_actor is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;

  select role, warehouse_id into v_role, v_warehouse_id from public.users where id = v_actor;

  -- Permission gate. A count never mutates stock, so this is intentionally
  -- broader than the adjustment gate — but warehouse is still scoped to its place.
  if v_role in ('admin', 'dispatcher') then
    null;
  elsif v_role = 'warehouse' and p_holder_id = coalesce(v_warehouse_id, v_actor) then
    null;
  else
    raise exception 'permission denied: cannot record a count for this holder'
      using errcode = '42501',
            hint    = 'admin/dispatcher can count any holder; warehouse can count only its own place.';
  end if;

  if p_batch_id is null then
    raise exception 'batch_id required' using errcode = '23514';
  end if;
  if not exists (select 1 from public.users where id = p_holder_id) then
    raise exception 'holder not found' using errcode = '23514';
  end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' then
    raise exception 'items must be a json array' using errcode = '23514';
  end if;

  for v_item in select jsonb_array_elements(p_items) loop
    v_pid     := nullif(v_item->>'product_catalog_id', '')::uuid;
    v_counted := (v_item->>'counted_qty')::int;
    if v_pid is null or v_counted is null then
      continue;
    end if;
    if not exists (select 1 from public.product_catalog where id = v_pid) then
      continue;
    end if;
    -- Idempotency: this (batch, product) already recorded → skip.
    if exists (
      select 1 from public.stock_counts where batch_id = p_batch_id and product_catalog_id = v_pid
    ) then
      continue;
    end if;

    select coalesce(quantity_on_hand, 0) into v_expected
      from public.current_stock
     where agent_id = p_holder_id and product_catalog_id = v_pid;
    v_expected := coalesce(v_expected, 0);

    insert into public.stock_counts (
      batch_id, holder_id, product_catalog_id, expected_qty, counted_qty, variance, counted_by, note
    ) values (
      p_batch_id, p_holder_id, v_pid, v_expected, v_counted, v_counted - v_expected, v_actor, p_note
    );

    v_recorded := v_recorded + 1;
    if v_counted = v_expected then
      v_matched := v_matched + 1;
    else
      v_off := v_off + 1;
    end if;
  end loop;

  perform public.write_audit(
    'stock_count', p_batch_id, null,
    jsonb_build_object(
      'holder_id', p_holder_id, 'recorded', v_recorded,
      'matched', v_matched, 'off', v_off, 'note', p_note
    ),
    'record stock count', v_actor
  );

  return jsonb_build_object('recorded', v_recorded, 'matched', v_matched, 'off', v_off);
end;
$$;


--
-- Name: reject_location_change(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reject_location_change(p_change_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_role  text;
  v_zone  text;
  v_c     public.delivery_location_changes%rowtype;
begin
  if not public.is_manager() then
    raise exception 'permission denied: rejecting a zone change requires admin or dispatcher'
      using errcode = '42501';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required to reject' using errcode = '22023';
  end if;

  select * into v_c from public.delivery_location_changes where id = p_change_id for update;
  if not found then raise exception 'change not found: %', p_change_id using errcode = 'P0002'; end if;
  if v_c.state <> 'pending' then
    raise exception 'this change is already % and cannot be rejected', v_c.state using errcode = '22023';
  end if;

  update public.delivery_location_changes
     set state = 'rejected', decided_by_user_id = v_actor, decided_at = now(),
         reason = reason || ' | rejected: ' || btrim(p_reason)
   where id = p_change_id;

  -- Surface the reason to the AGENT. Before this, the typed reason lived only in
  -- delivery_location_changes.reason, which no agent-facing screen reads (the
  -- list RPC is is_manager()-gated), so the agent got a generic push and nothing
  -- more. Seed a manager->agent note on the delivery's thread: the agent detail
  -- already renders <MessageThread> and agentUnreadCounts already badges
  -- ops-authored unread messages, so the reason shows up (durable, in-context,
  -- replyable, badged) with NO app change. author_id/role = the real manager so
  -- the thread shows their name and it's accountable. issue_type left null (a
  -- plain note, like a reply) so it does NOT register as an actionable flag; it
  -- is ops-authored so it will not trip the ops "agent replied" chip either.
  select role into v_role from public.users where id = v_actor;
  v_role := case when v_role in ('admin', 'dispatcher') then v_role else 'admin' end;
  select name into v_zone from public.locations where id = v_c.to_location_id;

  insert into public.delivery_messages (delivery_id, author_id, author_role, note)
    values (
      v_c.delivery_id, v_actor, v_role,
      'Zone change to ' || coalesce(v_zone, 'the requested zone')
        || ' not approved: ' || btrim(p_reason)
    );

  perform public.send_edge_notification(jsonb_build_object(
    'audience', 'user', 'user_id', v_c.requested_by_agent_id::text,
    'title', 'Zone change rejected',
    -- Include the reason inline (OS truncates a long one); the full text is
    -- durably in the order's messages, where the tap lands.
    'body',  'Not approved: ' || btrim(p_reason),
    'data',  jsonb_build_object('delivery_id', v_c.delivery_id)));
end;
$$;


--
-- Name: release_edit_lock(text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_edit_lock(p_entity_type text, p_entity_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  delete from public.edit_locks
   where entity_type = p_entity_type
     and entity_id   = p_entity_id
     and user_id     = auth.uid();
end $$;


--
-- Name: release_followup(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_followup(p_delivery_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  delete from public.delivery_followups
   where delivery_id = p_delivery_id
     and user_id     = auth.uid();
end $$;


--
-- Name: release_my_expo_push_token(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_my_expo_push_token(p_token text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if auth.uid() is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  delete from public.push_tokens
   where token = nullif(trim(p_token), '')
     and user_id = auth.uid();
end;
$$;


--
-- Name: release_postponed_due(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.release_postponed_due(p_due_date date) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_system_id uuid;
  v_row record;
  v_duplicate record;
  v_count integer := 0;
  v_cancelled integer := 0;
  v_deduped integer := 0;
  v_previous_eod_setting text := coalesce(current_setting('reda.in_eod_rollover', true), '');
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'releasing postponed orders requires admin or dispatcher role'
      using errcode = '42501';
  end if;

  select id into v_system_id
    from public.users
   where lower(email) = 'system@reda.local'
   limit 1;
  if v_system_id is null then
    raise exception 'Reda System user not found; postponed release cannot be audited';
  end if;
  v_actor := coalesce(v_actor, v_system_id);

  -- Suppress the terminal sibling cascade while this function deliberately
  -- selects one canonical row and closes only the ranked surplus copies.
  perform set_config('reda.in_eod_rollover', 'true', true);
  perform pg_catalog.pg_advisory_xact_lock(
    pg_catalog.hashtextextended('release_postponed_due:' || p_due_date::text, 0)
  );

  -- Defensive backstop. Immediate consolidation handles new postponements,
  -- while this pass repairs pre-existing rows and any legacy/race edge case
  -- before users see them in the unassigned pool.
  for v_duplicate in
    with eligible as (
      select d.id, d.client_id, d.customer_phone_normalized,
             coalesce(d.items_fingerprint, d.product_catalog_id::text) as item_key,
             d.scheduled_date, d.text_fingerprint,
             public._norm_address(d.raw_address) as norm_addr,
             d.assigned_agent_id, d.created_at, d.updated_at
        from public.deliveries d
       where d.order_type = 'delivery' and d.current_status = 'postponed'
         and d.scheduled_date <= p_due_date
         and d.deleted_at is null
         and d.order_type = 'delivery'
         and d.customer_phone_normalized is not null
    ),
    clustered as (
      select e.*,
             (
               select min(e2.id::text)
                 from eligible e2
                where e2.client_id = e.client_id
                  and e2.customer_phone_normalized = e.customer_phone_normalized
                  and e2.item_key = e.item_key
                  and e2.scheduled_date = e.scheduled_date
                  and (
                    e2.id = e.id
                    or (e2.text_fingerprint is not null
                        and e2.text_fingerprint = e.text_fingerprint)
                    or (e2.norm_addr is not null and e2.norm_addr = e.norm_addr)
                  )
             ) as sibling_cluster
        from eligible e
    ),
    ranked as (
      select c.*,
             row_number() over (
               partition by c.client_id, c.customer_phone_normalized,
                            c.item_key, c.scheduled_date, c.sibling_cluster
               order by c.updated_at desc, c.created_at asc, c.id asc
             ) as duplicate_rank,
             first_value(c.id) over (
               partition by c.client_id, c.customer_phone_normalized,
                            c.item_key, c.scheduled_date, c.sibling_cluster
               order by c.updated_at desc, c.created_at asc, c.id asc
             ) as canonical_delivery_id
        from clustered c
    )
    select *
      from ranked
     where duplicate_rank > 1
     order by scheduled_date, sibling_cluster, duplicate_rank
  loop
    perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(
      concat_ws('|',
        v_duplicate.client_id::text,
        v_duplicate.customer_phone_normalized,
        v_duplicate.item_key,
        v_duplicate.scheduled_date::text
      ), 0
    ));

    -- Recheck under a row lock: an immediate-consolidation trigger may have
    -- closed this copy while the release job was waiting.
    perform 1
      from public.deliveries
     where id = v_duplicate.id
       and current_status = 'postponed'
     for update;
    if not found then
      continue;
    end if;

    insert into public.delivery_status_history
      (delivery_id, from_status, to_status, changed_by_user_id,
       client_uuid, reason, effective_at)
    values
      (v_duplicate.id, 'postponed', 'cancelled', v_system_id,
       'postpone-release-dedup:' || v_duplicate.canonical_delivery_id::text
         || ':' || v_duplicate.id::text,
       'Duplicate postponed copy consolidated into order '
         || v_duplicate.canonical_delivery_id::text || ' before release.',
       now())
    on conflict (client_uuid) do nothing;

    update public.deliveries
       set current_status     = 'cancelled',
           assigned_agent_id = null,
           updated_at         = now()
     where id = v_duplicate.id
       and current_status = 'postponed';

    if found then
      perform public.write_audit(
        p_entity_type := 'delivery',
        p_entity_id   := v_duplicate.id,
        p_old         := jsonb_build_object(
          'current_status', 'postponed',
          'assigned_agent_id', v_duplicate.assigned_agent_id,
          'scheduled_date', v_duplicate.scheduled_date
        ),
        p_new         := jsonb_build_object(
          'current_status', 'cancelled',
          'assigned_agent_id', null,
          'scheduled_date', v_duplicate.scheduled_date,
          'canonical_delivery_id', v_duplicate.canonical_delivery_id
        ),
        p_reason      := 'postponed_release_duplicate_consolidated',
        p_actor_id    := v_system_id
      );
      v_deduped := v_deduped + 1;
    end if;
  end loop;

  -- Existing release/auto-cancel behavior, now operating only on canonical
  -- rows after the defensive deduplication pass.
  for v_row in
    select d.id, d.current_status, d.scheduled_date, d.assigned_agent_id,
           cl.auto_cancel_soft_fails
      from public.deliveries d
      join public.clients cl on cl.id = d.client_id
     where d.order_type = 'delivery' and d.current_status = 'postponed'
       and d.scheduled_date <= p_due_date
       and d.deleted_at is null
     for update of d
  loop
    if v_row.auto_cancel_soft_fails then
      perform public.change_delivery_status(
        p_client_uuid => 'eod-autocancel-postponed:' || v_row.scheduled_date::text
          || ':' || v_row.id::text,
        p_delivery_id => v_row.id,
        p_to_status   => 'failed_delivery',
        p_reason      => 'eod_auto_cancel:client_policy'
      );

      update public.deliveries
         set assigned_agent_id = null,
             updated_at = now()
       where id = v_row.id;

      v_cancelled := v_cancelled + 1;
      continue;
    end if;

    insert into public.delivery_status_history
      (delivery_id, from_status, to_status, changed_by_user_id,
       client_uuid, reason, effective_at)
    values
      (v_row.id, v_row.current_status, 'pending', v_actor,
       'eod-release-postponed:' || v_row.scheduled_date::text || ':' || v_row.id::text,
       'postponed order came due — released to the unassigned pool for fresh assignment',
       now())
    on conflict (client_uuid) do nothing;

    update public.deliveries
       set current_status      = 'pending',
           assigned_agent_id  = null,
           rolled_from_status = 'postponed',
           rolled_from_date   = v_row.scheduled_date,
           updated_at         = now()
     where id = v_row.id;

    perform public.write_audit(
      p_entity_type := 'delivery',
      p_entity_id   := v_row.id,
      p_old         := jsonb_build_object(
        'current_status', 'postponed',
        'assigned_agent_id', v_row.assigned_agent_id,
        'scheduled_date', v_row.scheduled_date
      ),
      p_new         := jsonb_build_object(
        'current_status', 'pending',
        'assigned_agent_id', null,
        'scheduled_date', v_row.scheduled_date,
        'rolled_from_status', 'postponed'
      ),
      p_reason      := 'eod_release_postponed',
      p_actor_id    := v_actor
    );

    v_count := v_count + 1;
  end loop;

  if v_deduped > 0 then
    raise notice 'eod: consolidated % duplicate postponed copy/copies before release',
      v_deduped;
  end if;
  if v_count > 0 then
    raise notice 'eod: released % postponed order(s) due on/before % into the unassigned pool',
      v_count, p_due_date;
  end if;
  if v_cancelled > 0 then
    raise notice 'eod: auto-cancelled % postponed order(s) due on/before % per client policy',
      v_cancelled, p_due_date;
  end if;

  -- A direct RPC call may share a wider transaction. Restore the caller's
  -- setting so unrelated status changes later in that transaction are not
  -- accidentally exempted from sibling coordination.
  perform set_config('reda.in_eod_rollover', v_previous_eod_setting, true);

  return v_count;
end
$$;


--
-- Name: remove_customer_blacklist(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.remove_customer_blacklist(p_id uuid, p_note text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_row   public.customer_blacklist;
begin
  if not public.is_manager() then
    raise exception 'permission denied: admin or dispatcher only' using errcode = '42501';
  end if;
  select * into v_row from public.customer_blacklist where id = p_id for update;
  if not found then raise exception 'Blacklist entry not found' using errcode = '22023'; end if;
  if v_row.removed_at is not null then return; end if;
  update public.customer_blacklist
     set removed_by = v_actor, removed_at = now(), removal_note = nullif(trim(p_note), '')
   where id = p_id;
  -- write_audit logs one row per key whose value changed, so old/new carry the
  -- same keys: only removed_at and removal_note actually change here.
  perform public.write_audit('customer_blacklist', p_id,
    jsonb_build_object('removed_at', null, 'removal_note', null),
    jsonb_build_object('removed_at', now(), 'removal_note', nullif(trim(p_note), '')),
    'remove customer number from blacklist', v_actor);
end;
$$;


--
-- Name: rep_activity_summary(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rep_activity_summary(p_from timestamp with time zone, p_to timestamp with time zone) RETURNS TABLE(rep_id uuid, display_name text, notifies bigint, messages bigint, calls bigint, last_active_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  -- Admin-only. Reps/dispatchers must not see peer or self performance.
  if not coalesce(public.is_admin(), false) then
    raise exception 'not authorised to view rep performance' using errcode = '42501';
  end if;

  return query
  with reps as (
    select u.id, u.display_name
      from public.users u
     where u.role = 'rep'
       and u.is_active is true
       and u.display_name not ilike '%test%'
  ),
  n as (  -- primary KPI: client notifications authored in range
    select dcn.notified_by_user_id as rep_id,
           count(*)                as cnt,
           max(dcn.notified_at)    as last_at
      from public.delivery_client_notifications dcn
     where dcn.notified_at >= p_from and dcn.notified_at < p_to
     group by dcn.notified_by_user_id
  ),
  m as (  -- thread messages posted as a rep in range
    select dm.author_id       as rep_id,
           count(*)           as cnt,
           max(dm.created_at) as last_at
      from public.delivery_messages dm
     where dm.author_role = 'rep'
       and dm.created_at >= p_from and dm.created_at < p_to
     group by dm.author_id
  ),
  c as (  -- calls initiated in range
    select calls.caller_id       as rep_id,
           count(*)              as cnt,
           max(calls.created_at) as last_at
      from public.calls
     where calls.created_at >= p_from and calls.created_at < p_to
     group by calls.caller_id
  )
  select
    r.id,
    r.display_name,
    coalesce(n.cnt, 0)::bigint,
    coalesce(m.cnt, 0)::bigint,
    coalesce(c.cnt, 0)::bigint,
    -- greatest() returns the largest non-null arg; NULL only when fully idle.
    greatest(n.last_at, m.last_at, c.last_at)
  from reps r
  left join n on n.rep_id = r.id
  left join m on m.rep_id = r.id
  left join c on c.rep_id = r.id
  order by coalesce(n.cnt, 0) desc,
           greatest(n.last_at, m.last_at, c.last_at) desc nulls last,
           r.display_name;
end;
$$;


--
-- Name: rep_notify_coverage(timestamp with time zone, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rep_notify_coverage(p_from timestamp with time zone, p_to timestamp with time zone) RETURNS TABLE(notifiable_updates bigint, notified bigint, pct_notified numeric, not_notified bigint, median_minutes_to_notify numeric, backlog_open bigint, oldest_open_update_age_minutes numeric, last_team_notify_at timestamp with time zone)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  k_notify_exempt constant text[] := array[
    'pending','delivered','rolled_over','agent_cancelled',
    'deferred_to_client','unserious','picked_up','waybilled'];
begin
  if not coalesce(public.is_admin(), false) then
    raise exception 'not authorised to view rep performance' using errcode = '42501';
  end if;

  return query
  with notifiable as (
    select dsh.id as status_history_id, dsh.delivery_id, dsh.changed_at
      from public.delivery_status_history dsh
      join public.deliveries d on d.id = dsh.delivery_id and d.deleted_at is null
      join public.clients c on c.id = d.client_id
     where dsh.changed_at >= p_from and dsh.changed_at < p_to
       and dsh.to_status <> all (k_notify_exempt)
       and not (dsh.to_status = 'failed_delivery' and c.auto_cancel_soft_fails)
  ),
  joined as (
    select nf.status_history_id, nf.delivery_id, nf.changed_at, dcn.notified_at,
           case when dcn.notified_at is not null
                then extract(epoch from (dcn.notified_at - nf.changed_at)) / 60.0
           end as minutes_to_notify
      from notifiable nf
      left join public.delivery_client_notifications dcn
        on dcn.status_history_id = nf.status_history_id
  ),
  agg as (
    select count(*) as notifiable_updates,
           count(j.notified_at) as notified,
           count(*) filter (where j.notified_at is null) as not_notified,
           percentile_cont(0.5) within group (order by j.minutes_to_notify)
             filter (where j.notified_at is not null) as median_minutes
      from joined j
  ),
  backlog as (
    select count(*) as backlog_open,
           extract(epoch from (now() - min(lh.changed_at))) / 60.0 as oldest_open_age_min
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
      join lateral (
        select h.id, h.changed_at
        from public.delivery_status_history h
        where h.delivery_id = d.id
        order by h.changed_at desc
        limit 1
      ) lh on true
      left join public.delivery_client_notifications dcn
        on dcn.status_history_id = lh.id
     where d.deleted_at is null
       and sd.category <> 'terminal'
       and d.current_status <> all (k_notify_exempt)
       and dcn.status_history_id is null
  )
  select
    agg.notifiable_updates,
    agg.notified,
    case when agg.notifiable_updates = 0 then 0::numeric
         else round(100.0 * agg.notified / agg.notifiable_updates, 1) end,
    agg.not_notified,
    round(agg.median_minutes::numeric, 1),
    backlog.backlog_open,
    round(backlog.oldest_open_age_min::numeric, 1),
    (select max(dcn2.notified_at) from public.delivery_client_notifications dcn2)
  from agg, backlog;
end;
$$;


--
-- Name: reply_to_delivery(uuid, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.reply_to_delivery(p_delivery_id uuid, p_text text, p_client_uuid uuid) RETURNS public.delivery_messages
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_user           uuid := auth.uid();
  v_role           text;
  v_status         text;
  v_assigned_agent uuid;
  v_existing       public.delivery_messages%rowtype;
  v_new            public.delivery_messages%rowtype;
begin
  if v_user is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if p_client_uuid is null then
    raise exception 'p_client_uuid is required' using errcode = '22023';
  end if;
  if p_text is null or length(trim(p_text)) = 0 then
    raise exception 'reply text is required' using errcode = '22023';
  end if;

  -- Idempotency. Same client_uuid = same row.
  select * into v_existing
    from public.delivery_messages
   where client_uuid = p_client_uuid;
  if found then
    return v_existing;
  end if;

  select current_status, assigned_agent_id
    into v_status, v_assigned_agent
    from public.deliveries where id = p_delivery_id;
  if v_status is null then
    raise exception 'delivery not found' using errcode = 'P0002';
  end if;
  if public._dm_is_terminal_status(v_status) then
    raise exception 'cannot reply on a terminal delivery (status %)', v_status
      using errcode = '22023';
  end if;

  -- Participant gate: assigned agent OR any operational coordinator role
  -- (admin/dispatcher/rep). is_admin_or_dispatcher() is the shared helper
  -- whose body already names that set; this preserves the single source of
  -- truth for "ops" across the codebase.
  select role into v_role from public.users where id = v_user;
  if not (
    public.is_admin_or_dispatcher()
    or (v_role = 'agent' and v_assigned_agent = v_user)
  ) then
    raise exception 'permission denied' using errcode = '42501';
  end if;

  -- 'Not my route' is an admin/dispatcher reassignment job. Reps may read the
  -- thread but must not engage while the flag is open: a reply would mislead the
  -- agent and (via mark_messages_read below) try to consume the flag. The UI
  -- already hides the composer for reps in this case; this is the server guard.
  if v_role = 'rep' and exists (
    select 1 from public.delivery_messages
     where delivery_id = p_delivery_id
       and author_role = 'agent'
       and issue_type = 'not_my_route'
       and read_at is null
  ) then
    raise exception 'not my route is handled by an admin or dispatcher'
      using errcode = '42501';
  end if;

  -- author_role is the user's actual role — drives the trigger's push
  -- routing (agent → reps, ops → assigned agent).
  insert into public.delivery_messages (
    delivery_id, author_id, author_role, note, client_uuid
  ) values (
    p_delivery_id, v_user, v_role, trim(p_text), p_client_uuid
  ) returning * into v_new;

  -- Replying IS engaging, so clear the other party's unread for this delivery.
  -- (ops reply → clears the agent's messages → ops badge clears; agent reply →
  -- clears ops messages → agent badge clears.) Role-aware via auth.uid().
  perform public.mark_messages_read(p_delivery_id);

  perform public.write_audit(
    'delivery_message', v_new.id,
    null,
    jsonb_build_object('text', p_text),
    'reply', null
  );

  return v_new;
end $$;


--
-- Name: requeue_failed_inbound(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.requeue_failed_inbound(p_ids uuid[]) RETURNS integer LANGUAGE plpgsql AS $$ begin raise exception 'No external bot in tests'; end $$;

--
-- Name: resolve_inbound_to_delivery(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_inbound_to_delivery(p_inbound_id uuid, p_delivery_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_text  text;
begin
  if not public.is_manager() then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  perform public._assert_holds_lock('bot_inbound', p_inbound_id);
  update public.bot_inbound_messages
     set status = 'created_delivery',
         delivery_id = p_delivery_id,
         processed_at = now()
   where id = p_inbound_id
   returning raw_text into v_text;
  if not found then
    raise exception 'inbound not found' using errcode = 'P0002';
  end if;

  -- Backstop: the delivery must carry the WhatsApp message it came from.
  -- The current app passes it at creation; older bundles did not.
  if v_text is not null then
    update public.deliveries d
       set bot_raw_message  = v_text,
           text_fingerprint = coalesce(d.text_fingerprint, public._text_fingerprint(v_text))
     where d.id = p_delivery_id
       and d.bot_raw_message is null;
    if found then
      perform public.write_audit('delivery', p_delivery_id,
        jsonb_build_object('bot_raw_message', null),
        jsonb_build_object('bot_raw_message', v_text),
        'review fix: WhatsApp message retained on the delivery', v_actor);
    end if;
  end if;

  -- Defence in depth: drop the lock here too (client also releases).
  delete from public.edit_locks
   where entity_type='bot_inbound' and entity_id=p_inbound_id;
end $$;


--
-- Name: return_delivery_leftover(text, uuid, integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.return_delivery_leftover(p_client_uuid text, p_delivery_id uuid, p_quantity integer DEFAULT NULL::integer, p_notes text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor      uuid := auth.uid();
  v_role       text := public.current_user_role();
  v_d          public.deliveries%rowtype;
  v_leftover   int;
  v_qty        int;
  v_wh         uuid;
  v_wh_count   int;
  v_existing   uuid;
  v_on_hand    int;
  v_source_id  uuid;
  v_target_id  uuid;
begin
  if v_actor is null then
    raise exception 'not signed in' using errcode = '28000';
  end if;
  if p_client_uuid is null or btrim(p_client_uuid) = '' then
    raise exception 'client_uuid required' using errcode = '23514';
  end if;

  -- Idempotency (queue retries): same client_uuid => return the prior source row.
  select id into v_existing
    from public.stock_adjustments
   where client_uuid = p_client_uuid
   limit 1;
  if v_existing is not null then
    return v_existing;
  end if;

  select * into v_d from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_d.deleted_at is not null then
    raise exception 'delivery has been deleted' using errcode = '22023';
  end if;

  -- Permission: the assigned agent (their own delivery) OR ops.
  if not (
       public.is_admin_or_dispatcher()
       or (v_role = 'agent' and v_d.assigned_agent_id = v_actor)
     ) then
    raise exception 'permission denied: only the assigned agent or ops can return leftover stock'
      using errcode = '42501';
  end if;

  -- Must be a delivered row. Raised as 22023 (retryable, not in the queue's
  -- terminal set) so if the paired mark-delivered job hasn't drained yet the
  -- queue simply retries instead of dead-lettering.
  if v_d.current_status <> 'delivered' then
    raise exception 'leftover can only be returned on a delivered order (status=%). Mark delivered first.',
      v_d.current_status using errcode = '22023';
  end if;
  if v_d.assigned_agent_id is null then
    raise exception 'delivery has no assigned agent; nothing to return from' using errcode = '22023';
  end if;

  v_leftover := coalesce(v_d.quantity_ordered, 0)
              - coalesce(v_d.quantity_delivered, v_d.quantity_ordered, 0);
  if v_leftover <= 0 then
    raise exception 'no leftover to return (ordered=%, delivered=%)',
      v_d.quantity_ordered, v_d.quantity_delivered using errcode = '22023';
  end if;

  v_qty := coalesce(p_quantity, v_leftover);
  if v_qty <= 0 or v_qty > v_leftover then
    raise exception 'return quantity % out of range (leftover is %)', v_qty, v_leftover
      using errcode = '23514';
  end if;

  -- Resolve the warehouse PLACE (the stock holder = role 'warehouse' with
  -- warehouse_id IS NULL; staff have a non-null warehouse_id and hold no stock).
  select count(*) into v_wh_count
    from public.users
   where role = 'warehouse' and warehouse_id is null and is_active = true;
  if v_wh_count = 0 then
    raise exception 'no active warehouse found to receive the return' using errcode = 'P0002';
  end if;
  if v_wh_count > 1 then
    -- Single-warehouse assumption (Shomolu today). If Reda opens a second
    -- warehouse, give this RPC an explicit p_warehouse_id target.
    raise exception 'multiple active warehouses exist; an explicit target is required' using errcode = '22023';
  end if;
  select id into v_wh
    from public.users
   where role = 'warehouse' and warehouse_id is null and is_active = true;

  -- Stock sufficiency on the agent's hand (mirrors create_stock_transfer).
  select coalesce(quantity_on_hand, 0) into v_on_hand
    from public.current_stock
   where agent_id           = v_d.assigned_agent_id
     and product_catalog_id = v_d.product_catalog_id;
  if coalesce(v_on_hand, 0) < v_qty then
    raise exception
      'insufficient_stock: agent has % units, return needs %',
      coalesce(v_on_hand, 0), v_qty
    using errcode = 'P0001',
          hint = jsonb_build_object(
            'code',    'insufficient_stock',
            'on_hand', coalesce(v_on_hand, 0),
            'needed',  v_qty
          )::text;
  end if;

  -- Paired warehouse_return: agent -qty, warehouse +qty (same shape as
  -- create_stock_transfer: two rows linked via related_adjustment_id).
  insert into public.stock_adjustments (
    agent_id, product_catalog_id, quantity_delta, reason, notes,
    client_uuid, created_by_user_id
  ) values (
    v_d.assigned_agent_id, v_d.product_catalog_id, -v_qty, 'warehouse_return',
    coalesce(p_notes, 'leftover return from delivery ' || p_delivery_id::text),
    p_client_uuid, v_actor
  ) returning id into v_source_id;

  insert into public.stock_adjustments (
    agent_id, product_catalog_id, quantity_delta, reason, notes,
    client_uuid, created_by_user_id, related_adjustment_id
  ) values (
    v_wh, v_d.product_catalog_id, v_qty, 'warehouse_return',
    coalesce(p_notes, 'leftover return from delivery ' || p_delivery_id::text),
    p_client_uuid || ':paired', v_actor, v_source_id
  ) returning id into v_target_id;

  update public.stock_adjustments
     set related_adjustment_id = v_target_id
   where id = v_source_id;

  perform public.write_audit(
    'stock_transfer', v_source_id, null,
    jsonb_build_object(
      'kind',                  'delivery_leftover_return',
      'delivery_id',           p_delivery_id,
      'from_user_id',          v_d.assigned_agent_id,
      'to_user_id',            v_wh,
      'product_catalog_id',    v_d.product_catalog_id,
      'quantity',              v_qty,
      'reason',                'warehouse_return',
      'related_adjustment_id', v_target_id
    )
  );

  return v_source_id;
end;
$$;


--
-- Name: revert_delivery_to_pending(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.revert_delivery_to_pending(p_delivery_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor        uuid := auth.uid();
  v_row          public.deliveries%rowtype;
  v_history_key  text := gen_random_uuid()::text;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if (select role from public.users where id = v_actor)
       not in ('admin','dispatcher') then
    raise exception 'revert delivered requires admin or dispatcher role'
      using errcode = '42501';
  end if;

  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required for revert' using errcode = '22023';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_row.deleted_at is not null then
    raise exception 'cannot revert a deleted delivery' using errcode = '22023';
  end if;

  -- Waybills/pickups never enter the delivery lifecycle — reverting one strands
  -- it in a non-terminal status and breaks the EOD rollover. Block at the source.
  if v_row.order_type is distinct from 'delivery' then
    raise exception 'only deliveries can be reverted to pending (order_type=%)', v_row.order_type
      using errcode = '22023',
            hint   = 'waybills/pickups are money-only records; soft-delete and recreate instead';
  end if;

  if v_row.current_status <> 'delivered' then
    raise exception 'can only revert from delivered (current: %)', v_row.current_status
      using errcode = '22023',
            hint   = 'use change_delivery_status for non-delivered transitions';
  end if;

  insert into public.delivery_status_history (
    delivery_id, from_status, to_status,
    changed_by_user_id, client_uuid, effective_at, reason
  ) values (
    p_delivery_id, 'delivered', 'pending',
    v_actor, v_history_key, now(),
    'revert_delivered: ' || btrim(p_reason)
  );

  -- [Phase 2] Release the delivered stock back to the agent as an append-only
  -- ledger row (current_stock no longer derives this). Read the per-line
  -- delivered quantities BEFORE they are nulled below.
  insert into public.stock_adjustments
    (agent_id, product_catalog_id, quantity_delta, reason, notes,
     client_uuid, created_by_user_id, delivery_id)
  select v_row.assigned_agent_id, di.product_catalog_id, di.quantity_delivered, 'delivery_returned',
         'revert_delivered: ' || btrim(p_reason),
         v_history_key || ':returned:' || di.product_catalog_id::text, v_actor, p_delivery_id
    from public.delivery_items di
   where di.delivery_id = p_delivery_id
     and coalesce(di.quantity_delivered, 0) > 0;

  update public.deliveries
     set current_status        = 'pending',
         quantity_delivered    = null,
         paid                  = null,
         payment_method        = null,
         cash_pos_fee_snapshot = null,
         updated_at            = now()
   where id = p_delivery_id;

  update public.delivery_items
     set quantity_delivered = null
   where delivery_id = p_delivery_id;

  perform public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := jsonb_build_object(
      'current_status',        v_row.current_status,
      'quantity_delivered',    v_row.quantity_delivered,
      'paid',                  v_row.paid,
      'payment_method',        v_row.payment_method,
      'cash_pos_fee_snapshot', v_row.cash_pos_fee_snapshot
    ),
    p_new         := jsonb_build_object(
      'current_status',        'pending',
      'quantity_delivered',    null,
      'paid',                  null,
      'payment_method',        null,
      'cash_pos_fee_snapshot', null
    ),
    p_reason      := 'revert_delivered: ' || btrim(p_reason)
  );
end;
$$;


--
-- Name: FUNCTION revert_delivery_to_pending(p_delivery_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.revert_delivery_to_pending(p_delivery_id uuid, p_reason text) IS 'Admin + dispatcher: revert a wrongly-delivered row back to pending, nulling the delivered-only columns (quantity_delivered, paid, payment_method, cash_pos_fee_snapshot). Reason required; audit-logged with reason ''revert_delivered: <text>''. Stock auto-recovers via the current_stock view. Cascade-cancelled siblings stay cancelled — caller reviews separately. Rep is excluded (manager-level call).';


--
-- Name: revert_location_change(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.revert_location_change(p_change_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_c     public.delivery_location_changes%rowtype;
  v_d     public.deliveries%rowtype;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array(select delivery_id from public.delivery_location_changes where id=p_change_id),'{}'::uuid[]);
  if not public.is_manager() then
    raise exception 'permission denied: reverting a zone change requires admin or dispatcher'
      using errcode = '42501';
  end if;
  if p_reason is null or btrim(p_reason) = '' then
    raise exception 'reason required to revert' using errcode = '22023';
  end if;

  select * into v_c from public.delivery_location_changes where id = p_change_id for update;
  if not found then raise exception 'change not found: %', p_change_id using errcode = 'P0002'; end if;
  if v_c.state not in ('applied', 'approved') then
    raise exception 'only an applied or approved change can be reverted (state=%)', v_c.state
      using errcode = '22023';
  end if;
  if v_c.from_location_id is null then
    raise exception 'cannot revert to an unset zone on this order; use admin location correction instead'
      using errcode = '22023';
  end if;

  select * into v_d from public.deliveries where id = v_c.delivery_id for update;
  if not found then raise exception 'delivery not found' using errcode = 'P0002'; end if;

  -- Don't clobber a newer change: only revert when the delivery is STILL on the
  -- zone this change applied. If a later change/correction moved it on, reverting
  -- to from_* would silently overwrite that newer state.
  if v_d.location_id is distinct from v_c.to_location_id then
    raise exception
      'this delivery has since moved to a different zone; revert no longer applies'
      using errcode = '22023';
  end if;

  -- True undo: write the stored from_* values exactly (no recompute), so it
  -- restores the original even if the rate card changed meanwhile.
  update public.deliveries
     set location_id            = v_c.from_location_id,
         charged_snapshot       = v_c.from_charged,
         agent_payment_snapshot = v_c.from_agent_payment,
         agent_payment_base_snapshot = v_c.from_agent_payment,
         agent_payment_base_captured_at = clock_timestamp(),
         updated_at             = now()
   where id = v_c.delivery_id;

  perform public.write_audit(
    p_entity_type := 'delivery',
    p_entity_id   := v_c.delivery_id,
    p_old := jsonb_build_object(
      'location_id',            v_d.location_id,
      'charged_snapshot',       v_d.charged_snapshot,
      'agent_payment_snapshot', v_d.agent_payment_snapshot
    ),
    p_new := jsonb_build_object(
      'location_id',            v_c.from_location_id,
      'charged_snapshot',       v_c.from_charged,
      'agent_payment_snapshot', v_c.from_agent_payment
    ),
    p_reason   := 'agent_location_change:reverted -- ' || btrim(p_reason),
    p_actor_id := v_actor
  );

  update public.delivery_location_changes
     set state = 'reverted', decided_by_user_id = v_actor, decided_at = now()
   where id = p_change_id;

  perform public.send_edge_notification(jsonb_build_object(
    'audience', 'user', 'user_id', v_c.requested_by_agent_id::text,
    'title', 'Zone change reverted',
    'body',  'A manager reverted your delivery zone change.',
    'data',  jsonb_build_object('delivery_id', v_c.delivery_id)));
end;
$$;


--
-- Name: review_same_customer_completion_day(uuid, uuid, bigint, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.review_same_customer_completion_day(p_request_id uuid, p_delivery_id uuid, p_expected_revision bigint, p_accepted_day date, p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  d public.deliveries%rowtype;
  e public.same_customer_earnings%rowtype;
  v_previous public.same_customer_completion_reviews%rowtype;
  v_lock text; v_group uuid; v_before jsonb; v_after jsonb;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if not public.is_admin() then raise exception 'admin role required for completion-date review' using errcode='42501'; end if;
  if p_request_id is null or p_delivery_id is null or p_expected_revision is null or p_accepted_day is null
     or nullif(btrim(p_reason),'') is null or length(btrim(p_reason))>2000 then
    raise exception 'request, delivery, revision, completion day and reason required' using errcode='22023';
  end if;
  -- Same-request serialization makes retries safe even before their first commit.
  perform pg_advisory_xact_lock(hashtextextended('same-customer-day-review:'||p_request_id::text,0));
  select * into v_previous from public.same_customer_completion_reviews where request_id=p_request_id;
  if found then
    if (v_previous.actor_id,v_previous.delivery_id,v_previous.expected_revision,v_previous.accepted_day,v_previous.reason)
       is distinct from (auth.uid(),p_delivery_id,p_expected_revision,p_accepted_day,btrim(p_reason)) then
      raise exception 'request id already used for a different correction' using errcode='22023';
    end if;
    return v_previous.after_value;
  end if;
  if not isfinite(p_accepted_day) or p_accepted_day>(clock_timestamp() at time zone 'Africa/Lagos')::date then
    raise exception 'completion day must be a finite Lagos date no later than today' using errcode='22023';
  end if;
  -- Shadow-only lock order matches status and identity correction. Final-pay
  -- integration must acquire the shared outer settlement locks before this row.
  select * into d from public.deliveries where id=p_delivery_id for update;
  if not found then raise exception 'delivery not found' using errcode='P0002'; end if;
  select * into e from public.same_customer_earnings where delivery_id=p_delivery_id;
  if not found or not e.active or d.current_status<>'delivered' or d.deleted_at is not null then
    raise exception 'an active successful earning is required' using errcode='22023';
  end if;
  for v_lock in select distinct k from unnest(array[
    public._same_customer_pay_lock_key(e.rider_id,e.customer_key,e.business_date),
    public._same_customer_pay_lock_key(e.rider_id,e.customer_key,p_accepted_day)
  ]) k where k is not null order by k loop
    perform pg_advisory_xact_lock(hashtextextended(v_lock,0));
  end loop;
  -- A different order's completion can change this earning while we wait.
  select * into e from public.same_customer_earnings where delivery_id=p_delivery_id for update;
  if e.revision<>p_expected_revision then
    raise exception 'earning changed; refresh before reviewing its completion date' using errcode='40001';
  end if;
  select id into v_group from public.same_customer_pay_groups
    where rider_id=e.rider_id and customer_key=e.customer_key and business_date=p_accepted_day and policy_version=e.policy_version;
  if exists (
    select 1 from public.same_customer_earnings x join public.settlements s
      on s.subject_type='agent' and s.subject_id=x.rider_id and s.period_date=x.accounting_date and s.voided_at is null
    where x.active and (x.delivery_id=e.delivery_id or x.group_id=e.group_id or x.group_id=v_group)
  ) then
    raise exception 'affected rider period is settled; resolve that settlement before changing the completion day' using errcode='22023';
  end if;
  v_before:=to_jsonb(e);
  if v_group is null then
    insert into public.same_customer_pay_groups(rider_id,customer_key,business_date,policy_version)
      values(e.rider_id,e.customer_key,p_accepted_day,e.policy_version) returning id into v_group;
  end if;
  update public.same_customer_earnings set business_date=p_accepted_day,group_id=v_group,date_review_reason=null,manual_event_review=manual_amount is not null and (manual_event_review or business_date is distinct from p_accepted_day),
    pay_state='pending',review_reason=null,expected_amount=null,multiplier=null,revision=revision+1,updated_at=clock_timestamp()
    where delivery_id=p_delivery_id;
  perform public._recalculate_customer_day_pay(e.group_id);
  if v_group is distinct from e.group_id then perform public._recalculate_customer_day_pay(v_group); end if;
  select to_jsonb(x) into v_after from public.same_customer_earnings x where delivery_id=p_delivery_id;
  insert into public.same_customer_completion_reviews(request_id,delivery_id,completion_event_id,expected_revision,accepted_day,reason,actor_id,before_value,after_value)
    values(p_request_id,p_delivery_id,e.completion_event_id,p_expected_revision,p_accepted_day,btrim(p_reason),auth.uid(),v_before,v_after);
  return v_after;
end $$;


--
-- Name: review_same_customer_manual_pay(uuid, uuid, bigint, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.review_same_customer_manual_pay(p_request_id uuid, p_group_id uuid, p_expected_revision bigint, p_reason text) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare g public.same_customer_pay_groups%rowtype; r public.same_customer_manual_reviews%rowtype;
  v_signature text; v_members jsonb; v_result jsonb;
begin
  if not public.is_admin() then raise exception 'admin role required for manual-pay review' using errcode='42501'; end if;
  if p_request_id is null or p_group_id is null or p_expected_revision is null or nullif(btrim(p_reason),'') is null or length(btrim(p_reason))>2000 then
    raise exception 'request, group, revision and reason required' using errcode='22023'; end if;
  select * into g from public.same_customer_pay_groups where id=p_group_id;
  if not found then raise exception 'pay group not found' using errcode='P0002'; end if;
  perform public._same_customer_lock_orders(array(select delivery_id from public.same_customer_earnings where group_id=p_group_id and active),array[g.rider_id]);
  perform pg_advisory_xact_lock(hashtextextended('same-customer-manual-review:'||p_request_id::text,0));
  select * into r from public.same_customer_manual_reviews where request_id=p_request_id;
  if found then
    if (r.actor_id,r.group_id,r.expected_revision,r.reason) is distinct from (auth.uid(),p_group_id,p_expected_revision,btrim(p_reason)) then
      raise exception 'request id already used for a different review' using errcode='22023'; end if;
    return r.result;
  end if;
  perform pg_advisory_xact_lock(hashtextextended(public._same_customer_pay_lock_key(g.rider_id,g.customer_key,g.business_date),0));
  select * into strict g from public.same_customer_pay_groups where id=p_group_id for update;
  if g.revision<>p_expected_revision then raise exception 'pay group changed; refresh before review' using errcode='40001'; end if;
  if g.state<>'manual_review' then raise exception 'this group does not have a pending manual exception' using errcode='22023'; end if;
  if exists(select 1 from public.same_customer_earnings e join public.settlements s
    on s.subject_type='agent' and s.subject_id=e.rider_id and s.period_date=e.accounting_date and s.voided_at is null
    where e.group_id=p_group_id and e.active) then
    raise exception 'affected rider period is settled; resolve settlement before manual-pay review' using errcode='22023'; end if;
  v_signature:=public._same_customer_manual_signature(p_group_id);
  select jsonb_agg(to_jsonb(e) order by e.delivery_id) into v_members from public.same_customer_earnings e where group_id=p_group_id and active;
  update public.same_customer_pay_groups set manual_review_signature=v_signature where id=p_group_id;
  perform public._recalculate_customer_day_pay(p_group_id);
  select jsonb_build_object('group_id',p_group_id,'revision',revision,'state',state,
    'expected_total',(select sum(expected_amount) from public.same_customer_earnings where group_id=p_group_id and active))
    into v_result from public.same_customer_pay_groups where id=p_group_id;
  insert into public.same_customer_manual_reviews(request_id,group_id,expected_revision,signature,reason,actor_id,reviewed_members,result)
    values(p_request_id,p_group_id,p_expected_revision,v_signature,btrim(p_reason),auth.uid(),v_members,v_result);
  return v_result;
end $$;


--
-- Name: rls_auto_enable(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rls_auto_enable() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


--
-- Name: rollover_delivery(text, uuid, date, text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.rollover_delivery(p_client_uuid text, p_delivery_id uuid, p_new_scheduled_date date DEFAULT NULL::date, p_reason text DEFAULT 'eod_rollover'::text, p_notify boolean DEFAULT true) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  -- Carry cap: how many times a soft-fail / never-attempted order may roll
  -- before it closes out to unserious. 1 = original day + exactly ONE follow-up
  -- day, then stop. (Lowered from 2 on 2026-06-20 — Reda follows up one day, not
  -- two days in a row.) Single source of truth: the comparison AND the reason
  -- string below both derive from this constant so they can never drift.
  v_carry_cap constant int := 1;
  v_actor uuid := auth.uid();
  v_old   public.deliveries%rowtype;
  v_new_id uuid;
  v_new_date date;
  v_rate_charged numeric;
  v_rate_agent_payment numeric;
  v_charged numeric;
  v_agent_payment numeric;
  v_existing_new uuid;
  v_is_strike boolean;
  v_category   text;
  v_cap_applies boolean;
  v_new_rollover_count int;
  v_rolled_from_status text;
  v_rolled_from_date   date;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);
  if not public.is_admin_or_dispatcher() then
    raise exception 'rollover requires admin or dispatcher role'
      using errcode = '42501';
  end if;

  if p_client_uuid is null or btrim(p_client_uuid) = '' then
    raise exception 'client_uuid required for idempotency' using errcode = '22023';
  end if;

  select id into v_existing_new
  from public.deliveries
  where parent_delivery_id = p_delivery_id
    and created_via = 'rollover'
  limit 1;
  if v_existing_new is not null then
    return v_existing_new;
  end if;

  select * into v_old from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;

  if v_old.deleted_at is not null then
    raise exception 'cannot roll a deleted delivery' using errcode = '22023';
  end if;

  if exists (
    select 1 from public.delivery_status_defs
    where status = v_old.current_status and category = 'terminal'
  ) then
    raise exception 'delivery already terminal (status=%) — nothing to roll', v_old.current_status
      using errcode = '22023';
  end if;

  -- Waybills/pickups are money-only records (no product, phone, or address) and
  -- are terminal by construction. They must never roll: the forward INSERT below
  -- defaults order_type to 'delivery' and would trip deliveries_delivery_requires_fields.
  -- run_eod_rollover already filters these out; this is the lowest-level backstop
  -- for any direct/manual call.
  if v_old.order_type is distinct from 'delivery' then
    raise exception 'only deliveries can be rolled (order_type=%) — waybills never roll', v_old.order_type
      using errcode = '22023';
  end if;

  v_is_strike := v_old.current_status in (
    'not_answering','not_around','not_available',
    'not_connecting','number_busy','switched_off'
  );

  -- no_product is a soft_failure but is Reda's transient supply gap, not the
  -- customer's fault — exclude it from the carry-cap so it rolls forward
  -- indefinitely (rollover_count frozen) until it's delivered or explicitly
  -- cancelled, instead of auto-closing to 'unserious' (Uzo, 2026-06-22).
  select sd.category in ('initial','soft_failure') and v_old.current_status <> 'no_product'
    into v_cap_applies
    from public.delivery_status_defs sd
   where sd.status = v_old.current_status;

  if v_cap_applies and v_old.rollover_count >= v_carry_cap then
    perform public.change_delivery_status(
      p_client_uuid     := p_client_uuid || ':cap-unserious',
      p_delivery_id     := v_old.id,
      p_to_status       := 'unserious',
      p_reason          := 'carry-cap reached (' || v_carry_cap || ' rollover)',
      p_notes           := null,
      p_paid            := null,
      p_quantity_delivered := null,
      p_payment_method  := null,
      p_effective_at    := now()
    );
    if p_notify then
      perform public._notify_admins_carry_cap(v_old.id);
    end if;
    return null;
  end if;

  v_new_date := public._ensure_workday(
    coalesce(p_new_scheduled_date, (v_old.scheduled_date + interval '1 day')::date)
  );

  if v_old.location_id is not null then
    -- Re-price the new day through the same client-aware source of truth used by
    -- create/edit/location-correction. Calling current_rate_for_location here
    -- used to bypass clients.max_charge_per_delivery on rollover children.
    -- The child is intentionally unassigned, so pass NULL for the agent: any
    -- future rider bonus is applied when an agent/location edit re-snapshots it.
    select er.charged, er.agent_payment
      into v_rate_charged, v_rate_agent_payment
      from public.effective_rate(v_old.location_id, v_old.client_id, null) er;
  end if;
  v_charged       := coalesce(v_rate_charged,       v_old.charged_snapshot);
  v_agent_payment := coalesce(v_rate_agent_payment, public._same_customer_normal_fee(v_old));

  v_new_rollover_count := case when v_cap_applies then v_old.rollover_count + 1
                               else v_old.rollover_count end;

  -- Carry the last MEANINGFUL status forward: the parent's status if it was
  -- attempted (not 'pending'), else inherit whatever the parent was already
  -- carrying. 'pending' means "never attempted that day", so it isn't worth
  -- surfacing and shouldn't clobber an earlier real attempt.
  if v_old.current_status <> 'pending' then
    v_rolled_from_status := v_old.current_status;
    v_rolled_from_date   := v_old.scheduled_date;
  else
    v_rolled_from_status := v_old.rolled_from_status;
    v_rolled_from_date   := v_old.rolled_from_date;
  end if;

  v_new_id := gen_random_uuid();
  insert into public.deliveries (
    id, client_id, product_catalog_id, customer_name, customer_phone, customer_phone_alt,
    customer_price, raw_address, location_id, assigned_agent_id,
    quantity_ordered, scheduled_date, created_via, parent_delivery_id,
    charged_snapshot, agent_payment_snapshot, current_status,
    created_by_user_id, bot_raw_message, text_fingerprint, rollover_count,
    rolled_from_status, rolled_from_date, delivery_instructions, client_rep, same_customer_key_override, same_customer_match_mode
  )
  values (
    v_new_id, v_old.client_id, v_old.product_catalog_id, v_old.customer_name, v_old.customer_phone, v_old.customer_phone_alt,
    v_old.customer_price, v_old.raw_address, v_old.location_id,
    null,                                          -- assigned_agent_id intentionally NULL
    v_old.quantity_ordered, v_new_date, 'rollover', v_old.id,
    v_charged, v_agent_payment, 'pending',
    v_actor, v_old.bot_raw_message, v_old.text_fingerprint, v_new_rollover_count,
    v_rolled_from_status, v_rolled_from_date, v_old.delivery_instructions, v_old.client_rep, v_old.same_customer_key_override, v_old.same_customer_match_mode
  );

  insert into public.delivery_status_history
    (delivery_id, from_status, to_status, changed_by_user_id, client_uuid, reason, effective_at)
  values
    (v_new_id, null, 'pending', v_actor, p_client_uuid, p_reason, now());

  perform public.change_delivery_status(
    p_client_uuid     := p_client_uuid || ':parent',
    p_delivery_id     := v_old.id,
    p_to_status       := 'rolled_over',
    p_reason          := p_reason,
    p_notes           := null,
    p_paid            := null,
    p_quantity_delivered := null,
    p_payment_method  := null,
    p_effective_at    := now()
  );

  perform public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := v_new_id,
    p_old         := jsonb_build_object(
      'parent_delivery_id', v_old.id,
      'old_scheduled_date', v_old.scheduled_date,
      'old_status', v_old.current_status,
      'old_charged_snapshot', v_old.charged_snapshot,
      'old_agent_payment_snapshot', v_old.agent_payment_snapshot,
      'old_rollover_count', v_old.rollover_count,
      'old_assigned_agent_id', v_old.assigned_agent_id
    ),
    p_new         := jsonb_build_object(
      'new_delivery_id', v_new_id,
      'new_scheduled_date', v_new_date,
      'charged_snapshot', v_charged,
      'agent_payment_snapshot', v_agent_payment,
      'new_rollover_count', v_new_rollover_count,
      'is_strike_rollover', v_is_strike,
      'new_assigned_agent_id', null,
      'normal_agent_payment', v_agent_payment,
      'inherited_customer_key_override', v_old.same_customer_key_override,
      'inherited_customer_match_mode', v_old.same_customer_match_mode,
      'rolled_from_status', v_rolled_from_status,
      'rolled_from_date', v_rolled_from_date
    ),
    p_reason      := p_reason
  );

  return v_new_id;
end;
$$;


--
-- Name: run_eod_rollover(date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_eod_rollover(p_for_date date DEFAULT CURRENT_DATE, p_reason text DEFAULT 'eod_rollover'::text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    SET statement_timeout TO '120s'
    AS $$
declare
  v_system_id constant uuid := '2d8d5895-d2a8-4900-b15e-7662b176a805';
  v_capped_ids_limit constant int := 100;
  v_row record;
  v_count integer := 0;
  v_same_agent_cancels       integer := 0;
  v_cross_agent_cancels      integer := 0;
  v_cap_hits                 integer := 0;
  v_capped_overflow          integer := 0;
  v_policy_cancels           integer := 0;
  v_sibling_resolved_cancels integer := 0;
  v_followup_closes          integer := 0;   -- follow_up closed to deferred_to_client
  v_disinterest_closes       integer := 0;   -- not_around/not_available closed to unserious
  v_capped_ids               uuid[]  := array[]::uuid[];
  v_new_child_id             uuid;
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'eod rollover requires admin or dispatcher role' using errcode = '42501';
  end if;

  perform set_config('reda.in_eod_rollover', 'true', true);

  -- The classifier is the single source of truth for what happens to each row.
  -- This loop only executes its verdicts (same side effects as before, one per
  -- action) — no rule lives here anymore.
  for v_row in
    select * from public._eod_classify(p_for_date)
  loop
    if v_row.action = 'sibling_resolved' then
      insert into public.delivery_status_history
        (delivery_id, from_status, to_status, changed_by_user_id, client_uuid, reason, effective_at)
      values (v_row.delivery_id, v_row.current_status, 'cancelled', v_system_id,
         'rollover-sibling-resolved:' || p_for_date::text || ':' || v_row.delivery_id::text,
         'Another agent already handled this order ('
           || coalesce(v_row.resolved_sibling_label, v_row.resolved_sibling_status)
           || '). Closed as duplicate.', now());
      update public.deliveries set current_status = 'cancelled', updated_at = now() where id = v_row.delivery_id;
      v_sibling_resolved_cancels := v_sibling_resolved_cancels + 1;

    elsif v_row.action = 'dedup_same_agent' then
      insert into public.delivery_status_history
        (delivery_id, from_status, to_status, changed_by_user_id, client_uuid, reason, effective_at)
      values (v_row.delivery_id, v_row.current_status, 'cancelled', v_system_id,
         'rollover-dedup-same-agent:' || p_for_date::text || ':' || v_row.delivery_id::text,
         'duplicate not completed, same-agent deduped on rollover', now());
      update public.deliveries set current_status = 'cancelled', updated_at = now() where id = v_row.delivery_id;
      v_same_agent_cancels := v_same_agent_cancels + 1;

    elsif v_row.action = 'dedup_cross_agent' then
      insert into public.delivery_status_history
        (delivery_id, from_status, to_status, changed_by_user_id, client_uuid, reason, effective_at)
      values (v_row.delivery_id, v_row.current_status, 'cancelled', v_system_id,
         'rollover-dedup-cross-agent:' || p_for_date::text || ':' || v_row.delivery_id::text,
         case when v_row.group_max_sort > 1 then 'race lost, deduped on rollover'
              else 'duplicate not completed, cross-agent deduped on rollover' end, now());
      update public.deliveries set current_status = 'cancelled', updated_at = now() where id = v_row.delivery_id;
      v_cross_agent_cancels := v_cross_agent_cancels + 1;

    -- not_around / not_available are disinterest signals (customer not interested,
    -- no money, or playing with the order form) — closed to unserious, not rolled.
    elsif v_row.action = 'close_disinterest' then
      perform public.change_delivery_status(
        p_client_uuid => 'eod-disinterest-close:' || v_row.delivery_id::text || ':' || p_for_date::text,
        p_delivery_id => v_row.delivery_id, p_to_status => 'unserious',
        p_reason => 'eod_disinterest_close:not_interested');
      v_disinterest_closes := v_disinterest_closes + 1;

    elsif v_row.action = 'close_policy' then
      perform public.change_delivery_status(
        p_client_uuid => 'eod-auto-cancel:' || v_row.delivery_id::text || ':' || p_for_date::text,
        p_delivery_id => v_row.delivery_id, p_to_status => 'failed_delivery',
        p_reason => 'eod_auto_cancel:client_policy');
      -- A postponed row swept by client policy closes UNASSIGNED (mirrors the
      -- release path's hand-off; history/audit keep who held it).
      if v_row.current_status = 'postponed' then
        update public.deliveries
           set assigned_agent_id = null, updated_at = now()
         where id = v_row.delivery_id;
      end if;
      v_policy_cancels := v_policy_cancels + 1;

    -- follow_up is handed back to the client (deferred_to_client), never rolled.
    elsif v_row.action = 'close_followup' then
      perform public.change_delivery_status(
        p_client_uuid => 'eod-followup-close:' || v_row.delivery_id::text || ':' || p_for_date::text,
        p_delivery_id => v_row.delivery_id, p_to_status => 'deferred_to_client',
        p_reason => 'eod_followup_close:excluded_from_rollover');
      v_followup_closes := v_followup_closes + 1;

    else
      -- 'roll' or 'cap_unserious': rollover_delivery rolls the row forward, or
      -- (when the carry cap is reached) closes it to unserious and returns null.
      v_new_child_id := public.rollover_delivery(
        p_client_uuid := 'eod:' || p_for_date::text || ':' || v_row.delivery_id::text,
        p_delivery_id := v_row.delivery_id,
        p_new_scheduled_date := (p_for_date + interval '1 day')::date,
        p_reason := p_reason, p_notify := false);

      if v_new_child_id is null then
        v_cap_hits := v_cap_hits + 1;
        if cardinality(v_capped_ids) < v_capped_ids_limit then
          v_capped_ids := array_append(v_capped_ids, v_row.delivery_id);
        else
          v_capped_overflow := v_capped_overflow + 1;
        end if;
      else
        v_count := v_count + 1;
      end if;
    end if;
  end loop;

  perform public._notify_admins_eod_summary(
    p_for_date := p_for_date, p_cap_hit_count := v_cap_hits,
    p_same_agent_count := v_same_agent_cancels, p_race_lost_count := v_cross_agent_cancels,
    p_capped_ids := v_capped_ids, p_policy_cancel_count := v_policy_cancels,
    p_sibling_resolved_count := v_sibling_resolved_cancels);

  if v_sibling_resolved_cancels > 0 then raise notice 'rollover: % cancelled because a sibling already settled the order', v_sibling_resolved_cancels; end if;
  if v_same_agent_cancels > 0 then raise notice 'rollover: % same-agent duplicates cancelled', v_same_agent_cancels; end if;
  if v_cross_agent_cancels > 0 then raise notice 'rollover: % cross-agent duplicates cancelled (race-lost or all-pending collapse)', v_cross_agent_cancels; end if;
  if v_cap_hits > 0 then raise notice 'rollover: % deliveries hit the carry cap and were marked unserious (% truncated)', v_cap_hits, v_capped_overflow; end if;
  if v_policy_cancels > 0 then raise notice 'rollover: % deliveries auto-cancelled by client policy (failed_delivery)', v_policy_cancels; end if;
  if v_followup_closes > 0 then raise notice 'rollover: % follow_up deliveries closed out to deferred_to_client (excluded from rollover)', v_followup_closes; end if;
  if v_disinterest_closes > 0 then raise notice 'rollover: % not_around/not_available deliveries closed to unserious (disinterest, excluded from rollover)', v_disinterest_closes; end if;

  return v_count;
end;
$$;


--
-- Name: FUNCTION run_eod_rollover(p_for_date date, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.run_eod_rollover(p_for_date date, p_reason text) IS 'Rolls every non-terminal delivery for p_for_date forward. Smart dedup: same-agent dupes collapse to one; cross-agent dupes preserved when all still pending (race-assign), collapsed when any has progressed (race winner takes it). 2-day carry cap enforced by rollover_delivery.';


--
-- Name: run_eod_rollover_all_stuck(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.run_eod_rollover_all_stuck(p_reason text DEFAULT 'auto_eod_cron'::text) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    SET statement_timeout TO '120s'
    AS $$
declare
  v_total       integer := 0;
  v_count       integer;
  v_date        date;
  v_released    integer := 0;
  v_admin       record;
  v_failed      text[] := array[]::text[];
  v_last_error  text;
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'requires admin or dispatcher role' using errcode = '42501';
  end if;

  -- 1. Release postponed orders due tomorrow (and any overdue from a missed
  --    night — release_postponed_due releases `scheduled_date <= arg`). Wrapped
  --    so a release failure can't block the rollover, and vice-versa.
  begin
    v_released := public.release_postponed_due(((now() at time zone 'Africa/Lagos')::date) + 1);
  exception when others then
    v_released := 0;
    v_failed   := array_append(v_failed, 'postpone-release: ' || sqlerrm);
    raise notice 'eod: postpone-release failed: %', sqlerrm;
  end;

  -- Observability: a silent nightly state-change that pulls orders out of agents'
  -- hands deserves a trace. Tell admins how many were released (only when > 0),
  -- using the same per-admin server-side push the rollover summary uses.
  if v_released > 0 then
    for v_admin in
      select id from public.users where role = 'admin' and is_active = true
    loop
      perform public.send_edge_notification(jsonb_build_object(
        'audience', 'user',
        'user_id',  v_admin.id::text,
        'title',    'Postponed orders released',
        'body',     v_released || ' postponed order(s) came due and moved to Unassigned — assign them for today.',
        'data',     jsonb_build_object('route', 'deliveries')
      ));
    end loop;
  end if;

  -- 2. Roll each stuck date independently. One bad date is logged and skipped,
  --    not fatal — it stays non-terminal and is retried on the next sweep.
  for v_date in
    select distinct d.scheduled_date
      from public.deliveries d
      join public.delivery_status_defs s on s.status = d.current_status
     where d.scheduled_date <= current_date
       and d.deleted_at is null
       and s.category <> 'terminal'
     order by d.scheduled_date
  loop
    begin
      v_count := public.run_eod_rollover(v_date, p_reason);
      v_total := v_total + v_count;
    exception when others then
      v_last_error := sqlerrm;
      v_failed     := array_append(v_failed, v_date::text || ': ' || sqlerrm);
      raise notice 'eod: rollover for % failed: %', v_date, sqlerrm;
    end;
  end loop;

  -- 3. Surface any failures so a partial EOD never goes unnoticed.
  if cardinality(v_failed) > 0 then
    for v_admin in
      select id from public.users where role = 'admin' and is_active = true
    loop
      perform public.send_edge_notification(jsonb_build_object(
        'audience', 'user',
        'user_id',  v_admin.id::text,
        'title',    'End of day completed with errors',
        'body',     cardinality(v_failed) || ' EOD step(s) failed and were skipped: '
                    || left(array_to_string(v_failed, ' | '), 300)
                    || '. Review the EOD screen.',
        'data',     jsonb_build_object('route', 'eod')
      ));
    end loop;
  end if;

  return v_total;
end;
$$;


--
-- Name: same_customer_badges(uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.same_customer_badges(p_delivery_ids uuid[]) RETURNS jsonb
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$ declare v_result jsonb;
begin
  if not public.is_manager() then raise exception 'admin or dispatcher role required' using errcode='42501'; end if;
  if cardinality(p_delivery_ids)>500 then raise exception 'maximum 500 deliveries' using errcode='22023'; end if;
  if not coalesce((select enabled from public.feature_flags where key='same_customer_discovery'),false) then return '[]'::jsonb; end if;
  with days as (select distinct scheduled_date from public.deliveries where id=any(p_delivery_ids)),
  groups as (select d.scheduled_date,g.* from days d cross join lateral public._same_customer_day_groups(d.scheduled_date) g),
  badges as (
    select member_id as delivery_id,
      (array_agg(g.group_id order by (g.match_kind='alternate'),g.group_id))[1] as group_id,g.scheduled_date as day,
      (array_agg(cardinality(g.delivery_ids) order by (g.match_kind='alternate'),g.group_id))[1] as order_count,
      (count(*)-1)::integer as additional_groups,
      bool_and(g.match_kind='alternate') as possible_only
    from groups g cross join lateral unnest(g.delivery_ids) member_id
    where member_id=any(p_delivery_ids) group by member_id,g.scheduled_date
  ) select coalesce(jsonb_agg(to_jsonb(b)),'[]'::jsonb) into v_result from badges b;
  return v_result;
end $$;


--
-- Name: send_edge_notification(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.send_edge_notification(p_body jsonb) RETURNS void LANGUAGE plpgsql AS $$ begin perform net.http_post(url:='http://isolated.invalid',headers:='{}',body:=p_body); end $$;

--
-- Name: set_agent_locations(uuid, uuid[], uuid[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_agent_locations(p_agent_id uuid, p_preferred_ids uuid[], p_avoided_ids uuid[]) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
begin
  if not public.is_admin() then
    raise exception 'admin only' using errcode = '42501';
  end if;

  if p_preferred_ids is not null and p_avoided_ids is not null
     and exists (
       select 1 from unnest(p_preferred_ids) p
        where p = any(p_avoided_ids)
     )
  then
    raise exception 'location cannot be both preferred and avoided'
      using errcode = '22023';
  end if;

  delete from public.agent_locations where agent_id = p_agent_id;

  if p_preferred_ids is not null and array_length(p_preferred_ids, 1) > 0 then
    insert into public.agent_locations (agent_id, location_id, kind, created_by_user_id)
    select p_agent_id, unnest(p_preferred_ids), 'preferred', v_actor
    on conflict do nothing;
  end if;

  if p_avoided_ids is not null and array_length(p_avoided_ids, 1) > 0 then
    insert into public.agent_locations (agent_id, location_id, kind, created_by_user_id)
    select p_agent_id, unnest(p_avoided_ids), 'avoid', v_actor
    on conflict do nothing;
  end if;
end;
$$;


--
-- Name: set_client_balance_opening(text, uuid, date, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_client_balance_opening(p_request_uuid text, p_client_id uuid, p_effective_date date, p_opening_balance numeric, p_note text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_existing_request uuid;
  v_old jsonb;
begin
  if not public.is_admin() then
    raise exception 'only admin can configure client balances' using errcode = '42501';
  end if;
  if nullif(btrim(p_request_uuid), '') is null then
    raise exception 'request uuid required' using errcode = '22023';
  end if;
  if p_effective_date is null or p_effective_date > (now() at time zone 'Africa/Lagos')::date then
    raise exception 'effective date must be today or earlier' using errcode = '22023';
  end if;
  if p_opening_balance is null then
    raise exception 'opening balance required' using errcode = '22023';
  end if;
  if not exists (select 1 from public.clients c where c.id = p_client_id) then
    raise exception 'client not found' using errcode = 'P0002';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(p_client_id::text, 0));

  select o.client_id into v_existing_request
    from public.client_balance_openings o
   where o.setup_request_uuid = p_request_uuid;
  if v_existing_request is not null then
    if v_existing_request <> p_client_id then
      raise exception 'request uuid already belongs to another client' using errcode = '23505';
    end if;
    return v_existing_request;
  end if;

  if exists (
    select 1 from public.client_payouts p
     where p.client_id = p_client_id and p.voided_at is null
  ) or exists (
    select 1 from public.client_payments p
     where p.client_id = p_client_id and p.voided_at is null
  ) then
    raise exception 'opening balance is locked after the first ledger payout or payment'
      using errcode = '22023',
            hint = 'void the payout or payment first if the cutover was incorrect';
  end if;

  select to_jsonb(o) into v_old
    from public.client_balance_openings o where o.client_id = p_client_id;

  insert into public.client_balance_openings(
    client_id, effective_date, opening_balance, note,
    setup_request_uuid, set_by, updated_at
  ) values (
    p_client_id, p_effective_date, p_opening_balance, nullif(btrim(p_note), ''),
    p_request_uuid, v_actor, now()
  )
  on conflict (client_id) do update set
    effective_date = excluded.effective_date,
    opening_balance = excluded.opening_balance,
    note = excluded.note,
    setup_request_uuid = excluded.setup_request_uuid,
    set_by = excluded.set_by,
    updated_at = now();

  perform public.write_audit(
    'client_balance_opening', p_client_id, v_old,
    jsonb_build_object(
      'client_id', p_client_id,
      'effective_date', p_effective_date,
      'opening_balance', p_opening_balance,
      'note', nullif(btrim(p_note), '')
    ),
    case when v_old is null then 'create' else 'update' end
  );
  return p_client_id;
end;
$$;


--
-- Name: set_client_bank_details(uuid, text, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_client_bank_details(p_id uuid, p_bank_account_name text, p_bank_account_number text, p_bank_name text, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $_$
declare
  v_old       public.clients;
  v_acct_name text := nullif(trim(p_bank_account_name), '');
  v_acct_no   text := nullif(trim(p_bank_account_number), '');
  v_bank      text := nullif(trim(p_bank_name), '');
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  select * into v_old from public.clients where id = p_id;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;
  -- Bank NUBAN is 10 digits; fintech wallets (OPay, PalmPay, Moniepoint) use the
  -- 11-digit phone-based account. Allow both. Validate only when provided so the
  -- field stays optional; a bad number would silently fail the Moniepoint upload.
  if v_acct_no is not null and v_acct_no !~ '^[0-9]{10,11}$' then
    raise exception 'bank account number must be 10 or 11 digits' using errcode = '23514';
  end if;

  -- Sets (not coalesces) all three: the edit form always submits the full set
  -- pre-filled with current values, so clearing a field intentionally nulls it.
  update public.clients
     set bank_account_name   = v_acct_name,
         bank_account_number = v_acct_no,
         bank_name           = v_bank
   where id = p_id;

  perform public.write_audit(
    'client', p_id,
    jsonb_build_object(
      'bank_account_name',   v_old.bank_account_name,
      'bank_account_number', v_old.bank_account_number,
      'bank_name',           v_old.bank_name
    ),
    jsonb_build_object(
      'bank_account_name',   v_acct_name,
      'bank_account_number', v_acct_no,
      'bank_name',           v_bank
    ),
    p_reason
  );
end;
$_$;


--
-- Name: set_feature_flag(text, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_feature_flag(p_key text, p_enabled boolean) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if not is_admin() then
    raise exception 'only admins can change feature flags';
  end if;
  if not exists (select 1 from public.feature_flags where key = p_key) then
    raise exception 'unknown feature flag: %', p_key;
  end if;
  update public.feature_flags
     set enabled            = p_enabled,
         updated_at         = now(),
         updated_by_user_id = auth.uid()
   where key = p_key;
end$$;


--
-- Name: set_left_warehouse(boolean, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_left_warehouse(p_left boolean, p_agent_id uuid DEFAULT NULL::uuid) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor       uuid := auth.uid();
  v_role        text := public.current_user_role();
  v_target      uuid := coalesce(p_agent_id, v_actor);
  v_target_role text;
  v_date        date := (now() at time zone 'Africa/Lagos')::date;
  v_departed_at timestamptz;
begin
  if v_actor is null then
    raise exception 'not authenticated' using errcode = '42501';
  end if;

  select role into v_target_role from public.users where id = v_target;
  if v_target_role is null then
    raise exception 'agent not found' using errcode = 'P0002';
  end if;
  if v_target_role <> 'agent' then
    raise exception 'only agents can be marked as having left the warehouse' using errcode = '23514';
  end if;

  -- Caller must be the agent themselves, or an ops user acting on their behalf.
  if not (
    (v_actor = v_target and v_role = 'agent')
    or public.is_admin_or_dispatcher()
    or public.is_warehouse()
  ) then
    raise exception 'permission denied: cannot change this agent''s warehouse status'
      using errcode = '42501';
  end if;

  if p_left then
    insert into public.agent_departures (agent_id, depart_date, departed_at, departed_by)
    values (v_target, v_date, now(), v_actor)
    on conflict (agent_id, depart_date) do nothing;   -- keep the earliest departure time

    select departed_at into v_departed_at
      from public.agent_departures
     where agent_id = v_target and depart_date = v_date;

    perform public.write_audit(
      'agent_departure', v_target, null,
      jsonb_build_object('depart_date', v_date, 'departed_at', v_departed_at, 'departed_by', v_actor),
      'left the warehouse', v_actor
    );
    return jsonb_build_object('left', true, 'depart_date', v_date, 'departed_at', v_departed_at);
  else
    delete from public.agent_departures where agent_id = v_target and depart_date = v_date;

    perform public.write_audit(
      'agent_departure', v_target,
      jsonb_build_object('depart_date', v_date), null,
      'undo left the warehouse', v_actor
    );
    return jsonb_build_object('left', false, 'depart_date', v_date);
  end if;
end;
$$;


--
-- Name: set_my_expo_push_token(text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_my_expo_push_token(p_token text, p_platform text DEFAULT NULL::text, p_device_label text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_token text := nullif(trim(p_token), '');
begin
  if v_actor is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  if v_token is null then
    return;
  end if;

  insert into public.push_tokens (user_id, token, platform, device_label)
    values (v_actor, v_token, p_platform, p_device_label)
  on conflict (token) do update
     set user_id      = excluded.user_id,
         platform     = coalesce(excluded.platform, public.push_tokens.platform),
         device_label = coalesce(excluded.device_label, public.push_tokens.device_label),
         last_seen_at = now();
end;
$$;


--
-- Name: settle_period(text, uuid, date, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.settle_period(p_subject_type text, p_subject_id uuid, p_period_date date, p_note text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_expected numeric := 0;
  v_count integer := 0;
  v_by_entry jsonb;
  v_id uuid;
  v_existing uuid;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_financial_keys(array[case when p_subject_type='agent' then 'agent:'||p_subject_id::text when p_subject_type='client' then 'client:'||p_subject_id::text||':'||p_period_date::text end]);
  if not public.is_admin() then
    raise exception 'only admin can settle a period' using errcode = '42501';
  end if;
  if p_subject_type not in ('client','agent') then
    raise exception 'subject_type must be ''client'' or ''agent''' using errcode = '23514';
  end if;
  if p_period_date is null then
    raise exception 'period_date required' using errcode = '23514';
  end if;

  perform public._assert_same_customer_settlement_ready(p_subject_type,p_subject_id,p_period_date);
  select id into v_existing from public.settlements
   where subject_type = p_subject_type and subject_id = p_subject_id
     and period_date = p_period_date and voided_at is null;
  if v_existing is not null then
    raise exception 'this % is already settled for %', p_subject_type, p_period_date
      using errcode = '23505',
            hint = 'void the existing settlement first if you need to re-settle';
  end if;

  if p_subject_type = 'client' then
    with entries as (
      select d.id::text as entry_id,
             d.paid - coalesce(d.charged_snapshot,0) - coalesce(d.cash_pos_fee_snapshot,0) as amount,
             jsonb_build_object(
               'entry_type','delivery', 'delivery_id',d.id, 'paid',d.paid,
               'charged',d.charged_snapshot, 'cash_pos_fee',d.cash_pos_fee_snapshot,
               'remit',d.paid - coalesce(d.charged_snapshot,0) - coalesce(d.cash_pos_fee_snapshot,0)
             ) as snapshot
        from public.deliveries d
       where d.client_id = p_subject_id and d.current_status = 'delivered'
         and d.scheduled_date = p_period_date and d.deleted_at is null
      union all
      select a.id::text, (a.customer_paid - a.client_charge - a.cash_pos_fee),
             jsonb_build_object(
               'entry_type','replacement_attempt', 'attempt_id',a.id,
               'delivery_id',a.delivery_id, 'outcome',a.outcome,
               'customer_paid',a.customer_paid,'payment_method',a.payment_method,'payment_received_by',a.payment_received_by,
               'client_charge',a.client_charge, 'cash_pos_fee',a.cash_pos_fee,
               'remit',(a.customer_paid - a.client_charge - a.cash_pos_fee)
             )
        from public.replacement_attempts a
        join public.deliveries d on d.id = a.delivery_id
       where d.client_id = p_subject_id
         and (a.attempted_at at time zone 'Africa/Lagos')::date = p_period_date
    )
    select coalesce(sum(amount),0), count(*)::integer,
           coalesce(jsonb_agg(snapshot order by entry_id),'[]'::jsonb)
      into v_expected, v_count, v_by_entry from entries;
  else
    with entries as (
      select d.id::text as entry_id,
             d.paid - coalesce(d.agent_payment_snapshot,0) as amount,
             jsonb_build_object(
               'entry_type','delivery', 'delivery_id',d.id, 'paid',d.paid,
               'agent_payment',d.agent_payment_snapshot,
               'to_remit',d.paid - coalesce(d.agent_payment_snapshot,0)
             ) as snapshot
        from public.deliveries d
       where public._same_customer_final_rider(d) = p_subject_id and d.current_status = 'delivered'
         and public._same_customer_final_accounting_date(d) = p_period_date and d.deleted_at is null
      union all
      select a.id::text, ((case when a.payment_received_by='rider' then a.customer_paid else 0 end)-a.agent_payment),
             jsonb_build_object(
               'entry_type','replacement_attempt', 'attempt_id',a.id,
               'delivery_id',a.delivery_id, 'outcome',a.outcome,
               'customer_paid',a.customer_paid,'payment_method',a.payment_method,'payment_received_by',a.payment_received_by,'agent_payment',a.agent_payment, 'to_remit',((case when a.payment_received_by='rider' then a.customer_paid else 0 end)-a.agent_payment)
             )
        from public.replacement_attempts a
        join public.deliveries d on d.id = a.delivery_id
       where a.assigned_agent_id = p_subject_id
         and (a.attempted_at at time zone 'Africa/Lagos')::date = p_period_date
    )
    select coalesce(sum(amount),0), count(*)::integer,
           coalesce(jsonb_agg(snapshot order by entry_id),'[]'::jsonb)
      into v_expected, v_count, v_by_entry from entries;
  end if;

  if v_count = 0 then
    raise exception 'nothing to settle for this % on %', p_subject_type, p_period_date
      using errcode = '22023';
  end if;

  insert into public.settlements(
    subject_type, subject_id, period_date, settled_by, expected_amount,
    deliveries_count, snapshot, note
  ) values (
    p_subject_type, p_subject_id, p_period_date, v_actor, v_expected, v_count,
    jsonb_build_object(
      'expected_amount',v_expected, 'entries_count',v_count, 'by_delivery',v_by_entry
    ), nullif(btrim(p_note),'')
  ) returning id into v_id;

  perform public.write_audit(
    'settlement', v_id, null,
    jsonb_build_object(
      'subject_type',p_subject_type, 'subject_id',p_subject_id,
      'period_date',p_period_date, 'expected_amount',v_expected,
      'entries_count',v_count, 'note',nullif(btrim(p_note),'')
    ), 'settle'
  );
  return v_id;
end;
$$;


--
-- Name: stock_coverage_today(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_coverage_today() RETURNS TABLE(product_catalog_id uuid, product_name text, orders_open integer, qty_open integer, qty_committed integer, on_hand_total integer, on_hand_warehouse integer, my_on_hand integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_date date := (now() at time zone 'Africa/Lagos')::date;
  v_uid  uuid := auth.uid();
begin
  if not exists (select 1 from public.users u where u.id = v_uid and u.is_active) then
    raise exception 'stock coverage requires an active staff account' using errcode = '42501';
  end if;

  return query
  with demand as (
    -- One row per line item (Feature A), legacy single-product fallback
    -- otherwise. Null pids (shouldn't happen, but defensive) drop out in agg.
    select coalesce(di.product_catalog_id, d.product_catalog_id)     as pid,
           coalesce(di.quantity_ordered, d.quantity_ordered, 1)::int as qty,
           d.id                                                      as delivery_id,
           d.current_status in ('available', 'available_evening')    as committed
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
      left join public.delivery_items di on di.delivery_id = d.id
     where d.scheduled_date = v_date
       and d.deleted_at is null
       and d.order_type in ('delivery', 'replacement')
       and sd.category <> 'terminal'
  ),
  agg as (
    select dm.pid,
           count(distinct dm.delivery_id)::int                        as orders_open,
           sum(dm.qty)::int                                           as qty_open,
           coalesce(sum(dm.qty) filter (where dm.committed), 0)::int  as qty_committed
      from demand dm
     where dm.pid is not null
     group by dm.pid
  ),
  stock as (
    select cs.product_catalog_id as pid,
           coalesce(sum(cs.quantity_on_hand), 0)::int as on_hand_total,
           coalesce(sum(cs.quantity_on_hand) filter (where exists (
             select 1 from public.users u
              where u.id = cs.agent_id
                and u.role = 'warehouse'
                and u.warehouse_id is null
           )), 0)::int as on_hand_warehouse,
           coalesce(sum(cs.quantity_on_hand) filter (where cs.agent_id = v_uid), 0)::int as my_on_hand
      from public.current_stock cs
     group by cs.product_catalog_id
  )
  select a.pid,
         pc.product_name,
         a.orders_open,
         a.qty_open,
         a.qty_committed,
         coalesce(s.on_hand_total, 0),
         coalesce(s.on_hand_warehouse, 0),
         coalesce(s.my_on_hand, 0)
    from agg a
    join public.product_catalog pc on pc.id = a.pid
    left join stock s on s.pid = a.pid
   order by pc.product_name;
end;
$$;


--
-- Name: stock_movement_summary(uuid, date, date, uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_movement_summary(p_product_catalog_id uuid, p_from date, p_to date, p_holder_id uuid DEFAULT NULL::uuid, p_bucket text DEFAULT 'day'::text) RETURNS TABLE(period_start date, reason text, qty bigint, activity_qty bigint)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  -- Ops oversight surface — same audience as the movement history.
  if not (public.is_admin_or_dispatcher() or public.is_warehouse()) then
    raise exception 'permission denied' using errcode = '42501';
  end if;
  if p_bucket not in ('day', 'week') then
    raise exception 'bucket must be ''day'' or ''week''' using errcode = '22023';
  end if;
  if p_from is null or p_to is null then
    raise exception 'from and to dates are required' using errcode = '23514';
  end if;

  return query
  with scoped as (
    select
      case
        when p_bucket = 'week'
          then date_trunc('week', sa.created_at at time zone 'Africa/Lagos')::date
        else (sa.created_at at time zone 'Africa/Lagos')::date
      end as movement_period,
      sa.reason as movement_reason,
      sa.quantity_delta::bigint as net_qty,
      case
        when p_holder_id is null
         and sa.reason in ('warehouse_issue', 'warehouse_return', 'transfer')
         and sa.quantity_delta < 0
          then -sa.quantity_delta::bigint
        else 0::bigint
      end as internal_activity_qty
    from public.stock_adjustments sa
    where sa.product_catalog_id = p_product_catalog_id
      and (p_holder_id is null or sa.agent_id = p_holder_id)
      and sa.created_at >= (p_from::text || ' 00:00')::timestamp at time zone 'Africa/Lagos'
      and sa.created_at <  ((p_to + 1)::text || ' 00:00')::timestamp at time zone 'Africa/Lagos'
  )
  select
    s.movement_period,
    s.movement_reason,
    sum(s.net_qty)::bigint,
    sum(s.internal_activity_qty)::bigint
  from scoped s
  group by s.movement_period, s.movement_reason
  having sum(s.net_qty) <> 0 or sum(s.internal_activity_qty) <> 0
  order by s.movement_period desc, s.movement_reason;
end;
$$;


--
-- Name: stock_restock_signal(integer, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.stock_restock_signal(p_window_days integer DEFAULT 28, p_lead_days numeric DEFAULT 3) RETURNS TABLE(product_catalog_id uuid, product_name text, client_name text, warehouse_qty integer, units_out integer, selling_days integer, qty_open integer, rate_per_day numeric, days_cover numeric, tier text)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_today  date := (now() at time zone 'Africa/Lagos')::date;
  v_window int  := greatest(least(coalesce(p_window_days, 28), 90), 7);
  v_lead   numeric := greatest(coalesce(p_lead_days, 3), 0.5);
  v_start  date;
begin
  -- Ops + warehouse. Agents never restock, and unlike stock_coverage_today
  -- (which powers their "should I call?" badge) this carries vendor names, so
  -- it must not be agent-callable — that would leak past the anti-poaching RLS.
  if not (public.is_admin_or_dispatcher() or public.is_warehouse()) then
    raise exception 'permission denied: restock signal is for ops and warehouse'
      using errcode = '42501';
  end if;

  v_start := v_today - (v_window - 1);

  return query
  with selling_dates as (
    -- The divisor's calendar. Sunday is dropped: it has never traded.
    select d::date as dt
      from generate_series(v_start, v_today, interval '1 day') d
     where extract(dow from d) <> 0
  ),
  shipped as (
    select sa.product_catalog_id                 as pid,
           (-sum(sa.quantity_delta))::int        as units_out
      from public.stock_adjustments sa
     where sa.reason = 'delivered'
       and (sa.created_at at time zone 'Africa/Lagos')::date between v_start and v_today
     group by sa.product_catalog_id
    having -sum(sa.quantity_delta) > 0
  ),
  demand as (
    -- Mirrors stock_coverage_today's demand CTE exactly.
    select coalesce(di.product_catalog_id, d.product_catalog_id)              as pid,
           sum(coalesce(di.quantity_ordered, d.quantity_ordered, 1))::int     as qty_open
      from public.deliveries d
      join public.delivery_status_defs sd on sd.status = d.current_status
      left join public.delivery_items di on di.delivery_id = d.id
     where d.scheduled_date = v_today
       and d.deleted_at is null
       and d.order_type = 'delivery'
       and sd.category <> 'terminal'
       and coalesce(di.product_catalog_id, d.product_catalog_id) is not null
     group by 1
  ),
  base as (
    -- FULL OUTER: a product with orders waiting but nothing shipped all window
    -- must still appear. That is precisely the chronically-out case.
    select coalesce(s.pid, dm.pid)      as pid,
           coalesce(s.units_out, 0)     as units_out,
           coalesce(dm.qty_open, 0)     as qty_open
      from shipped s
      full outer join demand dm on dm.pid = s.pid
     where coalesce(s.units_out, 0) > 0 or coalesce(dm.qty_open, 0) > 0
  ),
  first_seen as (
    -- When the product started being stocked at all, so a line introduced
    -- mid-window is rated over its own life rather than the full 28 days.
    select sa.product_catalog_id as pid,
           min((sa.created_at at time zone 'Africa/Lagos')::date) as first_move
      from public.stock_adjustments sa
     group by sa.product_catalog_id
  ),
  warehouse as (
    select cs.product_catalog_id                          as pid,
           coalesce(sum(cs.quantity_on_hand), 0)::int     as qty
      from public.current_stock cs
      join public.users u on u.id = cs.agent_id
     where u.role = 'warehouse' and u.warehouse_id is null
     group by cs.product_catalog_id
  ),
  scored as (
    select b.pid,
           pc.product_name::text                          as pname,
           coalesce(c.name, '')::text                     as cname,
           coalesce(w.qty, 0)                             as wqty,
           b.units_out,
           b.qty_open,
           greatest((
             select count(*) from selling_dates sd
              where sd.dt >= greatest(v_start, coalesce(f.first_move, v_start))
           ), 1)::int                                     as sdays
      from base b
      join public.product_catalog pc on pc.id = b.pid
      left join public.clients c     on c.id = pc.client_id
      left join warehouse w          on w.pid = b.pid
      left join first_seen f         on f.pid = b.pid
  ),
  rated as (
    -- Demand is a FLOOR, and only where the shipped rate is untrustworthy:
    -- when the shelf is empty or nothing shipped all window. Those are the
    -- exact cases where "units shipped" measures our failure to stock rather
    -- than customer appetite.
    --
    -- It is deliberately NOT applied to a product that is in stock and
    -- selling. Today's open orders are a snapshot of the whole open book —
    -- backlog included — not one day's demand, so treating them as a daily
    -- rate inflates it: Celimax Retinal ships 1.6/day but had 6 orders open,
    -- which would have read as 6/day and jumped it a whole tier. "Six orders
    -- against two units" is a real problem, but it is TODAY'S problem, and
    -- stock_coverage_today already reports it. Restock answers the slower
    -- question and must not double up on that one.
    select sc.*,
           case
             when sc.units_out = 0 or sc.wqty <= 0
               then greatest(sc.units_out::numeric / sc.sdays, sc.qty_open::numeric)
             else sc.units_out::numeric / sc.sdays
           end as rate
      from scored sc
  )
  select r.pid,
         r.pname,
         r.cname,
         r.wqty,
         r.units_out,
         r.sdays,
         r.qty_open,
         round(r.rate, 2)                                        as rate_per_day,
         round(r.wqty::numeric / r.rate, 2)                      as days_cover,
         case
           -- Nothing on the shelf while the product is still moving. This is
           -- the state the old `qty > 0` low-stock rule could never report.
           when r.wqty <= 0                    then 'out'
           when r.wqty::numeric / r.rate < 1   then 'critical'
           when r.wqty::numeric / r.rate < v_lead then 'reorder'
           else 'ok'
         end                                                     as tier
    from rated r
   -- Every 'out' row ties at 0 cover, so rate breaks the tie: a product
   -- shipping 10 a day belongs above one shipping 1 a month, not below it
   -- alphabetically.
   order by r.wqty::numeric / r.rate asc, r.rate desc, r.pname;
end;
$$;


--
-- Name: FUNCTION stock_restock_signal(p_window_days integer, p_lead_days numeric); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.stock_restock_signal(p_window_days integer, p_lead_days numeric) IS 'Days-of-cover restock signal: warehouse stock divided by units shipped per selling day (Sundays excluded), floored by today''s open order quantity so a product cannot go quiet just because being out of stock stopped its sales. Tiers out/critical/reorder/ok, where reorder = cover shorter than the replenishment lead time. Ops + warehouse only (carries vendor names).';


--
-- Name: tg_auto_assign_on_insert(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_auto_assign_on_insert() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if new.assigned_agent_id is null
     and new.deleted_at is null
     and new.created_via <> 'rollover'
     and new.order_type <> 'waybill'
     and coalesce((public.get_flag('enable_auto_assign')->>'enabled')::boolean, true)
  then
    begin
      perform public.auto_assign_delivery(new.id);
    exception when others then
      perform public.write_audit(
        p_actor_id    := null,
        p_entity_type := 'delivery',
        p_entity_id   := new.id,
        p_old         := null,
        p_new         := jsonb_build_object('error', sqlerrm),
        p_reason      := 'auto_assign: error'
      );
    end;
  end if;
  return null;
end;
$$;


--
-- Name: tg_auto_initialize_client_balance(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_auto_initialize_client_balance() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  insert into public.client_balance_openings(
    client_id, effective_date, opening_balance, note, setup_request_uuid, set_by
  ) values (
    new.id,
    greatest(
      date '2026-08-24',
      (coalesce(new.created_at, now()) at time zone 'Africa/Lagos')::date
    ),
    0,
    'Automatically enabled when the client was created',
    'auto:' || new.id::text,
    null
  )
  on conflict (client_id) do nothing;
  return new;
end;
$$;


--
-- Name: tg_clear_followup_on_status_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_clear_followup_on_status_change() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if old.current_status is distinct from new.current_status then
    delete from public.delivery_followups where delivery_id = new.id;
  end if;
  return new;
end $$;


--
-- Name: tg_copy_items_on_rollover(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_copy_items_on_rollover() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
begin
  if new.created_via = 'rollover' and new.parent_delivery_id is not null then
    perform public._copy_delivery_items(new.parent_delivery_id, new.id);
  end if;
  return new;
end;
$$;


--
-- Name: tg_handle_sibling_coordination(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_handle_sibling_coordination() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_system_id constant uuid := '2d8d5895-d2a8-4900-b15e-7662b176a805';
  v_sibling record;
  v_agent_first text;
  v_agent_display text;
  v_is_terminal_entry boolean;
  v_resolving_label text;
  v_lock_key text;
begin
  -- EOD owns its own snapshot-driven sibling handling. Cascading in the middle
  -- of that loop would invalidate rows that EOD is about to process.
  if coalesce(current_setting('reda.in_eod_rollover', true), '') = 'true' then
    return new;
  end if;

  -- Updates made by this trigger re-enter it. The outer invocation has already
  -- coordinated the whole sibling group.
  if pg_trigger_depth() > 1 then
    return new;
  end if;

  -- Stage 1: stand-by signal on first claim (existing behavior).
  if old.current_status = 'pending' and new.current_status = 'available' then
    select split_part(coalesce(display_name, 'Agent'), ' ', 1)
      into v_agent_first
      from public.users
     where id = new.assigned_agent_id;

    for v_sibling in
      select s.*
        from public._find_sibling_deliveries(new.id) s
        join public.delivery_status_defs sd on sd.status = s.current_status
       where sd.category <> 'terminal'
         and s.assigned_agent_id is not null
    loop
      perform public.send_edge_notification(jsonb_build_object(
        'audience', 'user',
        'user_id',  v_sibling.assigned_agent_id::text,
        'title',    'Stand by',
        'body',     coalesce(v_agent_first, 'Another agent') || ' is on '
                    || coalesce(new.customer_name, 'this delivery') || '. Hold for now.',
        'data',     jsonb_build_object('delivery_id', v_sibling.id)
      ));
    end loop;
  end if;

  -- Stage 1.5: two live race copies may both be postponed. When they converge
  -- on the same target date, retain the copy carrying the latest customer
  -- interaction (NEW) and close older postponed siblings as duplicates.
  --
  -- The transaction-scoped lock serializes simultaneous postponements for the
  -- same customer/items/date. After the first transaction commits, the second
  -- sees it and deterministically becomes the canonical latest interaction.
  if new.order_type = 'delivery'
     and new.current_status = 'postponed'
     and new.scheduled_date is not null
     and (
       old.current_status is distinct from new.current_status
       or old.scheduled_date is distinct from new.scheduled_date
     )
  then
    v_lock_key := concat_ws('|',
      new.client_id::text,
      coalesce(new.customer_phone_normalized, ''),
      coalesce(new.items_fingerprint, new.product_catalog_id::text, ''),
      new.scheduled_date::text
    );
    perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_lock_key, 0));

    for v_sibling in
      select s.*
        from public.deliveries s
        join public._find_sibling_deliveries(new.id) matched on matched.id = s.id
       where s.current_status = 'postponed'
         and s.order_type = 'delivery'
       order by s.updated_at desc, s.created_at asc, s.id asc
       for update of s
    loop
      insert into public.delivery_status_history
        (delivery_id, from_status, to_status, changed_by_user_id,
         client_uuid, reason, effective_at)
      values
        (v_sibling.id, v_sibling.current_status, 'cancelled', v_system_id,
         'postpone-consolidate:' || new.id::text || ':' || v_sibling.id::text,
         'Duplicate postponed copy consolidated into order ' || new.id::text
           || ' for ' || new.scheduled_date::text || '.',
         now())
      on conflict (client_uuid) do nothing;

      update public.deliveries
         set current_status     = 'cancelled',
             assigned_agent_id = null,
             updated_at         = now()
       where id = v_sibling.id
         and current_status = 'postponed';

      if found then
        perform public.write_audit(
          p_entity_type := 'delivery',
          p_entity_id   := v_sibling.id,
          p_old         := jsonb_build_object(
            'current_status', v_sibling.current_status,
            'assigned_agent_id', v_sibling.assigned_agent_id,
            'scheduled_date', v_sibling.scheduled_date
          ),
          p_new         := jsonb_build_object(
            'current_status', 'cancelled',
            'assigned_agent_id', null,
            'scheduled_date', v_sibling.scheduled_date,
            'canonical_delivery_id', new.id
          ),
          p_reason      := 'postpone_sibling_consolidated',
          p_actor_id    := v_system_id
        );
      end if;
    end loop;
  end if;

  -- Stage 2: cancel open siblings on entry to a resolving terminal status
  -- (existing behavior). rolled_over belongs to EOD; agent_cancelled means the
  -- order remains live for another agent.
  v_is_terminal_entry := exists (
    select 1
      from public.delivery_status_defs
     where status = new.current_status
       and category = 'terminal'
       and status <> 'rolled_over'
       and status <> 'agent_cancelled'
  ) and old.current_status is distinct from new.current_status;

  if v_is_terminal_entry then
    select coalesce(display_name, 'Agent')
      into v_agent_display
      from public.users
     where id = new.assigned_agent_id;

    select label
      into v_resolving_label
      from public.delivery_status_defs
     where status = new.current_status;
    v_resolving_label := coalesce(v_resolving_label, new.current_status);

    for v_sibling in
      select s.*
        from public._find_sibling_deliveries(new.id) s
        join public.delivery_status_defs sd on sd.status = s.current_status
       where sd.category <> 'terminal'
    loop
      insert into public.delivery_status_history
        (delivery_id, from_status, to_status, changed_by_user_id,
         client_uuid, reason, effective_at)
      values
        (v_sibling.id, v_sibling.current_status, 'cancelled', v_system_id,
         'sibling-cancel:' || new.id::text || ':' || v_sibling.id::text,
         coalesce(v_agent_display, 'Another agent')
           || ' handled the same order (' || v_resolving_label
           || '). Closed as duplicate.',
         now());

      update public.deliveries
         set current_status = 'cancelled',
             updated_at     = now()
       where id = v_sibling.id;

      if v_sibling.assigned_agent_id is not null then
        perform public.send_edge_notification(jsonb_build_object(
          'audience', 'user',
          'user_id',  v_sibling.assigned_agent_id::text,
          'title',    'Delivery closed',
          'body',     coalesce(v_agent_display, 'Another agent') || ' handled '
                      || coalesce(new.customer_name, 'this customer') || '''s order ('
                      || v_resolving_label || '). Your row is closed as duplicate.',
          'data',     jsonb_build_object('delivery_id', v_sibling.id)
        ));
      end if;
    end loop;
  end if;

  return new;
end
$$;


--
-- Name: tg_notify_assignment_push(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_notify_assignment_push() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare
  v_new uuid := new.assigned_agent_id;
  v_old uuid := case when TG_OP = 'UPDATE' then (old).assigned_agent_id else null end;
begin
  -- Bulk RPCs set this for the transaction and send ONE summary push per
  -- rider themselves (see bulk_unassign_deliveries).
  if coalesce(current_setting('reda.suppress_assignment_push', true), '') = 'true' then
    return new;
  end if;
  -- NEW: notify the agent who LOST the row — reassigned to another agent OR
  -- unassigned back to the queue. Skip on insert/no-op, and never ping the
  -- person who performed the move (e.g. a lead handing off their own delivery).
  if TG_OP = 'UPDATE'
     and v_old is not null
     and v_old is distinct from v_new
     and v_old is distinct from auth.uid()
  then
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'user',
      'user_id',  v_old::text,
      'title',    case when v_new is null then 'Order moved to the queue'
                       else 'Order reassigned' end,
      'body',     coalesce(new.customer_name, 'A delivery')
                  || case when v_new is null then ' is no longer on your list.'
                          else ' was reassigned to another agent.' end,
      'data',     jsonb_build_object('delivery_id', new.id)
    ));
  end if;
  -- EXISTING: push the NEW assignee (unchanged).
  if v_new is null then return new; end if;
  if TG_OP = 'UPDATE' and v_new is not distinct from v_old then return new; end if;
  perform public.send_edge_notification(
    jsonb_build_object('audience', 'assignment', 'delivery_id', new.id)
  );
  return new;
end;
$$;


--
-- Name: tg_notify_bot_error(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_notify_bot_error() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if new.status = 'error' and (TG_OP = 'INSERT' or old.status is distinct from 'error') then
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'admins+dispatchers',
      'title',    'Bot order errored',
      'body',     coalesce(left(new.error_text, 120), 'Check Review -> Errors'),
      'data',     jsonb_build_object('route', 'review')
    ));
  end if;
  return new;
end;
$$;


--
-- Name: tg_notify_bot_review(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_notify_bot_review() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
begin
  if new.status = 'needs_review'
     and (TG_OP = 'INSERT' or old.status is distinct from 'needs_review')
  then
    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'admins+dispatchers',
      'title',    'Bot needs review',
      'body',     'A WhatsApp message couldn''t be parsed — open Review.',
      'data',     jsonb_build_object('route', 'review', 'inbound_id', new.id)
    ));
  end if;
  return new;
end;
$$;


--
-- Name: tg_notify_delivery_message(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_notify_delivery_message() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_customer    text;
  v_agent_first text;
  v_agent_id    uuid;
  v_author_name text;
  v_label       text;
begin
  if new.author_role = 'agent' then
    -- Auto-seeded soft-fail notes (an agent picking number_busy/not_connecting/
    -- switched_off/etc. routes through flag_delivery_issue with
    -- issue_type='cant_reach_client') are routine call outcomes, not the agent
    -- reaching out — so they push no one. Mirrors the mobile AUTO_SEEDED_ISSUE_TYPES
    -- set and the list badge (opsUnreadAgentCounts). Deliberate contact (a reply,
    -- issue_type null, or an actionable flag) still notifies.
    if new.issue_type = 'cant_reach_client' then
      return new;
    end if;

    select d.customer_name, split_part(coalesce(u.display_name, 'Agent'), ' ', 1)
      into v_customer, v_agent_first
      from public.deliveries d
      left join public.users u on u.id = d.assigned_agent_id
     where d.id = new.delivery_id;

    v_label := public._dm_issue_label(new.issue_type);

    -- Reps own agent issues, EXCEPT 'not my route': that's a reassignment only
    -- admins/dispatchers can do, so route it to 'managers' (admin + dispatcher).
    -- 'reps' / 'managers' both resolve in the send-notification edge function.
    perform public.send_edge_notification(jsonb_build_object(
      'audience', case when new.issue_type = 'not_my_route' then 'managers' else 'reps' end,
      'title',    'Issue flagged',
      'body',     v_label || ' · ' || coalesce(v_customer, 'customer')
                  || ' (' || coalesce(v_agent_first, 'Agent') || ')',
      'data',     jsonb_build_object('delivery_id', new.delivery_id)
    ));
  else
    -- ops_to_agent
    select assigned_agent_id into v_agent_id
      from public.deliveries where id = new.delivery_id;
    if v_agent_id is null then
      return new;
    end if;

    select display_name into v_author_name
      from public.users where id = new.author_id;

    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'user',
      'user_id',  v_agent_id::text,
      'title',    'Reply from ' || coalesce(v_author_name, 'ops'),
      'body',     left(coalesce(new.note, ''), 120),
      'data',     jsonb_build_object('delivery_id', new.delivery_id)
    ));
  end if;
  return new;
end $$;


--
-- Name: tg_notify_delivery_status_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_notify_delivery_status_change() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare
  v_notify_set text[] := array['delivered','cancelled','failed_delivery','unserious','no_product'];
begin
  if new.order_type <> 'waybill'
     and new.current_status = any(v_notify_set)
     and (TG_OP = 'INSERT' or old.current_status is distinct from new.current_status)
  then
    perform public.send_edge_notification(jsonb_build_object(
      'audience',    'status_change',
      'delivery_id', new.id,
      'new_status',  new.current_status
    ));
  end if;
  return new;
end;
$$;


--
-- Name: tg_notify_negative_stock(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_notify_negative_stock() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
declare
  v_balance int;
  v_agent   text;
  v_product text;
begin
  select quantity_on_hand into v_balance
    from public.current_stock
   where agent_id = new.agent_id
     and product_catalog_id = new.product_catalog_id;

  if v_balance is null or v_balance >= 0 then return new; end if;

  select display_name into v_agent
    from public.users where id = new.agent_id;
  select product_name into v_product
    from public.product_catalog where id = new.product_catalog_id;

  perform public.send_edge_notification(jsonb_build_object(
    'audience', 'admins',
    'title',    'Negative stock',
    'body',     coalesce(v_agent, 'Agent') || ' is at ' || v_balance
                || ' on ' || coalesce(v_product, 'a product'),
    'data',     jsonb_build_object(
                  'route',      'stock',
                  'agent_id',   new.agent_id,
                  'product_id', new.product_catalog_id
                )
  ));
  return new;
end;
$$;


--
-- Name: tg_set_assigned_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_set_assigned_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if tg_op = 'INSERT' then
    if new.assigned_agent_id is not null then
      new.assigned_at := coalesce(new.assigned_at, now());
    end if;
  elsif new.assigned_agent_id is not null
        and new.assigned_agent_id is distinct from old.assigned_agent_id then
    new.assigned_at := now();
  end if;
  return new;
end $$;


--
-- Name: tg_signal_new_sibling(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_signal_new_sibling() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
declare
  v_sibling record;
  v_agent_first text;
begin
  if new.customer_phone_normalized is null
     or new.assigned_agent_id is null then
    return new;
  end if;

  for v_sibling in
    select * from public._find_sibling_deliveries(new.id)
     where current_status in ('available','available_evening')
       and assigned_agent_id is not null
  loop
    select split_part(coalesce(display_name, 'Agent'), ' ', 1)
      into v_agent_first
      from public.users where id = v_sibling.assigned_agent_id;

    perform public.send_edge_notification(jsonb_build_object(
      'audience', 'user',
      'user_id',  new.assigned_agent_id::text,
      'title',    'Stand by',
      'body',     coalesce(v_agent_first, 'Another agent') || ' is on '
                  || coalesce(new.customer_name, 'this delivery') || '. Hold for now.',
      'data',     jsonb_build_object('delivery_id', new.id)
    ));
  end loop;

  return new;
end $$;


--
-- Name: tg_sync_user_email_to_public(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.tg_sync_user_email_to_public() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
begin
  if new.email is distinct from old.email then
    update public.users
       set email = new.email
     where id = new.id;
  end if;
  return new;
end;
$$;


--
-- Name: FUNCTION tg_sync_user_email_to_public(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.tg_sync_user_email_to_public() IS 'Mirrors auth.users.email into public.users.email after a confirmed email change. Wired via the sync_user_email_to_public trigger on auth.users. Added 2026-05-26 when in-app email self-edit shipped.';


--
-- Name: today_delivery_rate(date); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.today_delivery_rate(p_for_date date DEFAULT NULL::date) RETURNS TABLE(delivered integer, available integer)
    LANGUAGE plpgsql STABLE SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_date date := coalesce(p_for_date, (now() at time zone 'Africa/Lagos')::date);
begin
  if not public.is_admin_or_dispatcher() then
    raise exception 'delivery rate requires admin or dispatcher role' using errcode = '42501';
  end if;

  return query
  with grp as (
    select sibling_group_key,
           bool_or(is_delivered) as dl,
           bool_or(is_available) as av
      from public._delivery_rate_base
     where scheduled_date = v_date
     group by sibling_group_key
  )
  select
    count(*) filter (where dl)::int,
    count(*) filter (where av)::int
  from grp;
end;
$$;


--
-- Name: unassign_delivery(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.unassign_delivery(p_delivery_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$

declare

  v_actor       uuid := auth.uid();

  v_row         public.deliveries%rowtype;

  v_is_terminal boolean;

begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],'{}'::uuid[]);

  if not public.is_manager() then

    raise exception 'unassign requires admin or dispatcher role'

      using errcode = '42501';

  end if;



  if p_reason is null or btrim(p_reason) = '' then

    raise exception 'reason required for unassign' using errcode = '22023';

  end if;



  select * into v_row from public.deliveries where id = p_delivery_id for update;

  if not found then

    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';

  end if;

  if v_row.deleted_at is not null then

    raise exception 'cannot unassign a deleted delivery' using errcode = '22023';

  end if;



  select category = 'terminal' into v_is_terminal

    from public.delivery_status_defs

   where status = v_row.current_status;

  if v_is_terminal is true then

    raise exception 'cannot unassign a terminal delivery (status=%)', v_row.current_status

      using errcode = '22023',

            hint   = 'reopen via the state machine first if this row must be reassigned';

  end if;



  if v_row.assigned_agent_id is null then

    raise exception 'delivery is already unassigned' using errcode = '22023';

  end if;



  update public.deliveries

     set assigned_agent_id = null,

         updated_at        = now()

   where id = p_delivery_id;



  perform public.write_audit(

    p_actor_id    := v_actor,

    p_entity_type := 'delivery',

    p_entity_id   := p_delivery_id,

    p_old         := jsonb_build_object('assigned_agent_id', v_row.assigned_agent_id),

    p_new         := jsonb_build_object('assigned_agent_id', null),

    p_reason      := 'unassign: ' || btrim(p_reason)

  );

end;

$$;


--
-- Name: FUNCTION unassign_delivery(p_delivery_id uuid, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.unassign_delivery(p_delivery_id uuid, p_reason text) IS 'Admin/dispatcher/rep: clear assigned_agent_id on a non-terminal delivery. Reason required; audit-logged with reason ''unassign: <text>''.';


--
-- Name: update_client(uuid, text, text, text, text, text, numeric); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_client(p_id uuid, p_name text, p_contact_phone text, p_contact_email text, p_notes text, p_reason text DEFAULT NULL::text, p_max_charge_per_delivery numeric DEFAULT NULL::numeric) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old   public.clients;
  v_name  text := nullif(trim(p_name), '');
  v_phone text := nullif(trim(p_contact_phone), '');
  v_email text := nullif(trim(p_contact_email), '');
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  select * into v_old from public.clients where id = p_id;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;
  if v_name is null then
    raise exception 'name required' using errcode = '23514';
  end if;
  if p_max_charge_per_delivery is not null and p_max_charge_per_delivery < 0 then
    raise exception 'max_charge_per_delivery must be >= 0' using errcode = '23514';
  end if;

  update public.clients
     set name                    = v_name,
         contact_phone           = v_phone,
         contact_email           = v_email,
         notes                   = p_notes,
         max_charge_per_delivery = coalesce(p_max_charge_per_delivery, max_charge_per_delivery)
   where id = p_id;

  perform public.write_audit(
    'client', p_id,
    jsonb_build_object(
      'name',                    v_old.name,
      'contact_phone',           v_old.contact_phone,
      'contact_email',           v_old.contact_email,
      'notes',                   v_old.notes,
      'max_charge_per_delivery', v_old.max_charge_per_delivery
    ),
    jsonb_build_object(
      'name',                    v_name,
      'contact_phone',           v_phone,
      'contact_email',           v_email,
      'notes',                   p_notes,
      'max_charge_per_delivery', coalesce(p_max_charge_per_delivery, v_old.max_charge_per_delivery)
    ),
    p_reason
  );
end;
$$;


--
-- Name: update_client(uuid, text, text, text, text, text, numeric, boolean); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_client(p_id uuid, p_name text, p_contact_phone text, p_contact_email text, p_notes text, p_reason text DEFAULT NULL::text, p_max_charge_per_delivery numeric DEFAULT NULL::numeric, p_auto_cancel_soft_fails boolean DEFAULT NULL::boolean) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old   public.clients;
  v_name  text := nullif(trim(p_name), '');
  v_phone text := nullif(trim(p_contact_phone), '');
  v_email text := nullif(trim(p_contact_email), '');
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  select * into v_old from public.clients where id = p_id;
  if not found then
    raise exception 'client not found' using errcode = 'P0002';
  end if;
  if v_name is null then
    raise exception 'name required' using errcode = '23514';
  end if;
  if p_max_charge_per_delivery is not null and p_max_charge_per_delivery < 0 then
    raise exception 'max_charge_per_delivery must be >= 0' using errcode = '23514';
  end if;

  update public.clients
     set name                    = v_name,
         contact_phone           = v_phone,
         contact_email           = v_email,
         notes                   = p_notes,
         max_charge_per_delivery = coalesce(p_max_charge_per_delivery, max_charge_per_delivery),
         auto_cancel_soft_fails  = coalesce(p_auto_cancel_soft_fails, auto_cancel_soft_fails)
   where id = p_id;

  perform public.write_audit(
    'client', p_id,
    jsonb_build_object(
      'name',                    v_old.name,
      'contact_phone',           v_old.contact_phone,
      'contact_email',           v_old.contact_email,
      'notes',                   v_old.notes,
      'max_charge_per_delivery', v_old.max_charge_per_delivery,
      'auto_cancel_soft_fails',  v_old.auto_cancel_soft_fails
    ),
    jsonb_build_object(
      'name',                    v_name,
      'contact_phone',           v_phone,
      'contact_email',           v_email,
      'notes',                   p_notes,
      'max_charge_per_delivery', coalesce(p_max_charge_per_delivery, v_old.max_charge_per_delivery),
      'auto_cancel_soft_fails',  coalesce(p_auto_cancel_soft_fails,  v_old.auto_cancel_soft_fails)
    ),
    p_reason
  );
end;
$$;


--
-- Name: update_delivery_fields(uuid, text, text, text, uuid, uuid, uuid, integer, numeric, uuid, text, jsonb, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_delivery_fields(p_delivery_id uuid, p_customer_name text DEFAULT NULL::text, p_customer_phone text DEFAULT NULL::text, p_raw_address text DEFAULT NULL::text, p_location_id uuid DEFAULT NULL::uuid, p_client_id uuid DEFAULT NULL::uuid, p_product_catalog_id uuid DEFAULT NULL::uuid, p_quantity_ordered integer DEFAULT NULL::integer, p_customer_price numeric DEFAULT NULL::numeric, p_assigned_agent_id uuid DEFAULT NULL::uuid, p_customer_phone_alt text DEFAULT NULL::text, p_items jsonb DEFAULT NULL::jsonb, p_delivery_instructions text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old            public.deliveries%rowtype;
  v_old_jsonb      jsonb;
  v_new_jsonb      jsonb;
  v_eff_location   uuid;
  v_eff_client     uuid;
  v_eff_agent      uuid;
  v_rate_changed   boolean;
  v_charged        numeric;
  v_agent_payment  numeric;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_orders(array[p_delivery_id],array[p_assigned_agent_id]);
  if not public.is_manager() then
    raise exception 'permission denied: admin or dispatcher only' using errcode = '42501';
  end if;
  perform public._assert_holds_lock('delivery', p_delivery_id);

  select * into v_old from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found' using errcode = 'P0002';
  end if;
  v_old_jsonb := to_jsonb(v_old);

  if v_old.current_status not in (
    'pending','available','available_evening',
    'not_answering','number_busy','switched_off','tomorrow','postponed','follow_up',
    'not_connecting','not_around','will_call_back','not_available'
  ) then
    raise exception 'delivery is locked (status=%); only pre-delivery rows can be edited', v_old.current_status
      using errcode = '22023';
  end if;

  v_eff_location := coalesce(p_location_id,       v_old.location_id);
  v_eff_client   := coalesce(p_client_id,         v_old.client_id);
  v_eff_agent    := coalesce(p_assigned_agent_id, v_old.assigned_agent_id);

  v_rate_changed :=
       (v_eff_location is distinct from v_old.location_id)
    or (v_eff_client   is distinct from v_old.client_id)
    or (v_eff_agent    is distinct from v_old.assigned_agent_id);

  if v_rate_changed then
    select er.charged, er.agent_payment into v_charged, v_agent_payment
      from public.effective_rate(v_eff_location, v_eff_client, v_eff_agent) er;
    if v_charged is null then
      raise exception 'no active rate card for (location=%, client=%); cannot recompute snapshots',
        v_eff_location, v_eff_client
        using errcode = '22023', hint = 'add a rate_card row for this location/client before editing';
    end if;
  end if;

  if p_items is not null then
    if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
      raise exception 'p_items must be a non-empty array' using errcode = '23514';
    end if;
    if exists (
      select 1 from jsonb_array_elements(p_items) e
       where not exists (
         select 1 from public.product_catalog pc
          where pc.id = (e->>'product_catalog_id')::uuid
            and pc.client_id = v_eff_client and pc.is_active = true)
    ) then
      raise exception 'a line item product is inactive or does not belong to the client' using errcode = '23514';
    end if;
  end if;

  update public.deliveries set
    customer_name      = coalesce(p_customer_name,      customer_name),
    customer_phone     = coalesce(p_customer_phone,     customer_phone),
    customer_phone_alt = case when p_customer_phone_alt is null then customer_phone_alt
                              when p_customer_phone_alt = ''   then null
                              else p_customer_phone_alt end,
    raw_address        = coalesce(p_raw_address,        raw_address),
    location_id        = v_eff_location,
    client_id          = v_eff_client,
    product_catalog_id = coalesce(p_product_catalog_id, product_catalog_id),
    quantity_ordered   = coalesce(p_quantity_ordered,   quantity_ordered),
    customer_price     = coalesce(p_customer_price,     customer_price),
    delivery_instructions = case when p_delivery_instructions is null then delivery_instructions
                                 when p_delivery_instructions = ''   then null
                                 else p_delivery_instructions end,
    charged_snapshot   = case when v_rate_changed then v_charged else charged_snapshot end,
    agent_payment_snapshot = case when v_rate_changed then v_agent_payment else agent_payment_snapshot end,
    agent_payment_base_snapshot = case when v_rate_changed then v_agent_payment else agent_payment_base_snapshot end,
    agent_payment_base_captured_at = case when v_rate_changed then clock_timestamp() else agent_payment_base_captured_at end,
    assigned_agent_id  = v_eff_agent,
    updated_at         = now()
   where id = p_delivery_id;

  -- Replace the item set when provided; else keep the LONE line in sync with a
  -- legacy single-product edit. [Feature A safety guard] never run the lone-line
  -- sync on a multi-item order — that would collapse the bundle. A stale bundle
  -- editing other fields (price/address/…) still works; items are left intact.
  if p_items is not null then
    perform public._apply_delivery_items(p_delivery_id, p_items);
  elsif (p_product_catalog_id is not null or p_quantity_ordered is not null or p_customer_price is not null)
        and (select count(*) from public.delivery_items where delivery_id = p_delivery_id) <= 1 then
    perform public._apply_delivery_items(p_delivery_id, jsonb_build_array(jsonb_build_object(
      'product_catalog_id', coalesce(p_product_catalog_id, v_old.product_catalog_id),
      'quantity_ordered',   coalesce(p_quantity_ordered,   v_old.quantity_ordered),
      'customer_price',     coalesce(p_customer_price,     v_old.customer_price))));
  end if;

  select to_jsonb(d) into v_new_jsonb from public.deliveries d where id = p_delivery_id;
  perform public.write_audit(
    'delivery', p_delivery_id, v_old_jsonb, v_new_jsonb,
    case when v_rate_changed then 'update_fields:rate_resnapshot' else 'update_fields' end, null);
end;
$$;


--
-- Name: update_location(uuid, text, text[], numeric, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_location(p_id uuid, p_name text, p_aliases text[], p_latitude numeric, p_longitude numeric, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old   public.locations;
  v_name  text := nullif(trim(p_name), '');
  v_aliases text[] := coalesce(p_aliases, '{}'::text[]);
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select * into v_old from public.locations where id = p_id;
  if not found then
    raise exception 'location not found' using errcode = 'P0002';
  end if;
  if v_name is null then
    raise exception 'name required' using errcode = '23514';
  end if;

  v_aliases := array(
    select trim(a) from unnest(v_aliases) a
     where nullif(trim(a), '') is not null
  );

  update public.locations
     set name      = v_name,
         aliases   = v_aliases,
         latitude  = p_latitude,
         longitude = p_longitude
   where id = p_id;

  perform public.write_audit(
    'location', p_id,
    jsonb_build_object(
      'name', v_old.name,
      'aliases', to_jsonb(v_old.aliases),
      'latitude', v_old.latitude,
      'longitude', v_old.longitude
    ),
    jsonb_build_object(
      'name', v_name,
      'aliases', to_jsonb(v_aliases),
      'latitude', p_latitude,
      'longitude', p_longitude
    ),
    p_reason
  );
end;
$$;


--
-- Name: update_product(uuid, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_product(p_id uuid, p_product_name text, p_description text, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old  public.product_catalog;
  v_name text := nullif(trim(p_product_name), '');
  v_desc text := nullif(trim(p_description), '');
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;

  select * into v_old from public.product_catalog where id = p_id;
  if not found then
    raise exception 'product not found' using errcode = 'P0002';
  end if;
  if v_name is null then
    raise exception 'product_name required' using errcode = '23514';
  end if;

  update public.product_catalog
     set product_name = v_name,
         description  = v_desc
   where id = p_id;

  perform public.write_audit(
    'product', p_id,
    jsonb_build_object('product_name', v_old.product_name, 'description', v_old.description),
    jsonb_build_object('product_name', v_name,            'description', v_desc),
    p_reason
  );
end;
$$;


--
-- Name: update_replacement_attempt_fees(uuid, numeric, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_replacement_attempt_fees(p_attempt_id uuid, p_client_charge numeric, p_agent_payment numeric, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_attempt record;
  v_day date;
  v_client_delta numeric;
  v_agent_delta numeric;
begin
  if not public.is_admin() then
    raise exception 'only admin can correct replacement fees' using errcode = '42501';
  end if;
  if nullif(trim(p_reason), '') is null then
    raise exception 'reason required for fee correction' using errcode = '23514';
  end if;
  if coalesce(p_client_charge, -1) < 0 or coalesce(p_agent_payment, -1) < 0 then
    raise exception 'replacement fees must be >= 0' using errcode = '23514';
  end if;

  select a.*, d.client_id into v_attempt
    from public.replacement_attempts a
    join public.deliveries d on d.id = a.delivery_id
   where a.id = p_attempt_id for update of a;
  if not found then
    raise exception 'replacement attempt not found' using errcode = 'P0002';
  end if;
  v_day := (v_attempt.attempted_at at time zone 'Africa/Lagos')::date;

  if exists (
    select 1 from public.settlements s
     where s.subject_type = 'client' and s.subject_id = v_attempt.client_id
       and s.period_date = v_day and s.voided_at is null
  ) then
    raise exception 'client reconciliation for this attempt date is already settled'
      using errcode = '22023',
            hint = 'void the client settlement, correct the fee, then settle again';
  end if;
  if exists (
    select 1 from public.settlements s
     where s.subject_type = 'agent' and s.subject_id = v_attempt.assigned_agent_id
       and s.period_date = v_day and s.voided_at is null
  ) then
    raise exception 'rider reconciliation for this attempt date is already settled'
      using errcode = '22023',
            hint = 'void the rider settlement, correct the fee, then settle again';
  end if;

  v_client_delta := p_client_charge - v_attempt.client_charge;
  v_agent_delta := p_agent_payment - v_attempt.agent_payment;
  update public.replacement_attempts
     set client_charge = p_client_charge, agent_payment = p_agent_payment
   where id = p_attempt_id;
  update public.deliveries
     set charged_snapshot = coalesce(charged_snapshot, 0) + v_client_delta,
         agent_payment_snapshot = coalesce(agent_payment_snapshot, 0) + v_agent_delta,
         updated_at = now()
   where id = v_attempt.delivery_id;

  perform public.write_audit(
    'replacement_attempt', p_attempt_id,
    jsonb_build_object(
      'client_charge',v_attempt.client_charge, 'agent_payment',v_attempt.agent_payment
    ),
    jsonb_build_object(
      'client_charge',p_client_charge, 'agent_payment',p_agent_payment
    ), trim(p_reason)
  );
end;
$$;


--
-- Name: update_self_profile(text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_self_profile(p_display_name text, p_phone text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_old   public.users%rowtype;
begin
  if v_actor is null then
    raise exception 'not authenticated' using errcode = '42501';
  end if;

  select * into v_old from public.users where id = v_actor;
  if not found then
    raise exception 'user row missing' using errcode = 'P0002';
  end if;

  if length(coalesce(trim(p_display_name), '')) < 2 then
    raise exception 'display name too short' using errcode = '22023';
  end if;

  update public.users
     set display_name = trim(p_display_name),
         phone        = nullif(trim(p_phone), '')
   where id = v_actor;

  perform public.write_audit(
    p_entity_type := 'user',
    p_entity_id   := v_actor,
    p_old         := to_jsonb(v_old),
    p_new         := jsonb_build_object(
      'display_name', trim(p_display_name),
      'phone',        nullif(trim(p_phone), '')
    ),
    p_reason      := 'self-edit profile',
    p_actor_id    := v_actor
  );
end;
$$;


--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    new.updated_at = now();
    return new;
end;
$$;


--
-- Name: update_user(uuid, text, text, text, text, numeric, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_user(p_id uuid, p_display_name text, p_role text, p_phone text, p_reason text DEFAULT NULL::text, p_agent_payment_bonus numeric DEFAULT NULL::numeric, p_warehouse_id uuid DEFAULT NULL::uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_old   public.users;
  v_name  text := nullif(trim(p_display_name), '');
  v_phone text := nullif(trim(p_phone), '');
  v_new_warehouse_id uuid;
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  select * into v_old from public.users where id = p_id;
  if not found then
    raise exception 'user not found' using errcode = 'P0002';
  end if;
  if v_name is null then
    raise exception 'display_name required' using errcode = '23514';
  end if;
  if p_role not in ('admin','dispatcher','agent','warehouse','rep') then
    raise exception 'invalid role' using errcode = '23514';
  end if;
  if p_agent_payment_bonus is not null and p_agent_payment_bonus < 0 then
    raise exception 'agent_payment_bonus must be >= 0' using errcode = '23514';
  end if;

  -- Resolve the new link: only meaningful for warehouse users; coalesce keeps
  -- the existing link when the caller doesn't pass one; any non-warehouse role
  -- clears it so the users_warehouse_staff_sanity CHECK can't be violated.
  v_new_warehouse_id := case
    when p_role = 'warehouse' then coalesce(p_warehouse_id, v_old.warehouse_id)
    else null
  end;
  if v_new_warehouse_id is not null then
    if v_new_warehouse_id = p_id then
      raise exception 'a warehouse user cannot be linked to itself' using errcode = '23514';
    end if;
    if not exists (
      select 1 from public.users
       where id = v_new_warehouse_id and role = 'warehouse'
         and warehouse_id is null and is_active = true
    ) then
      raise exception 'warehouse_id must reference an active warehouse place' using errcode = '23514';
    end if;
  end if;

  if p_role = 'agent' and v_old.role <> 'agent' then
    insert into public.agent_profiles (user_id, delivery_capacity)
    values (p_id, 10)
    on conflict (user_id) do nothing;
  end if;

  update public.users
     set display_name        = v_name,
         role                = p_role,
         phone               = v_phone,
         agent_payment_bonus = coalesce(p_agent_payment_bonus, agent_payment_bonus),
         warehouse_id        = v_new_warehouse_id
   where id = p_id;

  perform public.write_audit(
    'user', p_id,
    jsonb_build_object(
      'display_name',        v_old.display_name,
      'role',                v_old.role,
      'phone',               v_old.phone,
      'agent_payment_bonus', v_old.agent_payment_bonus,
      'warehouse_id',        v_old.warehouse_id
    ),
    jsonb_build_object(
      'display_name',        v_name,
      'role',                p_role,
      'phone',               v_phone,
      'agent_payment_bonus', coalesce(p_agent_payment_bonus, v_old.agent_payment_bonus),
      'warehouse_id',        v_new_warehouse_id
    ),
    p_reason
  );
end;
$$;


--
-- Name: update_waybill(uuid, uuid, numeric, numeric, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_waybill(p_delivery_id uuid, p_client_id uuid, p_charged numeric, p_paid numeric, p_label text, p_note text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor          uuid := auth.uid();
  v_row            public.deliveries%rowtype;
  v_role           text;
  v_label          text := coalesce(nullif(btrim(p_label), ''), 'Waybill');
  v_client_changed boolean;
  v_charge_changed boolean;
begin
  if not public.is_manager() then
    raise exception 'editing a waybill requires admin or dispatcher role' using errcode = '42501';
  end if;
  if p_client_id is null then
    raise exception 'a client is required for a waybill' using errcode = '23514';
  end if;
  if p_charged is null or p_charged < 0 then
    raise exception 'charge must be a non-negative number' using errcode = '23514';
  end if;
  if p_paid is null or p_paid < 0 then
    raise exception 'paid out must be a non-negative number' using errcode = '23514';
  end if;

  select * into v_row from public.deliveries where id = p_delivery_id for update;
  if not found then
    raise exception 'delivery not found: %', p_delivery_id using errcode = 'P0002';
  end if;
  if v_row.deleted_at is not null then
    raise exception 'cannot edit a deleted waybill' using errcode = '22023';
  end if;
  if v_row.order_type <> 'waybill' then
    raise exception 'update_waybill only edits waybill/pickup orders (order_type=%)', v_row.order_type
      using errcode = '22023',
            hint = 'use the delivery editors / correction RPCs for normal deliveries';
  end if;

  v_client_changed := p_client_id is distinct from v_row.client_id;
  v_charge_changed := p_charged    is distinct from v_row.charged_snapshot;

  -- Settled-day guard (client side). If the charge or client changed and the
  -- current client's day is frozen, the remitted figure would desync.
  if (v_charge_changed or v_client_changed) and exists (
    select 1 from public.settlements s
     where s.subject_type = 'client'
       and s.subject_id   = v_row.client_id
       and s.period_date  = v_row.scheduled_date
       and s.voided_at is null
  ) then
    raise exception
      'cannot edit: the client is already settled for %', v_row.scheduled_date
      using errcode = '23505',
            hint   = 'void the client settlement for this day, then edit and re-settle';
  end if;

  -- Moving the charge ONTO a client already settled for that day would also desync.
  if v_client_changed and exists (
    select 1 from public.settlements s
     where s.subject_type = 'client'
       and s.subject_id   = p_client_id
       and s.period_date  = v_row.scheduled_date
       and s.voided_at is null
  ) then
    raise exception
      'cannot move to that client: they are already settled for %', v_row.scheduled_date
      using errcode = '23505',
            hint   = 'void that client''s settlement for this day first';
  end if;

  update public.deliveries
     set client_id              = p_client_id,
         charged_snapshot       = p_charged,
         agent_payment_snapshot = p_paid,
         customer_name          = v_label,
         updated_at             = now()
   where id = p_delivery_id;

  -- Keep the client-facing breakdown note in sync. client_remit_detail reads the
  -- EARLIEST non-empty delivery_message for waybill rows, so update that row in
  -- place; insert one only if (unexpectedly) none exists.
  if nullif(btrim(p_note), '') is not null then
    select role into v_role from public.users where id = v_actor;
    v_role := case when v_role in ('admin','dispatcher') then v_role else 'admin' end;

    update public.delivery_messages dm
       set note = btrim(p_note)
      from (
        select id from public.delivery_messages
         where delivery_id = p_delivery_id
           and nullif(btrim(note), '') is not null
         order by created_at asc
         limit 1
      ) fn
     where dm.id = fn.id;

    if not found then
      insert into public.delivery_messages (delivery_id, author_id, author_role, note)
        values (p_delivery_id, v_actor, v_role, btrim(p_note));
    end if;
  end if;

  perform public.write_audit(
    p_actor_id    := v_actor,
    p_entity_type := 'delivery',
    p_entity_id   := p_delivery_id,
    p_old         := jsonb_build_object(
      'client_id',              v_row.client_id,
      'charged_snapshot',       v_row.charged_snapshot,
      'agent_payment_snapshot', v_row.agent_payment_snapshot,
      'customer_name',          v_row.customer_name
    ),
    p_new         := jsonb_build_object(
      'client_id',              p_client_id,
      'charged_snapshot',       p_charged,
      'agent_payment_snapshot', p_paid,
      'customer_name',          v_label
    ),
    p_reason      := 'waybill_edit'
  );
end;
$$;


--
-- Name: upsert_rate_card(uuid, numeric, numeric, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.upsert_rate_card(p_location_id uuid, p_charged numeric, p_agent_payment numeric, p_reason text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_new_id        uuid;
  v_prev          public.rate_card;
  v_location_active boolean;
  v_now           timestamptz := now();
  v_actor         uuid := auth.uid();
begin
  if not public.is_admin() then
    raise exception 'permission denied: admin only' using errcode = '42501';
  end if;
  if p_charged is null or p_charged < 0 then
    raise exception 'charged must be a non-negative number' using errcode = '23514';
  end if;
  if p_agent_payment is null or p_agent_payment < 0 then
    raise exception 'agent_payment must be a non-negative number' using errcode = '23514';
  end if;

  select is_active into v_location_active from public.locations where id = p_location_id;
  if not found then
    raise exception 'location not found' using errcode = 'P0002';
  end if;
  if not v_location_active then
    raise exception 'location is inactive — reactivate it before setting a rate' using errcode = '23514';
  end if;

  -- Lock and read the current rate (if any), then close it.
  select * into v_prev
    from public.rate_card
   where location_id = p_location_id
     and effective_until is null
   for update;

  if found then
    -- No-op if nothing actually changed (avoid creating a meaningless version)
    if v_prev.charged = p_charged and v_prev.agent_payment = p_agent_payment then
      return v_prev.id;
    end if;
    update public.rate_card set effective_until = v_now where id = v_prev.id;
  end if;

  insert into public.rate_card (location_id, charged, agent_payment, effective_from, created_by_user_id)
  values (p_location_id, p_charged, p_agent_payment, v_now, v_actor)
  returning id into v_new_id;

  perform public.write_audit(
    'rate_card', p_location_id,
    case when v_prev.id is not null
      then jsonb_build_object('charged', v_prev.charged, 'agent_payment', v_prev.agent_payment)
      else null
    end,
    jsonb_build_object('charged', p_charged, 'agent_payment', p_agent_payment),
    p_reason
  );

  return v_new_id;
end;
$$;


--
-- Name: FUNCTION upsert_rate_card(p_location_id uuid, p_charged numeric, p_agent_payment numeric, p_reason text); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.upsert_rate_card(p_location_id uuid, p_charged numeric, p_agent_payment numeric, p_reason text) IS 'Set a new rate for a location. Closes the current effective row by setting effective_until = now() and inserts a new row with effective_from = now(). If the new charged + agent_payment match the current row, it is a no-op. Audit-logged. entity_type in audit_log is "rate_card" and entity_id is the location_id (one logical thread of changes per location).';


--
-- Name: void_client_payment(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.void_client_payment(p_payment_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_row public.client_payments%rowtype;
begin
  if not public.is_admin() then
    raise exception 'only admin can void client payments' using errcode = '42501';
  end if;
  if nullif(btrim(p_reason), '') is null then
    raise exception 'void reason required' using errcode = '22023';
  end if;
  select * into v_row from public.client_payments where id = p_payment_id for update;
  if not found then raise exception 'payment not found' using errcode = 'P0002'; end if;
  if v_row.voided_at is not null then return; end if;

  update public.client_payments set
    voided_at = now(), voided_by = v_actor, void_reason = btrim(p_reason)
  where id = p_payment_id;

  perform public.write_audit(
    'client_payment', p_payment_id, to_jsonb(v_row),
    to_jsonb(v_row) || jsonb_build_object(
      'voided_at', now(), 'voided_by', v_actor, 'void_reason', btrim(p_reason)
    ), 'void'
  );
end;
$$;


--
-- Name: void_client_payout(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.void_client_payout(p_payout_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_row public.client_payouts%rowtype;
begin
  if not public.is_admin() then
    raise exception 'only admin can void client payouts' using errcode = '42501';
  end if;
  if nullif(btrim(p_reason), '') is null then
    raise exception 'void reason required' using errcode = '22023';
  end if;
  select * into v_row from public.client_payouts where id = p_payout_id for update;
  if not found then raise exception 'payout not found' using errcode = 'P0002'; end if;
  if v_row.voided_at is not null then return; end if;

  update public.client_payouts set
    voided_at = now(), voided_by = v_actor, void_reason = btrim(p_reason)
  where id = p_payout_id;

  perform public.write_audit(
    'client_payout', p_payout_id, to_jsonb(v_row),
    to_jsonb(v_row) || jsonb_build_object(
      'voided_at', now(), 'voided_by', v_actor, 'void_reason', btrim(p_reason)
    ), 'void'
  );
end;
$$;


--
-- Name: void_settlement(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.void_settlement(p_settlement_id uuid, p_reason text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor uuid := auth.uid();
  v_row   public.settlements%rowtype;
begin
  -- same_customer_financial_outer_lock
  perform public._same_customer_lock_financial_keys(array(select case when subject_type='agent' then 'agent:'||subject_id::text else 'client:'||subject_id::text||':'||period_date::text end from public.settlements where id=p_settlement_id));
  if not public.is_admin() then
    raise exception 'only admin can void a settlement' using errcode = '42501';
  end if;
  if nullif(btrim(p_reason), '') is null then
    raise exception 'reason required to void a settlement' using errcode = '23514';
  end if;

  select * into v_row from public.settlements where id = p_settlement_id for update;
  if not found then
    raise exception 'settlement not found' using errcode = 'P0002';
  end if;
  if v_row.voided_at is not null then
    raise exception 'settlement is already voided' using errcode = '22023';
  end if;

  update public.settlements
     set voided_at   = now(),
         voided_by   = v_actor,
         void_reason = p_reason
   where id = p_settlement_id;
  if v_row.subject_type='agent' then perform public._refresh_same_customer_pay_period(v_row.subject_id,v_row.period_date); end if;

  perform public.write_audit(
    'settlement', p_settlement_id,
    jsonb_build_object('voided_at', null),
    jsonb_build_object('voided_at', now(), 'voided_by', v_actor, 'void_reason', p_reason),
    'void'
  );
end;
$$;


--
-- Name: write_audit(text, uuid, jsonb, jsonb, text, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.write_audit(p_entity_type text, p_entity_id uuid, p_old jsonb, p_new jsonb, p_reason text DEFAULT NULL::text, p_actor_id uuid DEFAULT NULL::uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public', 'auth'
    AS $$
declare
  v_actor   uuid := coalesce(p_actor_id, auth.uid());
  v_key     text;
  v_old_val text;
  v_new_val text;
begin
  if v_actor is null then
    raise exception 'write_audit: actor unknown' using errcode = '28000';
  end if;

  for v_key in
    select k from (
      select jsonb_object_keys(coalesce(p_old, '{}'::jsonb)) as k
      union
      select jsonb_object_keys(coalesce(p_new, '{}'::jsonb)) as k
    ) keys
  loop
    v_old_val := case when p_old is null then null else p_old ->> v_key end;
    v_new_val := case when p_new is null then null else p_new ->> v_key end;
    if v_old_val is distinct from v_new_val then
      insert into public.audit_log
        (entity_type, entity_id, field_name, old_value, new_value, reason, changed_by_user_id)
      values
        (p_entity_type, p_entity_id, v_key, v_old_val, v_new_val, p_reason, v_actor);
    end if;
  end loop;
end;
$$;


--
-- Name: FUNCTION write_audit(p_entity_type text, p_entity_id uuid, p_old jsonb, p_new jsonb, p_reason text, p_actor_id uuid); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION public.write_audit(p_entity_type text, p_entity_id uuid, p_old jsonb, p_new jsonb, p_reason text, p_actor_id uuid) IS 'Per-field diff into audit_log. Pass jsonb_build_object(...) for p_old/p_new. NULL p_old = insert; NULL p_new = delete; both set = update. Caller must be a SECURITY DEFINER function (otherwise auth.uid() resolves to the client and the table-grant revoke applies).';


--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.custom_oauth_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_type text NOT NULL,
    identifier text NOT NULL,
    name text NOT NULL,
    client_id text NOT NULL,
    client_secret text NOT NULL,
    acceptable_client_ids text[] DEFAULT '{}'::text[] NOT NULL,
    scopes text[] DEFAULT '{}'::text[] NOT NULL,
    pkce_enabled boolean DEFAULT true NOT NULL,
    attribute_mapping jsonb DEFAULT '{}'::jsonb NOT NULL,
    authorization_params jsonb DEFAULT '{}'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    email_optional boolean DEFAULT false NOT NULL,
    issuer text,
    discovery_url text,
    skip_nonce_check boolean DEFAULT false NOT NULL,
    cached_discovery jsonb,
    discovery_cached_at timestamp with time zone,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT custom_oauth_providers_authorization_url_https CHECK (((authorization_url IS NULL) OR (authorization_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_authorization_url_length CHECK (((authorization_url IS NULL) OR (char_length(authorization_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_client_id_length CHECK (((char_length(client_id) >= 1) AND (char_length(client_id) <= 512))),
    CONSTRAINT custom_oauth_providers_discovery_url_length CHECK (((discovery_url IS NULL) OR (char_length(discovery_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_identifier_format CHECK ((identifier ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::text)),
    CONSTRAINT custom_oauth_providers_issuer_length CHECK (((issuer IS NULL) OR ((char_length(issuer) >= 1) AND (char_length(issuer) <= 2048)))),
    CONSTRAINT custom_oauth_providers_jwks_uri_https CHECK (((jwks_uri IS NULL) OR (jwks_uri ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_jwks_uri_length CHECK (((jwks_uri IS NULL) OR (char_length(jwks_uri) <= 2048))),
    CONSTRAINT custom_oauth_providers_name_length CHECK (((char_length(name) >= 1) AND (char_length(name) <= 100))),
    CONSTRAINT custom_oauth_providers_oauth2_requires_endpoints CHECK (((provider_type <> 'oauth2'::text) OR ((authorization_url IS NOT NULL) AND (token_url IS NOT NULL) AND (userinfo_url IS NOT NULL)))),
    CONSTRAINT custom_oauth_providers_oidc_discovery_url_https CHECK (((provider_type <> 'oidc'::text) OR (discovery_url IS NULL) OR (discovery_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_issuer_https CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NULL) OR (issuer ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_oidc_requires_issuer CHECK (((provider_type <> 'oidc'::text) OR (issuer IS NOT NULL))),
    CONSTRAINT custom_oauth_providers_provider_type_check CHECK ((provider_type = ANY (ARRAY['oauth2'::text, 'oidc'::text]))),
    CONSTRAINT custom_oauth_providers_token_url_https CHECK (((token_url IS NULL) OR (token_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_token_url_length CHECK (((token_url IS NULL) OR (char_length(token_url) <= 2048))),
    CONSTRAINT custom_oauth_providers_userinfo_url_https CHECK (((userinfo_url IS NULL) OR (userinfo_url ~~ 'https://%'::text))),
    CONSTRAINT custom_oauth_providers_userinfo_url_length CHECK (((userinfo_url IS NULL) OR (char_length(userinfo_url) <= 2048)))
);


--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text,
    code_challenge_method auth.code_challenge_method,
    code_challenge text,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone,
    invite_token text,
    referrer text,
    oauth_client_state_id uuid,
    linking_target_id uuid,
    email_optional boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid,
    last_webauthn_challenge_data jsonb
);


--
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- Name: COLUMN mfa_factors.last_webauthn_challenge_data; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.mfa_factors.last_webauthn_challenge_data IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_authorizations (
    id uuid NOT NULL,
    authorization_id text NOT NULL,
    client_id uuid NOT NULL,
    user_id uuid,
    redirect_uri text NOT NULL,
    scope text NOT NULL,
    state text,
    resource text,
    code_challenge text,
    code_challenge_method auth.code_challenge_method,
    response_type auth.oauth_response_type DEFAULT 'code'::auth.oauth_response_type NOT NULL,
    status auth.oauth_authorization_status DEFAULT 'pending'::auth.oauth_authorization_status NOT NULL,
    authorization_code text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:03:00'::interval) NOT NULL,
    approved_at timestamp with time zone,
    nonce text,
    CONSTRAINT oauth_authorizations_authorization_code_length CHECK ((char_length(authorization_code) <= 255)),
    CONSTRAINT oauth_authorizations_code_challenge_length CHECK ((char_length(code_challenge) <= 128)),
    CONSTRAINT oauth_authorizations_expires_at_future CHECK ((expires_at > created_at)),
    CONSTRAINT oauth_authorizations_nonce_length CHECK ((char_length(nonce) <= 255)),
    CONSTRAINT oauth_authorizations_redirect_uri_length CHECK ((char_length(redirect_uri) <= 2048)),
    CONSTRAINT oauth_authorizations_resource_length CHECK ((char_length(resource) <= 2048)),
    CONSTRAINT oauth_authorizations_scope_length CHECK ((char_length(scope) <= 4096)),
    CONSTRAINT oauth_authorizations_state_length CHECK ((char_length(state) <= 4096))
);


--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_client_states (
    id uuid NOT NULL,
    provider_type text NOT NULL,
    code_verifier text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE oauth_client_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.oauth_client_states IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_secret_hash text,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    client_type auth.oauth_client_type DEFAULT 'confidential'::auth.oauth_client_type NOT NULL,
    token_endpoint_auth_method text NOT NULL,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048)),
    CONSTRAINT oauth_clients_token_endpoint_auth_method_check CHECK ((token_endpoint_auth_method = ANY (ARRAY['client_secret_basic'::text, 'client_secret_post'::text, 'none'::text])))
);


--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    client_id uuid NOT NULL,
    scopes text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT oauth_consents_revoked_after_granted CHECK (((revoked_at IS NULL) OR (revoked_at >= granted_at))),
    CONSTRAINT oauth_consents_scopes_length CHECK ((char_length(scopes) <= 2048)),
    CONSTRAINT oauth_consents_scopes_not_empty CHECK ((char_length(TRIM(BOTH FROM scopes)) > 0))
);


--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text,
    oauth_client_id uuid,
    refresh_token_hmac_key text,
    refresh_token_counter bigint,
    scopes text,
    CONSTRAINT sessions_scopes_length CHECK ((char_length(scopes) <= 4096))
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN sessions.refresh_token_hmac_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_hmac_key IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN sessions.refresh_token_counter; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.refresh_token_counter IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    challenge_type text NOT NULL,
    session_data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT webauthn_challenges_challenge_type_check CHECK ((challenge_type = ANY (ARRAY['signup'::text, 'registration'::text, 'authentication'::text])))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    attestation_type text DEFAULT ''::text NOT NULL,
    aaguid uuid,
    sign_count bigint DEFAULT 0 NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_eligible boolean DEFAULT false NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    friendly_name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: delivery_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    delivery_id uuid NOT NULL,
    product_catalog_id uuid NOT NULL,
    quantity_ordered integer NOT NULL,
    quantity_delivered integer,
    customer_price numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT delivery_items_quantity_delivered_check CHECK ((quantity_delivered >= 0)),
    CONSTRAINT delivery_items_quantity_ordered_check CHECK ((quantity_ordered > 0))
);


--
-- Name: TABLE delivery_items; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.delivery_items IS 'Line items for a delivery (Feature A). One delivery (envelope, one fee) holds N items (product + qty). customer_price is record-keeping only and never feeds fee math.';


--
-- Name: delivery_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_status_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    delivery_id uuid NOT NULL,
    changed_by_user_id uuid NOT NULL,
    from_status text,
    to_status text NOT NULL,
    reason text,
    notes text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    effective_at timestamp with time zone DEFAULT now() NOT NULL,
    client_uuid text NOT NULL,
    reported_occurred_at timestamp with time zone
);


--
-- Name: TABLE delivery_status_history; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.delivery_status_history IS 'Immutable audit trail. Inserts only. Updates/deletes blocked by trigger.';


--
-- Name: COLUMN delivery_status_history.effective_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.delivery_status_history.effective_at IS 'When the user said the event actually happened. Defaults to changed_at. Used for operational reporting.';


--
-- Name: COLUMN delivery_status_history.client_uuid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.delivery_status_history.client_uuid IS 'Client-generated UUID for idempotent retries.';


--
-- Name: COLUMN delivery_status_history.reported_occurred_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.delivery_status_history.reported_occurred_at IS 'Explicit client occurrence claim. NULL means unknown, including pre-migration history. effective_at may contain a legacy server fallback.';


--
-- Name: _delivery_rate_base; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public._delivery_rate_base AS
 SELECT d.id,
    d.scheduled_date,
        CASE
            WHEN ((public._norm_phone(d.customer_phone) IS NULL) OR (d.scheduled_date IS NULL)) THEN ('solo:'::text || (d.id)::text)
            WHEN (
            CASE
                WHEN (COALESCE(it.item_count, (0)::bigint) > 0) THEN it.item_sig
                WHEN (d.product_catalog_id IS NOT NULL) THEN (((d.product_catalog_id)::text || ':'::text) || (COALESCE(d.quantity_ordered, 0))::text)
                ELSE NULL::text
            END IS NULL) THEN ('solo:'::text || (d.id)::text)
            ELSE md5(((((((public._norm_phone(d.customer_phone) || '|'::text) ||
            CASE
                WHEN (COALESCE(it.item_count, (0)::bigint) > 0) THEN it.item_sig
                ELSE (((d.product_catalog_id)::text || ':'::text) || (COALESCE(d.quantity_ordered, 0))::text)
            END) || '|'::text) || (d.scheduled_date)::text) || '|'::text) || TRIM(BOTH FROM regexp_replace(regexp_replace(lower(COALESCE(d.raw_address, ''::text)), '[^a-z0-9 ]+'::text, ' '::text, 'g'::text), '\s+'::text, ' '::text, 'g'::text))))
        END AS sibling_group_key,
    (d.current_status = 'delivered'::text) AS is_delivered,
    ((d.current_status = 'delivered'::text) OR (EXISTS ( SELECT 1
           FROM public.delivery_status_history h
          WHERE ((h.delivery_id = d.id) AND (h.to_status = ANY (ARRAY['available'::text, 'available_evening'::text])))))) AS is_available
   FROM (public.deliveries d
     LEFT JOIN LATERAL ( SELECT count(*) AS item_count,
            string_agg((((di.product_catalog_id)::text || ':'::text) || (di.quantity_ordered)::text), '|'::text ORDER BY (((di.product_catalog_id)::text || ':'::text) || (di.quantity_ordered)::text)) AS item_sig
           FROM public.delivery_items di
          WHERE (di.delivery_id = d.id)) it ON (true))
  WHERE ((d.deleted_at IS NULL) AND (d.order_type = 'delivery'::text));


--
-- Name: address_match_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.address_match_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    delivery_id uuid,
    raw_address text NOT NULL,
    maps_response jsonb,
    gemini_response jsonb,
    matched_location_id uuid,
    confidence text,
    was_overridden boolean DEFAULT false NOT NULL,
    override_location_id uuid,
    corrected_by_user_id uuid,
    matched_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT address_match_log_confidence_check CHECK ((confidence = ANY (ARRAY['high'::text, 'medium'::text, 'low'::text, 'none'::text])))
);


--
-- Name: TABLE address_match_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.address_match_log IS 'AI address normalization log. Used for accuracy analysis and potential fine-tuning.';


--
-- Name: agent_departures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_departures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    depart_date date NOT NULL,
    departed_at timestamp with time zone DEFAULT now() NOT NULL,
    departed_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agent_location_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_location_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_profile_id uuid NOT NULL,
    location_id uuid NOT NULL,
    priority_score integer DEFAULT 50 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_location_preferences_priority_score_check CHECK (((priority_score >= 0) AND (priority_score <= 100)))
);


--
-- Name: COLUMN agent_location_preferences.priority_score; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.agent_location_preferences.priority_score IS '0-100. Higher = stronger preference. 50 = neutral. Used in auto-assignment.';


--
-- Name: agent_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_locations (
    agent_id uuid NOT NULL,
    location_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by_user_id uuid,
    kind text DEFAULT 'preferred'::text NOT NULL,
    CONSTRAINT agent_locations_kind_check CHECK ((kind = ANY (ARRAY['preferred'::text, 'avoid'::text])))
);


--
-- Name: agent_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    delivery_capacity integer DEFAULT 20 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_profiles_delivery_capacity_check CHECK ((delivery_capacity > 0))
);


--
-- Name: COLUMN agent_profiles.delivery_capacity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.agent_profiles.delivery_capacity IS 'Soft limit on concurrent pending deliveries. Used in auto-assignment scoring.';


--
-- Name: agent_stock_count_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_stock_count_submissions (
    batch_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    week_ending date NOT NULL,
    counted_at timestamp with time zone DEFAULT now() NOT NULL,
    note text,
    items_count integer NOT NULL,
    off_count integer NOT NULL,
    items jsonb NOT NULL,
    CONSTRAINT agent_stock_count_submissions_week_ending_check CHECK ((EXTRACT(dow FROM week_ending) = (6)::numeric))
);


--
-- Name: ai_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ai_config (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by_user_id uuid
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    field_name text NOT NULL,
    old_value text,
    new_value text,
    changed_by_user_id uuid NOT NULL,
    reason text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_log IS 'General field-change audit. Polymorphic via entity_type + entity_id.';


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    notes text,
    contact_phone text,
    contact_email text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    max_charge_per_delivery numeric,
    auto_cancel_soft_fails boolean DEFAULT false NOT NULL,
    bank_account_name text,
    bank_account_number text,
    bank_name text,
    CONSTRAINT clients_max_charge_per_delivery_nonneg CHECK (((max_charge_per_delivery IS NULL) OR (max_charge_per_delivery >= (0)::numeric)))
);


--
-- Name: COLUMN clients.notes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clients.notes IS 'Free-form rules and instructions. Displayed prominently on agent delivery screen.';


--
-- Name: COLUMN clients.auto_cancel_soft_fails; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clients.auto_cancel_soft_fails IS 'Per-client EOD policy. When true, deliveries in customer-unreachable soft-failure statuses are transitioned to failed_delivery at EOD instead of being rolled forward. Set for clients that prefer the order to die rather than carry. Customer-deferral statuses (tomorrow/postponed/will_call_back/follow_up) and logistics-in-progress statuses (picked_up/waybilled) are NOT affected — they keep rolling.';


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    aliases text[],
    latitude numeric(10,7),
    longitude numeric(10,7),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: COLUMN locations.aliases; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.locations.aliases IS 'Alternative names. AI normalization can match against these.';


--
-- Name: product_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_catalog (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_id uuid NOT NULL,
    product_name text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    aliases text[]
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    phone text,
    display_name text NOT NULL,
    role text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deactivated_at timestamp with time zone,
    notes text,
    expo_push_token text,
    agent_payment_bonus numeric DEFAULT 0 NOT NULL,
    parent_agent_id uuid,
    warehouse_id uuid,
    CONSTRAINT users_agent_payment_bonus_nonneg CHECK ((agent_payment_bonus >= (0)::numeric)),
    CONSTRAINT users_no_self_parent CHECK (((parent_agent_id IS NULL) OR (parent_agent_id <> id))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'dispatcher'::text, 'agent'::text, 'warehouse'::text, 'rep'::text]))),
    CONSTRAINT users_warehouse_staff_sanity CHECK ((((warehouse_id IS NULL) OR (warehouse_id <> id)) AND ((warehouse_id IS NULL) OR (role = 'warehouse'::text))))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'Application users. The "warehouse" role is a single special row representing Reda warehouse stock.';


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.role IS 'admin | dispatcher | agent | warehouse';


--
-- Name: COLUMN users.parent_agent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.parent_agent_id IS 'Lead agent for this user. Sub-agents report to a lead and are excluded from auto-assign; their lead receives the assignment and reassigns manually. Self-reference is rejected.';


--
-- Name: COLUMN users.warehouse_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.warehouse_id IS 'For role=warehouse users: NULL = this user IS a warehouse place (stock holder); NOT NULL = staff member who acts on the linked place''s books (per-person audit, one set of books).';


--
-- Name: available_orders_safe; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.available_orders_safe AS
 SELECT d.id AS delivery_id,
    d.assigned_agent_id AS agent_id,
    u.display_name AS agent_name,
    d.client_id,
    c.name AS client_name,
    di.product_catalog_id,
    p.product_name,
    di.quantity_ordered,
    d.customer_name,
    d.location_id,
    l.name AS location_name,
    d.scheduled_date,
    d.current_status,
    d.bot_raw_message,
    (d.bot_raw_message IS NOT NULL) AS has_raw_message
   FROM (((((public.deliveries d
     JOIN public.users u ON ((u.id = d.assigned_agent_id)))
     JOIN public.clients c ON ((c.id = d.client_id)))
     JOIN public.delivery_items di ON ((di.delivery_id = d.id)))
     JOIN public.product_catalog p ON ((p.id = di.product_catalog_id)))
     LEFT JOIN public.locations l ON ((l.id = d.location_id)))
  WHERE ((d.deleted_at IS NULL) AND (d.current_status = ANY (ARRAY['available'::text, 'available_evening'::text])) AND (d.assigned_agent_id IS NOT NULL) AND (public.is_admin_or_dispatcher() OR public.is_warehouse() OR (d.assigned_agent_id = auth.uid())));


--
-- Name: bot_inbound_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bot_inbound_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wasender_message_id text NOT NULL,
    remote_jid text,
    raw_payload jsonb NOT NULL,
    raw_text text,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone,
    status text DEFAULT 'queued'::text NOT NULL,
    parse_result jsonb,
    delivery_id uuid,
    error_text text,
    CONSTRAINT bot_inbound_messages_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'parsed'::text, 'shadow_only'::text, 'needs_review'::text, 'created_delivery'::text, 'duplicate'::text, 'error'::text, 'blocked'::text])))
);


--
-- Name: client_balance_openings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_balance_openings (
    client_id uuid NOT NULL,
    effective_date date NOT NULL,
    opening_balance numeric DEFAULT 0 NOT NULL,
    note text,
    setup_request_uuid text NOT NULL,
    set_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: replacement_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replacement_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    delivery_id uuid NOT NULL,
    client_uuid text NOT NULL,
    outcome text NOT NULL,
    status_after text NOT NULL,
    notes text,
    next_attempt_date date,
    client_charge numeric DEFAULT 0 NOT NULL,
    agent_payment numeric DEFAULT 0 NOT NULL,
    assigned_agent_id uuid NOT NULL,
    attempted_by_user_id uuid NOT NULL,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_paid numeric DEFAULT 0 NOT NULL,
    payment_method text,
    payment_received_by text,
    cash_pos_fee numeric DEFAULT 0 NOT NULL,
    CONSTRAINT replacement_attempts_agent_payment_check CHECK ((agent_payment >= (0)::numeric)),
    CONSTRAINT replacement_attempts_cash_pos_fee_check CHECK ((cash_pos_fee >= (0)::numeric)),
    CONSTRAINT replacement_attempts_client_charge_check CHECK ((client_charge >= (0)::numeric)),
    CONSTRAINT replacement_attempts_customer_paid_check CHECK (((customer_paid >= (0)::numeric) AND (customer_paid < 'Infinity'::numeric))),
    CONSTRAINT replacement_attempts_outcome_check CHECK ((outcome = ANY (ARRAY['completed'::text, 'customer_unreachable'::text, 'customer_postponed'::text, 'details_incorrect'::text, 'customer_rejected'::text, 'cancelled'::text, 'other'::text]))),
    CONSTRAINT replacement_payment_valid CHECK ((((customer_paid = (0)::numeric) AND (payment_method IS NULL) AND (payment_received_by IS NULL) AND (cash_pos_fee = (0)::numeric)) OR ((customer_paid = (0)::numeric) AND (payment_method = 'vendor_direct'::text) AND (payment_received_by IS NULL) AND (cash_pos_fee = (0)::numeric)) OR ((customer_paid > (0)::numeric) AND (payment_method = 'transfer'::text) AND (payment_received_by = ANY (ARRAY['rider'::text, 'reda'::text])) AND (cash_pos_fee = (0)::numeric)) OR ((customer_paid > (0)::numeric) AND (payment_method = 'cash'::text) AND (payment_received_by = ANY (ARRAY['rider'::text, 'reda'::text])) AND (cash_pos_fee = (500)::numeric))))
);


--
-- Name: client_financial_activity; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.client_financial_activity AS
 SELECT d.client_id,
    d.scheduled_date AS activity_date,
    'delivery'::text AS entry_type,
    d.id AS entry_id,
    ((COALESCE(d.paid, (0)::numeric) - COALESCE(d.charged_snapshot, (0)::numeric)) - COALESCE(d.cash_pos_fee_snapshot, (0)::numeric)) AS amount
   FROM public.deliveries d
  WHERE ((d.current_status = 'delivered'::text) AND (d.deleted_at IS NULL) AND (COALESCE(d.order_type, 'delivery'::text) <> 'replacement'::text))
UNION ALL
 SELECT d.client_id,
    ((a.attempted_at AT TIME ZONE 'Africa/Lagos'::text))::date AS activity_date,
    'replacement_attempt'::text AS entry_type,
    a.id AS entry_id,
    ((a.customer_paid - a.client_charge) - a.cash_pos_fee) AS amount
   FROM (public.replacement_attempts a
     JOIN public.deliveries d ON ((d.id = a.delivery_id)))
  WHERE (d.deleted_at IS NULL);


--
-- Name: client_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_uuid text NOT NULL,
    client_id uuid NOT NULL,
    payment_date date NOT NULL,
    amount numeric NOT NULL,
    balance_before numeric NOT NULL,
    balance_after numeric NOT NULL,
    note text,
    received_by uuid NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    voided_at timestamp with time zone,
    voided_by uuid,
    void_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_payments_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: client_payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_payouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_uuid text NOT NULL,
    client_id uuid NOT NULL,
    payout_date date NOT NULL,
    amount numeric NOT NULL,
    balance_before numeric NOT NULL,
    balance_after numeric NOT NULL,
    note text,
    paid_by uuid NOT NULL,
    paid_at timestamp with time zone DEFAULT now() NOT NULL,
    voided_at timestamp with time zone,
    voided_by uuid,
    void_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT client_payouts_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: stock_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    product_catalog_id uuid NOT NULL,
    quantity_delta integer NOT NULL,
    reason text NOT NULL,
    notes text,
    related_adjustment_id uuid,
    created_by_user_id uuid NOT NULL,
    client_uuid text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    delivery_id uuid,
    CONSTRAINT stock_adjustments_quantity_delta_check CHECK ((quantity_delta <> 0)),
    CONSTRAINT stock_adjustments_reason_check CHECK ((reason = ANY (ARRAY['loss'::text, 'theft'::text, 'damaged'::text, 'found'::text, 'correction'::text, 'transfer'::text, 'warehouse_return'::text, 'warehouse_issue'::text, 'bulk_intake'::text, 'delivered'::text, 'delivery_returned'::text, 'replacement_outbound'::text, 'replacement_return_accepted'::text])))
);


--
-- Name: TABLE stock_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.stock_adjustments IS 'Non-delivery stock movements. quantity_delta is signed. Paired transfers link via related_adjustment_id.';


--
-- Name: COLUMN stock_adjustments.agent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_adjustments.agent_id IS 'User holding the stock. Can be a real agent or the special warehouse user.';


--
-- Name: current_stock; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.current_stock AS
 SELECT agent_id,
    product_catalog_id,
    sum(quantity_delta) AS quantity_on_hand
   FROM public.stock_adjustments
  GROUP BY agent_id, product_catalog_id
 HAVING (sum(quantity_delta) <> 0);


--
-- Name: VIEW current_stock; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.current_stock IS 'Current stock per (agent, product). Runs as querying user, respects RLS.';


--
-- Name: current_stock_parity_baseline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.current_stock_parity_baseline (
    agent_id uuid,
    product_catalog_id uuid,
    quantity_on_hand bigint
);


--
-- Name: TABLE current_stock_parity_baseline; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.current_stock_parity_baseline IS 'Frozen current_stock snapshot taken at Feature A Phase 1, before any view change. Phase 3 asserts the items-based current_stock is byte-identical to this. Drop after Phase 4 sign-off.';


--
-- Name: delivery_client_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_client_notifications (
    status_history_id uuid NOT NULL,
    delivery_id uuid NOT NULL,
    notified_by_user_id uuid NOT NULL,
    notified_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deliveries_admin; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.deliveries_admin AS
 SELECT d.id,
    d.client_id,
    d.product_catalog_id,
    d.location_id,
    d.assigned_agent_id,
    d.parent_delivery_id,
    d.customer_name,
    d.customer_phone,
    d.raw_address,
    d.quantity_ordered,
    d.quantity_delivered,
    d.customer_price,
    d.paid,
    d.payment_method,
    d.charged_snapshot,
    d.agent_payment_snapshot,
    d.current_status,
    d.created_date,
    d.scheduled_date,
    d.created_by_user_id,
    d.created_via,
    d.bot_raw_message,
    d.created_at,
    d.updated_at,
    d.deleted_at,
    (COALESCE(d.charged_snapshot, (0)::numeric) - COALESCE(d.agent_payment_snapshot, (0)::numeric)) AS margin,
    lh.id AS latest_history_id,
    lh.changed_at AS latest_changed_at,
    (ln.status_history_id IS NOT NULL) AS latest_notified,
    d.customer_phone_alt,
    lm.created_at AS latest_message_at,
    d.rolled_from_status,
    d.rolled_from_date,
    d.rollover_count,
    d.delivery_instructions,
    d.assigned_at,
    d.order_type,
    GREATEST(d.created_at, lh.changed_at, lm.created_at, d.assigned_at) AS activity_at,
    COALESCE(it.item_count, (0)::bigint) AS item_count,
        CASE
            WHEN (COALESCE(it.item_count, (0)::bigint) > 1) THEN ((it.item_count)::text || ' items'::text)
            WHEN (it.item_count = 1) THEN COALESCE(it.first_item_name, 'Product'::text)
            ELSE COALESCE(lpc.product_name, '—'::text)
        END AS product_label,
        CASE
            WHEN ((public._norm_phone(d.customer_phone) IS NULL) OR (d.scheduled_date IS NULL)) THEN ('solo:'::text || (d.id)::text)
            WHEN (
            CASE
                WHEN (COALESCE(it.item_count, (0)::bigint) > 0) THEN it.item_sig
                WHEN (d.product_catalog_id IS NOT NULL) THEN (((d.product_catalog_id)::text || ':'::text) || (COALESCE(d.quantity_ordered, 0))::text)
                ELSE NULL::text
            END IS NULL) THEN ('solo:'::text || (d.id)::text)
            ELSE md5(((((((public._norm_phone(d.customer_phone) || '|'::text) ||
            CASE
                WHEN (COALESCE(it.item_count, (0)::bigint) > 0) THEN it.item_sig
                ELSE (((d.product_catalog_id)::text || ':'::text) || (COALESCE(d.quantity_ordered, 0))::text)
            END) || '|'::text) || (d.scheduled_date)::text) || '|'::text) || TRIM(BOTH FROM regexp_replace(regexp_replace(lower(COALESCE(d.raw_address, ''::text)), '[^a-z0-9 ]+'::text, ' '::text, 'g'::text), '\s+'::text, ' '::text, 'g'::text))))
        END AS sibling_group_key
   FROM (((((public.deliveries d
     LEFT JOIN LATERAL ( SELECT h.id,
            h.changed_at
           FROM public.delivery_status_history h
          WHERE (h.delivery_id = d.id)
          ORDER BY h.changed_at DESC
         LIMIT 1) lh ON (true))
     LEFT JOIN public.delivery_client_notifications ln ON ((ln.status_history_id = lh.id)))
     LEFT JOIN LATERAL ( SELECT m.created_at
           FROM public.delivery_messages m
          WHERE (m.delivery_id = d.id)
          ORDER BY m.created_at DESC
         LIMIT 1) lm ON (true))
     LEFT JOIN LATERAL ( SELECT count(*) AS item_count,
            string_agg((((di.product_catalog_id)::text || ':'::text) || (di.quantity_ordered)::text), '|'::text ORDER BY (((di.product_catalog_id)::text || ':'::text) || (di.quantity_ordered)::text)) AS item_sig,
            (array_agg(pc.product_name ORDER BY di.created_at))[1] AS first_item_name
           FROM (public.delivery_items di
             LEFT JOIN public.product_catalog pc ON ((pc.id = di.product_catalog_id)))
          WHERE (di.delivery_id = d.id)) it ON (true))
     LEFT JOIN public.product_catalog lpc ON ((lpc.id = d.product_catalog_id)))
  WHERE (public.is_admin() AND (d.deleted_at IS NULL));


--
-- Name: VIEW deliveries_admin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.deliveries_admin IS 'Full delivery row including charged_snapshot, agent_payment_snapshot, and computed margin. Hard-gated to is_admin(). Excludes soft-deleted rows.';


--
-- Name: deliveries_safe; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.deliveries_safe AS
 SELECT d.id,
    d.client_id,
    d.product_catalog_id,
    d.location_id,
    d.customer_name,
    d.customer_phone,
    d.raw_address,
    d.quantity_ordered,
    d.quantity_delivered,
    d.customer_price,
    d.paid,
    d.payment_method,
        CASE
            WHEN (d.assigned_agent_id = auth.uid()) THEN d.agent_payment_snapshot
            ELSE NULL::numeric
        END AS agent_payment_snapshot,
    d.assigned_agent_id,
    d.created_by_user_id,
    d.current_status,
    d.bot_raw_message,
    d.created_via,
    d.parent_delivery_id,
    d.scheduled_date,
    d.created_date,
    d.created_at,
    d.updated_at,
    lh.id AS latest_history_id,
    lh.changed_at AS latest_changed_at,
    (ln.status_history_id IS NOT NULL) AS latest_notified,
    d.customer_phone_alt,
    lm.created_at AS latest_message_at,
    d.rolled_from_status,
    d.rolled_from_date,
    d.rollover_count,
    d.delivery_instructions,
    d.assigned_at,
    d.order_type,
    GREATEST(d.created_at, lh.changed_at, lm.created_at, d.assigned_at) AS activity_at,
    COALESCE(it.item_count, (0)::bigint) AS item_count,
        CASE
            WHEN (COALESCE(it.item_count, (0)::bigint) > 1) THEN ((it.item_count)::text || ' items'::text)
            WHEN (it.item_count = 1) THEN COALESCE(it.first_item_name, 'Product'::text)
            ELSE COALESCE(lpc.product_name, '—'::text)
        END AS product_label,
        CASE
            WHEN ((public._norm_phone(d.customer_phone) IS NULL) OR (d.scheduled_date IS NULL)) THEN ('solo:'::text || (d.id)::text)
            WHEN (
            CASE
                WHEN (COALESCE(it.item_count, (0)::bigint) > 0) THEN it.item_sig
                WHEN (d.product_catalog_id IS NOT NULL) THEN (((d.product_catalog_id)::text || ':'::text) || (COALESCE(d.quantity_ordered, 0))::text)
                ELSE NULL::text
            END IS NULL) THEN ('solo:'::text || (d.id)::text)
            ELSE md5(((((((public._norm_phone(d.customer_phone) || '|'::text) ||
            CASE
                WHEN (COALESCE(it.item_count, (0)::bigint) > 0) THEN it.item_sig
                ELSE (((d.product_catalog_id)::text || ':'::text) || (COALESCE(d.quantity_ordered, 0))::text)
            END) || '|'::text) || (d.scheduled_date)::text) || '|'::text) || TRIM(BOTH FROM regexp_replace(regexp_replace(lower(COALESCE(d.raw_address, ''::text)), '[^a-z0-9 ]+'::text, ' '::text, 'g'::text), '\s+'::text, ' '::text, 'g'::text))))
        END AS sibling_group_key
   FROM (((((public.deliveries d
     LEFT JOIN LATERAL ( SELECT h.id,
            h.changed_at
           FROM public.delivery_status_history h
          WHERE (h.delivery_id = d.id)
          ORDER BY h.changed_at DESC
         LIMIT 1) lh ON (true))
     LEFT JOIN public.delivery_client_notifications ln ON ((ln.status_history_id = lh.id)))
     LEFT JOIN LATERAL ( SELECT m.created_at
           FROM public.delivery_messages m
          WHERE (m.delivery_id = d.id)
          ORDER BY m.created_at DESC
         LIMIT 1) lm ON (true))
     LEFT JOIN LATERAL ( SELECT count(*) AS item_count,
            string_agg((((di.product_catalog_id)::text || ':'::text) || (di.quantity_ordered)::text), '|'::text ORDER BY (((di.product_catalog_id)::text || ':'::text) || (di.quantity_ordered)::text)) AS item_sig,
            (array_agg(pc.product_name ORDER BY di.created_at))[1] AS first_item_name
           FROM (public.delivery_items di
             LEFT JOIN public.product_catalog pc ON ((pc.id = di.product_catalog_id)))
          WHERE (di.delivery_id = d.id)) it ON (true))
     LEFT JOIN public.product_catalog lpc ON ((lpc.id = d.product_catalog_id)))
  WHERE ((d.deleted_at IS NULL) AND (public.is_admin_or_dispatcher() OR (d.assigned_agent_id = auth.uid())));


--
-- Name: VIEW deliveries_safe; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON VIEW public.deliveries_safe IS 'Delivery row WITHOUT charged_snapshot or computed margin. agent_payment_snapshot is exposed only to the assigned agent. Used by agent and dispatcher app paths.';


--
-- Name: delivery_followups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_followups (
    delivery_id uuid NOT NULL,
    user_id uuid NOT NULL,
    claimed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: delivery_location_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_location_changes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_uuid text NOT NULL,
    delivery_id uuid NOT NULL,
    requested_by_agent_id uuid NOT NULL,
    from_location_id uuid,
    to_location_id uuid NOT NULL,
    from_charged numeric,
    from_agent_payment numeric,
    to_charged numeric NOT NULL,
    to_agent_payment numeric NOT NULL,
    reason text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    decided_by_user_id uuid,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT delivery_location_changes_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'applied'::text, 'approved'::text, 'rejected'::text, 'reverted'::text])))
);


--
-- Name: delivery_status_defs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_status_defs (
    status text NOT NULL,
    category text NOT NULL,
    label text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    needs_followup boolean DEFAULT false NOT NULL,
    CONSTRAINT delivery_status_defs_category_check CHECK ((category = ANY (ARRAY['initial'::text, 'active'::text, 'soft_failure'::text, 'terminal'::text])))
);


--
-- Name: COLUMN delivery_status_defs.needs_followup; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.delivery_status_defs.needs_followup IS 'true for soft statuses where ops would actively contact the customer (and the I''ll-handle-this claim makes sense). False for logistics-in-progress soft statuses like picked_up / waybilled where the customer is already in motion.';


--
-- Name: delivery_status_transitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delivery_status_transitions (
    from_status text NOT NULL,
    to_status text NOT NULL,
    requires_admin boolean DEFAULT false NOT NULL,
    requires_reason boolean DEFAULT false NOT NULL
);


--
-- Name: edit_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.edit_locks (
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    user_id uuid NOT NULL,
    acquired_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT edit_locks_entity_type_check CHECK ((entity_type = ANY (ARRAY['delivery'::text, 'bot_inbound'::text])))
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_flags (
    key text NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    value jsonb,
    description text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by_user_id uuid
);


--
-- Name: mybot_inbound_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mybot_inbound_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id text NOT NULL,
    from_phone text,
    raw_text text NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    raw_payload jsonb NOT NULL,
    paired_contractor_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    parse_status text DEFAULT 'pending'::text NOT NULL,
    parse_result jsonb,
    processed_at timestamp with time zone,
    error_text text,
    text_fingerprint text GENERATED ALWAYS AS (public._text_fingerprint(raw_text)) STORED,
    CONSTRAINT mybot_inbound_messages_parse_status_check CHECK ((parse_status = ANY (ARRAY['pending'::text, 'parsed'::text, 'error'::text, 'skipped'::text])))
);


--
-- Name: push_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token text NOT NULL,
    platform text,
    device_label text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rate_card; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_card (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    location_id uuid NOT NULL,
    charged numeric(10,2) NOT NULL,
    agent_payment numeric(10,2) NOT NULL,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    effective_until timestamp with time zone,
    created_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT rate_card_agent_payment_check CHECK ((agent_payment >= (0)::numeric)),
    CONSTRAINT rate_card_charged_check CHECK ((charged >= (0)::numeric))
);


--
-- Name: TABLE rate_card; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rate_card IS 'Time-bounded rates. Current rate has effective_until = null. Editing a rate inserts a new row and closes the old one.';


--
-- Name: recent_edge_function_failures; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.recent_edge_function_failures AS
 SELECT id,
    status_code,
    "substring"(content, 1, 200) AS content_preview,
    created
   FROM net._http_response
  WHERE ((status_code IS NULL) OR (status_code >= 400))
  ORDER BY id DESC;


--
-- Name: replacement_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replacement_jobs (
    delivery_id uuid NOT NULL,
    original_delivery_id uuid,
    reason text NOT NULL,
    notes text,
    success_client_charge numeric DEFAULT 0 NOT NULL,
    success_agent_payment numeric DEFAULT 0 NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT replacement_jobs_success_agent_payment_check CHECK ((success_agent_payment >= (0)::numeric)),
    CONSTRAINT replacement_jobs_success_client_charge_check CHECK ((success_client_charge >= (0)::numeric))
);


--
-- Name: replacement_return_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replacement_return_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    client_uuid text NOT NULL,
    return_item_id uuid NOT NULL,
    event_type text NOT NULL,
    from_holder_id uuid,
    to_holder_id uuid,
    quantity integer NOT NULL,
    condition text,
    notes text,
    actor_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT replacement_return_events_condition_check CHECK (((condition IS NULL) OR (condition = ANY (ARRAY['usable'::text, 'damaged'::text, 'unknown'::text])))),
    CONSTRAINT replacement_return_events_event_type_check CHECK ((event_type = ANY (ARRAY['collected'::text, 'not_collected'::text, 'received_and_accepted'::text, 'received_for_vendor'::text, 'rejected_as_damaged'::text, 'discarded'::text, 'returned_to_vendor'::text]))),
    CONSTRAINT replacement_return_events_quantity_check CHECK ((quantity >= 0))
);


--
-- Name: replacement_return_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.replacement_return_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    delivery_id uuid NOT NULL,
    product_catalog_id uuid NOT NULL,
    quantity_expected integer NOT NULL,
    vendor_instruction text DEFAULT 'ask_if_damaged'::text NOT NULL,
    actual_quantity integer,
    reported_condition text,
    outcome text,
    custody_state text DEFAULT 'expected'::text NOT NULL,
    current_holder_id uuid,
    rider_notes text,
    collected_at timestamp with time zone,
    warehouse_received_at timestamp with time zone,
    inspected_by_user_id uuid,
    stock_adjustment_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT replacement_return_items_actual_quantity_check CHECK (((actual_quantity IS NULL) OR (actual_quantity >= 0))),
    CONSTRAINT replacement_return_items_custody_state_check CHECK ((custody_state = ANY (ARRAY['expected'::text, 'with_rider_usable_pending_inspection'::text, 'with_rider_damaged_hold'::text, 'left_with_customer'::text, 'discarded'::text, 'warehouse_accepted_stock'::text, 'warehouse_hold_for_vendor'::text, 'warehouse_rejected_damaged'::text, 'returned_to_vendor'::text]))),
    CONSTRAINT replacement_return_items_outcome_check CHECK (((outcome IS NULL) OR (outcome = ANY (ARRAY['usable_collected'::text, 'damaged_collected'::text, 'left_with_customer'::text, 'discarded'::text])))),
    CONSTRAINT replacement_return_items_quantity_expected_check CHECK ((quantity_expected > 0)),
    CONSTRAINT replacement_return_items_reported_condition_check CHECK (((reported_condition IS NULL) OR (reported_condition = ANY (ARRAY['usable'::text, 'damaged'::text, 'unknown'::text])))),
    CONSTRAINT replacement_return_items_vendor_instruction_check CHECK ((vendor_instruction = ANY (ARRAY['ask_if_damaged'::text, 'collect_and_hold'::text, 'do_not_collect_damaged'::text])))
);


--
-- Name: same_customer_assignment_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_assignment_requests (
    request_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    delivery_ids uuid[] NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: same_customer_completion_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_completion_reviews (
    request_id uuid NOT NULL,
    delivery_id uuid NOT NULL,
    completion_event_id uuid NOT NULL,
    expected_revision bigint NOT NULL,
    accepted_day date NOT NULL,
    reason text NOT NULL,
    actor_id uuid NOT NULL,
    before_value jsonb NOT NULL,
    after_value jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT same_customer_completion_reviews_reason_check CHECK (((length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 2000)))
);


--
-- Name: same_customer_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_decisions (
    request_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    action text NOT NULL,
    delivery_ids uuid[] NOT NULL,
    request_orders jsonb DEFAULT '[]'::jsonb NOT NULL,
    reason text NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT same_customer_decisions_action_check CHECK ((action = ANY (ARRAY['link'::text, 'split'::text, 'reset'::text]))),
    CONSTRAINT same_customer_decisions_reason_check CHECK ((length(btrim(reason)) > 0))
);


--
-- Name: same_customer_earning_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_earning_revisions (
    id bigint NOT NULL,
    delivery_id uuid NOT NULL,
    actor_id uuid,
    old_value jsonb,
    new_value jsonb NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: same_customer_earning_revisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_earning_revisions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.same_customer_earning_revisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: same_customer_earnings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_earnings (
    delivery_id uuid NOT NULL,
    completion_event_id uuid NOT NULL,
    rider_id uuid NOT NULL,
    customer_key text NOT NULL,
    recorded_at timestamp with time zone NOT NULL,
    occurred_at timestamp with time zone,
    business_date date,
    accounting_date date NOT NULL,
    base_fee numeric(12,2),
    multiplier numeric(3,2),
    expected_amount numeric(12,2),
    group_id uuid,
    active boolean DEFAULT true NOT NULL,
    date_review_reason text,
    pay_state text DEFAULT 'pending'::text NOT NULL,
    review_reason text,
    manual_amount numeric(12,2),
    manual_reason text,
    policy_version integer DEFAULT 1 NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    manual_decision_id bigint,
    manual_event_review boolean DEFAULT false NOT NULL,
    policy_applied boolean DEFAULT false NOT NULL,
    legacy_amount numeric(12,2),
    final_amount numeric(12,2),
    final_state text DEFAULT 'shadow'::text NOT NULL,
    final_review_reason text,
    CONSTRAINT same_customer_earnings_check CHECK (((manual_amount IS NULL) = (manual_reason IS NULL))),
    CONSTRAINT same_customer_earnings_check1 CHECK (((pay_state <> 'ready'::text) OR ((expected_amount IS NOT NULL) AND (business_date IS NOT NULL)))),
    CONSTRAINT same_customer_earnings_date_review_reason_check CHECK ((date_review_reason = ANY (ARRAY['date_discrepancy'::text, 'clock_skew'::text, 'missing_occurrence'::text]))),
    CONSTRAINT same_customer_earnings_final_state_check CHECK ((final_state = ANY (ARRAY['shadow'::text, 'legacy'::text, 'ready'::text, 'pending'::text, 'reversed'::text]))),
    CONSTRAINT same_customer_earnings_manual_amount_check CHECK ((manual_amount >= (0)::numeric)),
    CONSTRAINT same_customer_earnings_manual_reason_check CHECK (((manual_reason IS NULL) OR (length(btrim(manual_reason)) > 0))),
    CONSTRAINT same_customer_earnings_pay_state_check CHECK ((pay_state = ANY (ARRAY['ready'::text, 'pending'::text, 'reversed'::text]))),
    CONSTRAINT same_customer_earnings_policy_version_check CHECK ((policy_version = 1))
);


--
-- Name: same_customer_fee_decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_fee_decisions (
    id bigint NOT NULL,
    delivery_id uuid NOT NULL,
    amount numeric(12,2),
    reason text NOT NULL,
    actor_id uuid NOT NULL,
    source text NOT NULL,
    request_id uuid,
    expected_revision bigint,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT same_customer_fee_decisions_amount_check CHECK (((amount IS NULL) OR ((amount >= (0)::numeric) AND ((amount)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text]))))),
    CONSTRAINT same_customer_fee_decisions_reason_check CHECK ((length(btrim(reason)) > 0)),
    CONSTRAINT same_customer_fee_decisions_source_check CHECK ((source = ANY (ARRAY['charge_correction'::text, 'clear_exception'::text])))
);


--
-- Name: same_customer_fee_decisions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_fee_decisions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.same_customer_fee_decisions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: same_customer_manual_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_manual_reviews (
    request_id uuid NOT NULL,
    group_id uuid NOT NULL,
    expected_revision bigint NOT NULL,
    signature text NOT NULL,
    reason text NOT NULL,
    actor_id uuid NOT NULL,
    reviewed_members jsonb NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT same_customer_manual_reviews_reason_check CHECK (((length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 2000)))
);


--
-- Name: same_customer_normal_fee_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_normal_fee_reviews (
    request_id uuid NOT NULL,
    delivery_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    completion_event_id uuid NOT NULL,
    expected_revision bigint NOT NULL,
    normal_fee numeric(10,2) NOT NULL,
    reason text NOT NULL,
    before_value jsonb NOT NULL,
    after_value jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT same_customer_normal_fee_reviews_normal_fee_check CHECK (((normal_fee >= (0)::numeric) AND ((normal_fee)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])))),
    CONSTRAINT same_customer_normal_fee_reviews_reason_check CHECK (((length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 2000)))
);


--
-- Name: same_customer_pay_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_pay_groups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rider_id uuid NOT NULL,
    customer_key text NOT NULL,
    business_date date NOT NULL,
    policy_version integer DEFAULT 1 NOT NULL,
    state text DEFAULT 'ready'::text NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    manual_review_signature text,
    CONSTRAINT same_customer_pay_groups_policy_version_check CHECK ((policy_version = 1)),
    CONSTRAINT same_customer_pay_groups_state_check CHECK ((state = ANY (ARRAY['ready'::text, 'rate_mismatch'::text, 'manual_review'::text])))
);


--
-- Name: same_customer_pay_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_pay_policy (
    singleton boolean DEFAULT true NOT NULL,
    active_from date,
    inactive_from date,
    CONSTRAINT same_customer_pay_policy_check CHECK (((inactive_from IS NULL) OR ((active_from IS NOT NULL) AND (inactive_from > active_from)))),
    CONSTRAINT same_customer_pay_policy_singleton_check CHECK (singleton)
);


--
-- Name: same_customer_pay_policy_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_pay_policy_days (
    business_date date NOT NULL,
    enabled boolean NOT NULL,
    policy_version integer DEFAULT 1 NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT same_customer_pay_policy_days_policy_version_check CHECK ((policy_version = 1))
);


--
-- Name: same_customer_policy_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_policy_audit (
    id bigint NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    database_actor text DEFAULT SESSION_USER NOT NULL,
    action text NOT NULL,
    effective_day date NOT NULL,
    release_reference text NOT NULL,
    reason text NOT NULL,
    before_policy jsonb NOT NULL,
    after_policy jsonb NOT NULL,
    CONSTRAINT same_customer_policy_audit_action_check CHECK ((action = ANY (ARRAY['schedule'::text, 'suspend'::text])))
);


--
-- Name: same_customer_policy_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_policy_audit ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.same_customer_policy_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: same_customer_projection_context; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.same_customer_projection_context (
    backend_pid integer NOT NULL,
    transaction_id bigint NOT NULL
);


--
-- Name: settlement_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settlement_batches (
    id uuid NOT NULL,
    period_date date NOT NULL,
    agent_ids uuid[] NOT NULL,
    note text,
    settled_by uuid NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT settlement_batches_agent_ids_nonempty CHECK ((cardinality(agent_ids) > 0))
);


--
-- Name: TABLE settlement_batches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.settlement_batches IS 'Idempotency and grouping record for atomic bulk agent handover settlements.';


--
-- Name: settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settlements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    subject_type text NOT NULL,
    subject_id uuid NOT NULL,
    period_date date NOT NULL,
    settled_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_by uuid NOT NULL,
    expected_amount numeric NOT NULL,
    deliveries_count integer NOT NULL,
    snapshot jsonb NOT NULL,
    note text,
    voided_at timestamp with time zone,
    voided_by uuid,
    void_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT settlements_subject_type_check CHECK ((subject_type = ANY (ARRAY['client'::text, 'agent'::text])))
);


--
-- Name: stock_counts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_counts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id uuid NOT NULL,
    holder_id uuid NOT NULL,
    product_catalog_id uuid NOT NULL,
    expected_qty integer NOT NULL,
    counted_qty integer NOT NULL,
    variance integer NOT NULL,
    counted_by uuid,
    counted_at timestamp with time zone DEFAULT now() NOT NULL,
    note text
);


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_identifier_key UNIQUE (identifier);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_code_key UNIQUE (authorization_code);


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_authorization_id_key UNIQUE (authorization_id);


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_client_states
    ADD CONSTRAINT oauth_client_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_pkey PRIMARY KEY (id);


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_client_unique UNIQUE (user_id, client_id);


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: address_match_log address_match_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_match_log
    ADD CONSTRAINT address_match_log_pkey PRIMARY KEY (id);


--
-- Name: agent_departures agent_departures_agent_id_depart_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_departures
    ADD CONSTRAINT agent_departures_agent_id_depart_date_key UNIQUE (agent_id, depart_date);


--
-- Name: agent_departures agent_departures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_departures
    ADD CONSTRAINT agent_departures_pkey PRIMARY KEY (id);


--
-- Name: agent_location_preferences agent_location_preferences_agent_profile_id_location_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_location_preferences
    ADD CONSTRAINT agent_location_preferences_agent_profile_id_location_id_key UNIQUE (agent_profile_id, location_id);


--
-- Name: agent_location_preferences agent_location_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_location_preferences
    ADD CONSTRAINT agent_location_preferences_pkey PRIMARY KEY (id);


--
-- Name: agent_locations agent_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_locations
    ADD CONSTRAINT agent_locations_pkey PRIMARY KEY (agent_id, location_id);


--
-- Name: agent_profiles agent_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_pkey PRIMARY KEY (id);


--
-- Name: agent_profiles agent_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_user_id_key UNIQUE (user_id);


--
-- Name: agent_stock_count_submissions agent_stock_count_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stock_count_submissions
    ADD CONSTRAINT agent_stock_count_submissions_pkey PRIMARY KEY (batch_id);


--
-- Name: ai_config ai_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_config
    ADD CONSTRAINT ai_config_pkey PRIMARY KEY (key);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bot_inbound_messages bot_inbound_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_inbound_messages
    ADD CONSTRAINT bot_inbound_messages_pkey PRIMARY KEY (id);


--
-- Name: bot_inbound_messages bot_inbound_messages_wasender_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_inbound_messages
    ADD CONSTRAINT bot_inbound_messages_wasender_message_id_key UNIQUE (wasender_message_id);


--
-- Name: calls calls_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_pkey PRIMARY KEY (id);


--
-- Name: client_balance_openings client_balance_openings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_balance_openings
    ADD CONSTRAINT client_balance_openings_pkey PRIMARY KEY (client_id);


--
-- Name: client_balance_openings client_balance_openings_setup_request_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_balance_openings
    ADD CONSTRAINT client_balance_openings_setup_request_uuid_key UNIQUE (setup_request_uuid);


--
-- Name: client_payments client_payments_client_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_client_uuid_key UNIQUE (client_uuid);


--
-- Name: client_payments client_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_pkey PRIMARY KEY (id);


--
-- Name: client_payouts client_payouts_client_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payouts
    ADD CONSTRAINT client_payouts_client_uuid_key UNIQUE (client_uuid);


--
-- Name: client_payouts client_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payouts
    ADD CONSTRAINT client_payouts_pkey PRIMARY KEY (id);


--
-- Name: clients clients_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_name_key UNIQUE (name);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: customer_blacklist customer_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_blacklist
    ADD CONSTRAINT customer_blacklist_pkey PRIMARY KEY (id);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (id);


--
-- Name: delivery_client_notifications delivery_client_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_client_notifications
    ADD CONSTRAINT delivery_client_notifications_pkey PRIMARY KEY (status_history_id);


--
-- Name: delivery_followups delivery_followups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_followups
    ADD CONSTRAINT delivery_followups_pkey PRIMARY KEY (delivery_id);


--
-- Name: delivery_items delivery_items_one_line_per_product; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_one_line_per_product UNIQUE (delivery_id, product_catalog_id);


--
-- Name: delivery_items delivery_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_pkey PRIMARY KEY (id);


--
-- Name: delivery_location_changes delivery_location_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT delivery_location_changes_pkey PRIMARY KEY (id);


--
-- Name: delivery_messages delivery_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_messages
    ADD CONSTRAINT delivery_messages_pkey PRIMARY KEY (id);


--
-- Name: delivery_status_defs delivery_status_defs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_defs
    ADD CONSTRAINT delivery_status_defs_pkey PRIMARY KEY (status);


--
-- Name: delivery_status_history delivery_status_history_client_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_history
    ADD CONSTRAINT delivery_status_history_client_uuid_key UNIQUE (client_uuid);


--
-- Name: delivery_status_history delivery_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_history
    ADD CONSTRAINT delivery_status_history_pkey PRIMARY KEY (id);


--
-- Name: delivery_status_transitions delivery_status_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_transitions
    ADD CONSTRAINT delivery_status_transitions_pkey PRIMARY KEY (from_status, to_status);


--
-- Name: delivery_location_changes dlc_client_uuid_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT dlc_client_uuid_uniq UNIQUE (client_uuid);


--
-- Name: edit_locks edit_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.edit_locks
    ADD CONSTRAINT edit_locks_pkey PRIMARY KEY (entity_type, entity_id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (key);


--
-- Name: locations locations_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_name_key UNIQUE (name);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: mybot_inbound_messages mybot_inbound_messages_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mybot_inbound_messages
    ADD CONSTRAINT mybot_inbound_messages_message_id_key UNIQUE (message_id);


--
-- Name: mybot_inbound_messages mybot_inbound_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mybot_inbound_messages
    ADD CONSTRAINT mybot_inbound_messages_pkey PRIMARY KEY (id);


--
-- Name: product_catalog product_catalog_client_id_product_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_catalog
    ADD CONSTRAINT product_catalog_client_id_product_name_key UNIQUE (client_id, product_name);


--
-- Name: product_catalog product_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_catalog
    ADD CONSTRAINT product_catalog_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_pkey PRIMARY KEY (id);


--
-- Name: push_tokens push_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_token_key UNIQUE (token);


--
-- Name: rate_card rate_card_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_card
    ADD CONSTRAINT rate_card_pkey PRIMARY KEY (id);


--
-- Name: replacement_attempts replacement_attempts_client_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_attempts
    ADD CONSTRAINT replacement_attempts_client_uuid_key UNIQUE (client_uuid);


--
-- Name: replacement_attempts replacement_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_attempts
    ADD CONSTRAINT replacement_attempts_pkey PRIMARY KEY (id);


--
-- Name: replacement_jobs replacement_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_jobs
    ADD CONSTRAINT replacement_jobs_pkey PRIMARY KEY (delivery_id);


--
-- Name: replacement_return_events replacement_return_events_client_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_events
    ADD CONSTRAINT replacement_return_events_client_uuid_key UNIQUE (client_uuid);


--
-- Name: replacement_return_events replacement_return_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_events
    ADD CONSTRAINT replacement_return_events_pkey PRIMARY KEY (id);


--
-- Name: replacement_return_items replacement_return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_items
    ADD CONSTRAINT replacement_return_items_pkey PRIMARY KEY (id);


--
-- Name: same_customer_assignment_requests same_customer_assignment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_assignment_requests
    ADD CONSTRAINT same_customer_assignment_requests_pkey PRIMARY KEY (request_id);


--
-- Name: same_customer_completion_reviews same_customer_completion_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_completion_reviews
    ADD CONSTRAINT same_customer_completion_reviews_pkey PRIMARY KEY (request_id);


--
-- Name: same_customer_decisions same_customer_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_decisions
    ADD CONSTRAINT same_customer_decisions_pkey PRIMARY KEY (request_id);


--
-- Name: same_customer_earning_revisions same_customer_earning_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earning_revisions
    ADD CONSTRAINT same_customer_earning_revisions_pkey PRIMARY KEY (id);


--
-- Name: same_customer_earnings same_customer_earnings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earnings
    ADD CONSTRAINT same_customer_earnings_pkey PRIMARY KEY (delivery_id);


--
-- Name: same_customer_fee_decisions same_customer_fee_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_fee_decisions
    ADD CONSTRAINT same_customer_fee_decisions_pkey PRIMARY KEY (id);


--
-- Name: same_customer_fee_decisions same_customer_fee_decisions_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_fee_decisions
    ADD CONSTRAINT same_customer_fee_decisions_request_id_key UNIQUE (request_id);


--
-- Name: same_customer_manual_reviews same_customer_manual_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_manual_reviews
    ADD CONSTRAINT same_customer_manual_reviews_pkey PRIMARY KEY (request_id);


--
-- Name: same_customer_normal_fee_reviews same_customer_normal_fee_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_normal_fee_reviews
    ADD CONSTRAINT same_customer_normal_fee_reviews_pkey PRIMARY KEY (request_id);


--
-- Name: same_customer_pay_groups same_customer_pay_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_pay_groups
    ADD CONSTRAINT same_customer_pay_groups_pkey PRIMARY KEY (id);


--
-- Name: same_customer_pay_groups same_customer_pay_groups_rider_id_customer_key_business_dat_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_pay_groups
    ADD CONSTRAINT same_customer_pay_groups_rider_id_customer_key_business_dat_key UNIQUE (rider_id, customer_key, business_date, policy_version);


--
-- Name: same_customer_pay_policy_days same_customer_pay_policy_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_pay_policy_days
    ADD CONSTRAINT same_customer_pay_policy_days_pkey PRIMARY KEY (business_date);


--
-- Name: same_customer_pay_policy same_customer_pay_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_pay_policy
    ADD CONSTRAINT same_customer_pay_policy_pkey PRIMARY KEY (singleton);


--
-- Name: same_customer_policy_audit same_customer_policy_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_policy_audit
    ADD CONSTRAINT same_customer_policy_audit_pkey PRIMARY KEY (id);


--
-- Name: same_customer_projection_context same_customer_projection_context_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_projection_context
    ADD CONSTRAINT same_customer_projection_context_pkey PRIMARY KEY (backend_pid, transaction_id);


--
-- Name: settlement_batches settlement_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settlement_batches
    ADD CONSTRAINT settlement_batches_pkey PRIMARY KEY (id);


--
-- Name: settlements settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_pkey PRIMARY KEY (id);


--
-- Name: stock_adjustments stock_adjustments_client_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_client_uuid_key UNIQUE (client_uuid);


--
-- Name: stock_adjustments stock_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_pkey PRIMARY KEY (id);


--
-- Name: stock_counts stock_counts_batch_id_product_catalog_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_batch_id_product_catalog_id_key UNIQUE (batch_id, product_catalog_id);


--
-- Name: stock_counts stock_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_created_at_idx ON auth.custom_oauth_providers USING btree (created_at);


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_enabled_idx ON auth.custom_oauth_providers USING btree (enabled);


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_identifier_idx ON auth.custom_oauth_providers USING btree (identifier);


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX custom_oauth_providers_provider_type_idx ON auth.custom_oauth_providers USING btree (provider_type);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_oauth_client_states_created_at ON auth.oauth_client_states USING btree (created_at);


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_auth_pending_exp_idx ON auth.oauth_authorizations USING btree (expires_at) WHERE (status = 'pending'::auth.oauth_authorization_status);


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_client_idx ON auth.oauth_consents USING btree (client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_active_user_client_idx ON auth.oauth_consents USING btree (user_id, client_id) WHERE (revoked_at IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_consents_user_order_idx ON auth.oauth_consents USING btree (user_id, granted_at DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_oauth_client_id_idx ON auth.sessions USING btree (oauth_client_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_expires_at_idx ON auth.webauthn_challenges USING btree (expires_at);


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_challenges_user_id_idx ON auth.webauthn_challenges USING btree (user_id);


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX webauthn_credentials_credential_id_key ON auth.webauthn_credentials USING btree (credential_id);


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX webauthn_credentials_user_id_idx ON auth.webauthn_credentials USING btree (user_id);


--
-- Name: agent_locations_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_locations_agent_idx ON public.agent_locations USING btree (agent_id);


--
-- Name: agent_locations_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_locations_kind_idx ON public.agent_locations USING btree (agent_id, kind);


--
-- Name: agent_locations_location_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_locations_location_idx ON public.agent_locations USING btree (location_id);


--
-- Name: agent_stock_count_week_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_stock_count_week_idx ON public.agent_stock_count_submissions USING btree (week_ending, agent_id, counted_at DESC);


--
-- Name: bot_inbound_blocked_entry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bot_inbound_blocked_entry_idx ON public.bot_inbound_messages USING btree ((((parse_result -> 'blacklist'::text) ->> 'entry_id'::text))) WHERE (status = 'blocked'::text);


--
-- Name: calls_callee_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calls_callee_status_idx ON public.calls USING btree (callee_id, status);


--
-- Name: calls_caller_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calls_caller_created_idx ON public.calls USING btree (caller_id, created_at DESC);


--
-- Name: calls_client_uuid_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX calls_client_uuid_uniq ON public.calls USING btree (client_uuid) WHERE (client_uuid IS NOT NULL);


--
-- Name: calls_delivery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX calls_delivery_idx ON public.calls USING btree (related_delivery_id) WHERE (related_delivery_id IS NOT NULL);


--
-- Name: calls_one_ringing_per_callee; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX calls_one_ringing_per_callee ON public.calls USING btree (callee_id) WHERE ((status = 'ringing'::text) AND (callee_audience = 'user'::text));


--
-- Name: calls_one_ringing_per_caller; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX calls_one_ringing_per_caller ON public.calls USING btree (caller_id) WHERE (status = 'ringing'::text);


--
-- Name: client_payments_client_date_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_payments_client_date_active ON public.client_payments USING btree (client_id, payment_date, received_at) WHERE (voided_at IS NULL);


--
-- Name: client_payouts_client_date_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX client_payouts_client_date_active ON public.client_payouts USING btree (client_id, payout_date, paid_at) WHERE (voided_at IS NULL);


--
-- Name: customer_blacklist_active_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customer_blacklist_active_phone_idx ON public.customer_blacklist USING btree (phone_normalized) WHERE (removed_at IS NULL);


--
-- Name: customer_blacklist_added_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_blacklist_added_idx ON public.customer_blacklist USING btree (added_at DESC);


--
-- Name: deliveries_client_ledger_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_client_ledger_activity ON public.deliveries USING btree (client_id, scheduled_date) WHERE ((current_status = 'delivered'::text) AND (deleted_at IS NULL));


--
-- Name: deliveries_product_catalog_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_product_catalog_idx ON public.deliveries USING btree (product_catalog_id) WHERE (deleted_at IS NULL);


--
-- Name: deliveries_same_customer_alt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_same_customer_alt_idx ON public.deliveries USING btree (scheduled_date, same_customer_phone_alt) WHERE ((deleted_at IS NULL) AND (order_type = 'delivery'::text) AND (same_customer_phone_alt IS NOT NULL));


--
-- Name: deliveries_same_customer_override_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_same_customer_override_idx ON public.deliveries USING btree (same_customer_key_override, scheduled_date) WHERE ((deleted_at IS NULL) AND (same_customer_key_override IS NOT NULL));


--
-- Name: deliveries_same_customer_primary_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_same_customer_primary_idx ON public.deliveries USING btree (scheduled_date, same_customer_phone) WHERE ((deleted_at IS NULL) AND (order_type = 'delivery'::text) AND (same_customer_phone IS NOT NULL));


--
-- Name: deliveries_sibling_lookup_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX deliveries_sibling_lookup_idx ON public.deliveries USING btree (customer_phone_normalized, product_catalog_id, scheduled_date) WHERE ((customer_phone_normalized IS NOT NULL) AND (deleted_at IS NULL));


--
-- Name: delivery_client_notifications_delivery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_client_notifications_delivery_idx ON public.delivery_client_notifications USING btree (delivery_id);


--
-- Name: delivery_client_notifications_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_client_notifications_user_idx ON public.delivery_client_notifications USING btree (notified_by_user_id);


--
-- Name: delivery_followups_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_followups_user_idx ON public.delivery_followups USING btree (user_id);


--
-- Name: delivery_items_delivery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_items_delivery_idx ON public.delivery_items USING btree (delivery_id);


--
-- Name: delivery_items_product_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_items_product_idx ON public.delivery_items USING btree (product_catalog_id);


--
-- Name: delivery_messages_client_uuid_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX delivery_messages_client_uuid_uniq ON public.delivery_messages USING btree (client_uuid) WHERE (client_uuid IS NOT NULL);


--
-- Name: delivery_messages_delivery_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_messages_delivery_created_idx ON public.delivery_messages USING btree (delivery_id, created_at);


--
-- Name: delivery_messages_unread_from_agent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_messages_unread_from_agent_idx ON public.delivery_messages USING btree (delivery_id) WHERE ((author_role = 'agent'::text) AND (read_at IS NULL));


--
-- Name: delivery_messages_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_messages_unread_idx ON public.delivery_messages USING btree (delivery_id, author_role) WHERE (read_at IS NULL);


--
-- Name: delivery_status_history_failed_outcome_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX delivery_status_history_failed_outcome_idx ON public.delivery_status_history USING btree (to_status, changed_at DESC, delivery_id) WHERE (to_status = ANY (ARRAY['failed_delivery'::text, 'cancelled'::text, 'not_around'::text, 'unserious'::text, 'abandoned'::text]));


--
-- Name: dlc_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dlc_delivery ON public.delivery_location_changes USING btree (delivery_id);


--
-- Name: dlc_one_open_per_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dlc_one_open_per_delivery ON public.delivery_location_changes USING btree (delivery_id) WHERE (state = 'pending'::text);


--
-- Name: dlc_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dlc_pending ON public.delivery_location_changes USING btree (state) WHERE (state = 'pending'::text);


--
-- Name: edit_locks_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX edit_locks_user_idx ON public.edit_locks USING btree (user_id);


--
-- Name: idx_address_match_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_address_match_delivery ON public.address_match_log USING btree (delivery_id);


--
-- Name: idx_agent_departures_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_departures_date ON public.agent_departures USING btree (depart_date, agent_id);


--
-- Name: idx_agent_loc_pref_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_loc_pref_agent ON public.agent_location_preferences USING btree (agent_profile_id);


--
-- Name: idx_agent_loc_pref_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_loc_pref_location ON public.agent_location_preferences USING btree (location_id);


--
-- Name: idx_agent_profiles_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_profiles_user ON public.agent_profiles USING btree (user_id);


--
-- Name: idx_audit_log_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_entity ON public.audit_log USING btree (entity_type, entity_id, changed_at DESC);


--
-- Name: idx_audit_log_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_user ON public.audit_log USING btree (changed_by_user_id, changed_at DESC);


--
-- Name: idx_bot_inbound_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bot_inbound_delivery ON public.bot_inbound_messages USING btree (delivery_id) WHERE (delivery_id IS NOT NULL);


--
-- Name: idx_bot_inbound_received; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bot_inbound_received ON public.bot_inbound_messages USING btree (received_at DESC);


--
-- Name: idx_dcn_notifier_notified_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dcn_notifier_notified_at ON public.delivery_client_notifications USING btree (notified_by_user_id, notified_at);


--
-- Name: idx_deliveries_agent_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_agent_status ON public.deliveries USING btree (assigned_agent_id, current_status) WHERE (deleted_at IS NULL);


--
-- Name: idx_deliveries_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_client ON public.deliveries USING btree (client_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_deliveries_customer_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_customer_name_trgm ON public.deliveries USING gin (customer_name public.gin_trgm_ops);


--
-- Name: idx_deliveries_customer_phone_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_customer_phone_trgm ON public.deliveries USING gin (customer_phone public.gin_trgm_ops);


--
-- Name: idx_deliveries_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_parent ON public.deliveries USING btree (parent_delivery_id);


--
-- Name: idx_deliveries_scheduled_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_scheduled_date ON public.deliveries USING btree (scheduled_date) WHERE (deleted_at IS NULL);


--
-- Name: idx_deliveries_status_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deliveries_status_active ON public.deliveries USING btree (current_status) WHERE (deleted_at IS NULL);


--
-- Name: idx_delivery_status_history_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_delivery_status_history_delivery ON public.delivery_status_history USING btree (delivery_id, changed_at DESC);


--
-- Name: idx_delivery_status_history_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_delivery_status_history_user ON public.delivery_status_history USING btree (changed_by_user_id);


--
-- Name: idx_dm_author_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dm_author_created_at ON public.delivery_messages USING btree (author_id, created_at);


--
-- Name: idx_dsh_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dsh_changed_at ON public.delivery_status_history USING btree (changed_at);


--
-- Name: idx_mybot_inbound_fingerprint; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mybot_inbound_fingerprint ON public.mybot_inbound_messages USING btree (text_fingerprint, received_at DESC) WHERE (parse_status = 'parsed'::text);


--
-- Name: idx_mybot_inbound_from_phone_received; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mybot_inbound_from_phone_received ON public.mybot_inbound_messages USING btree (from_phone, received_at DESC);


--
-- Name: idx_mybot_inbound_parse_status_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mybot_inbound_parse_status_pending ON public.mybot_inbound_messages USING btree (parse_status) WHERE (parse_status <> 'parsed'::text);


--
-- Name: idx_mybot_inbound_received; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mybot_inbound_received ON public.mybot_inbound_messages USING btree (received_at DESC);


--
-- Name: idx_product_catalog_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_product_catalog_client ON public.product_catalog USING btree (client_id);


--
-- Name: idx_rate_card_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_card_active ON public.rate_card USING btree (location_id, effective_from, effective_until);


--
-- Name: idx_stock_adj_agent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_agent ON public.stock_adjustments USING btree (agent_id);


--
-- Name: idx_stock_adj_agent_created_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_agent_created_desc ON public.stock_adjustments USING btree (agent_id, created_at DESC);


--
-- Name: idx_stock_adj_agent_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_agent_product ON public.stock_adjustments USING btree (agent_id, product_catalog_id);


--
-- Name: idx_stock_adj_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_created_at_id ON public.stock_adjustments USING btree (created_at DESC, id DESC);


--
-- Name: idx_stock_adj_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_delivery ON public.stock_adjustments USING btree (delivery_id) WHERE (delivery_id IS NOT NULL);


--
-- Name: idx_stock_adj_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_product ON public.stock_adjustments USING btree (product_catalog_id);


--
-- Name: idx_stock_adj_product_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_product_created ON public.stock_adjustments USING btree (product_catalog_id, created_at DESC, id DESC);


--
-- Name: idx_stock_adj_related; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_adj_related ON public.stock_adjustments USING btree (related_adjustment_id);


--
-- Name: idx_stock_counts_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_counts_batch ON public.stock_counts USING btree (batch_id);


--
-- Name: idx_stock_counts_holder_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_counts_holder_product ON public.stock_counts USING btree (holder_id, product_catalog_id, counted_at DESC);


--
-- Name: idx_users_role_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_role_active ON public.users USING btree (role) WHERE (is_active = true);


--
-- Name: push_tokens_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_tokens_user_idx ON public.push_tokens USING btree (user_id);


--
-- Name: replacement_attempts_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX replacement_attempts_delivery ON public.replacement_attempts USING btree (delivery_id, attempted_at DESC);


--
-- Name: replacement_attempts_financial_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX replacement_attempts_financial_day ON public.replacement_attempts USING btree ((((attempted_at AT TIME ZONE 'Africa/Lagos'::text))::date));


--
-- Name: replacement_attempts_ledger_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX replacement_attempts_ledger_activity ON public.replacement_attempts USING btree (attempted_at, delivery_id);


--
-- Name: replacement_return_events_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX replacement_return_events_item ON public.replacement_return_events USING btree (return_item_id, created_at);


--
-- Name: replacement_returns_custody_queue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX replacement_returns_custody_queue ON public.replacement_return_items USING btree (custody_state, collected_at) WHERE (custody_state = ANY (ARRAY['with_rider_usable_pending_inspection'::text, 'with_rider_damaged_hold'::text, 'warehouse_hold_for_vendor'::text]));


--
-- Name: replacement_returns_delivery; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX replacement_returns_delivery ON public.replacement_return_items USING btree (delivery_id);


--
-- Name: same_customer_completion_reviews_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_completion_reviews_event_idx ON public.same_customer_completion_reviews USING btree (delivery_id, completion_event_id, created_at DESC, request_id DESC);


--
-- Name: same_customer_earnings_group_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_earnings_group_idx ON public.same_customer_earnings USING btree (group_id, recorded_at, completion_event_id) WHERE active;


--
-- Name: same_customer_earnings_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_earnings_period_idx ON public.same_customer_earnings USING btree (rider_id, accounting_date) WHERE active;


--
-- Name: same_customer_fee_decisions_delivery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_fee_decisions_delivery_idx ON public.same_customer_fee_decisions USING btree (delivery_id, id DESC);


--
-- Name: same_customer_final_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_final_pending_idx ON public.same_customer_earnings USING btree (rider_id, accounting_date) WHERE (active AND policy_applied AND (final_state = 'pending'::text));


--
-- Name: same_customer_final_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_final_period_idx ON public.same_customer_earnings USING btree (accounting_date, rider_id, delivery_id) WHERE (policy_applied AND active);


--
-- Name: same_customer_normal_fee_reviews_delivery_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX same_customer_normal_fee_reviews_delivery_idx ON public.same_customer_normal_fee_reviews USING btree (delivery_id, created_at DESC);


--
-- Name: settlements_by_date_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX settlements_by_date_active ON public.settlements USING btree (period_date) WHERE (voided_at IS NULL);


--
-- Name: settlements_one_active_per_subject_day; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX settlements_one_active_per_subject_day ON public.settlements USING btree (subject_type, subject_id, period_date) WHERE (voided_at IS NULL);


--
-- Name: stock_adjustments_client_uuid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_adjustments_client_uuid_idx ON public.stock_adjustments USING btree (client_uuid);


--
-- Name: uniq_rate_card_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_rate_card_current ON public.rate_card USING btree (location_id) WHERE (effective_until IS NULL);


--
-- Name: users_parent_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_parent_agent_id_idx ON public.users USING btree (parent_agent_id) WHERE (parent_agent_id IS NOT NULL);


--
-- Name: users_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_warehouse_id_idx ON public.users USING btree (warehouse_id) WHERE (warehouse_id IS NOT NULL);


--
-- Name: bot_inbound_messages bot_parse_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER bot_parse_on_insert AFTER INSERT ON public.bot_inbound_messages FOR EACH ROW EXECUTE FUNCTION supabase_functions.http_request('http://kong:8000/functions/v1/bot-parse-message', 'POST', '{"Content-type":"application/json","x-internal-secret":"isolated-test"}', '{}', '5000');


--
-- Name: deliveries clear_followup_on_status_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER clear_followup_on_status_change AFTER UPDATE OF current_status ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_clear_followup_on_status_change();


--
-- Name: clients clients_auto_initialize_balance; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER clients_auto_initialize_balance AFTER INSERT ON public.clients FOR EACH ROW EXECUTE FUNCTION public.tg_auto_initialize_client_balance();


--
-- Name: deliveries copy_items_on_rollover; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER copy_items_on_rollover AFTER INSERT ON public.deliveries FOR EACH ROW WHEN ((new.created_via = 'rollover'::text)) EXECUTE FUNCTION public.tg_copy_items_on_rollover();


--
-- Name: deliveries guard_same_customer_identity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_same_customer_identity BEFORE INSERT OR UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public._guard_same_customer_identity();


--
-- Name: deliveries guard_same_customer_normal_fee; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_same_customer_normal_fee BEFORE INSERT OR UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public._guard_same_customer_normal_fee();


--
-- Name: deliveries handle_sibling_coordination; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER handle_sibling_coordination AFTER UPDATE OF current_status, scheduled_date ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_handle_sibling_coordination();


--
-- Name: mybot_inbound_messages mybot_parse_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER mybot_parse_on_insert AFTER INSERT ON public.mybot_inbound_messages FOR EACH ROW EXECUTE FUNCTION supabase_functions.http_request('http://kong:8000/functions/v1/mybot-parse-message', 'POST', '{"Content-type":"application/json","x-internal-secret":"isolated-test"}', '{}', '5000');


--
-- Name: deliveries notify_assignment_push; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_assignment_push AFTER INSERT OR UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_notify_assignment_push();


--
-- Name: bot_inbound_messages notify_bot_error; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_bot_error AFTER INSERT OR UPDATE ON public.bot_inbound_messages FOR EACH ROW EXECUTE FUNCTION public.tg_notify_bot_error();


--
-- Name: bot_inbound_messages notify_bot_review; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_bot_review AFTER INSERT OR UPDATE ON public.bot_inbound_messages FOR EACH ROW EXECUTE FUNCTION public.tg_notify_bot_review();


--
-- Name: delivery_messages notify_delivery_message; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_delivery_message AFTER INSERT ON public.delivery_messages FOR EACH ROW EXECUTE FUNCTION public.tg_notify_delivery_message();


--
-- Name: deliveries notify_delivery_status_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_delivery_status_change AFTER INSERT OR UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_notify_delivery_status_change();


--
-- Name: stock_adjustments notify_negative_stock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER notify_negative_stock AFTER INSERT ON public.stock_adjustments FOR EACH ROW EXECUTE FUNCTION public.tg_notify_negative_stock();


--
-- Name: replacement_attempts same_customer_attempt_write_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_attempt_write_lock BEFORE INSERT OR DELETE OR UPDATE ON public.replacement_attempts FOR EACH ROW EXECUTE FUNCTION public._same_customer_attempt_financial_lock();


--
-- Name: same_customer_earnings same_customer_earning_audit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_earning_audit AFTER INSERT OR UPDATE ON public.same_customer_earnings FOR EACH ROW EXECUTE FUNCTION public._same_customer_earning_audit();


--
-- Name: deliveries same_customer_financial_write_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_financial_write_lock BEFORE INSERT OR DELETE OR UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public._same_customer_delivery_financial_lock();


--
-- Name: deliveries same_customer_settled_delivery_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_settled_delivery_guard BEFORE UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public._guard_same_customer_settled_delivery();


--
-- Name: settlements same_customer_settlement_write_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_settlement_write_lock BEFORE INSERT OR DELETE OR UPDATE ON public.settlements FOR EACH ROW EXECUTE FUNCTION public._same_customer_settlement_financial_lock();


--
-- Name: deliveries same_customer_shadow_delivery; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_shadow_delivery AFTER UPDATE OF current_status, deleted_at, customer_phone, same_customer_key_override, agent_payment_snapshot, agent_payment_base_snapshot, agent_payment_base_captured_at ON public.deliveries FOR EACH ROW WHEN ((((((((old.current_status IS DISTINCT FROM new.current_status) OR (old.deleted_at IS DISTINCT FROM new.deleted_at)) OR (old.customer_phone IS DISTINCT FROM new.customer_phone)) OR (old.same_customer_key_override IS DISTINCT FROM new.same_customer_key_override)) OR (old.agent_payment_snapshot IS DISTINCT FROM new.agent_payment_snapshot)) OR (old.agent_payment_base_snapshot IS DISTINCT FROM new.agent_payment_base_snapshot)) OR (old.agent_payment_base_captured_at IS DISTINCT FROM new.agent_payment_base_captured_at))) EXECUTE FUNCTION public._same_customer_shadow_delivery();


--
-- Name: delivery_status_history same_customer_shadow_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER same_customer_shadow_history AFTER INSERT ON public.delivery_status_history FOR EACH ROW WHEN (((new.to_status = 'delivered'::text) OR (new.from_status = 'delivered'::text))) EXECUTE FUNCTION public._same_customer_shadow_history();


--
-- Name: deliveries signal_new_sibling; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER signal_new_sibling AFTER INSERT ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_signal_new_sibling();


--
-- Name: deliveries signal_new_sibling_on_assign; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER signal_new_sibling_on_assign AFTER UPDATE OF assigned_agent_id ON public.deliveries FOR EACH ROW WHEN (((old.assigned_agent_id IS NULL) AND (new.assigned_agent_id IS NOT NULL))) EXECUTE FUNCTION public.tg_signal_new_sibling();


--
-- Name: calls tg_calls_set_channel; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_calls_set_channel BEFORE INSERT ON public.calls FOR EACH ROW EXECUTE FUNCTION public._calls_set_channel();


--
-- Name: calls tg_notify_call_invite_push; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tg_notify_call_invite_push AFTER INSERT ON public.calls FOR EACH ROW EXECUTE FUNCTION public.notify_call_invite_push();


--
-- Name: deliveries trg_auto_assign_on_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_auto_assign_on_insert AFTER INSERT ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_auto_assign_on_insert();


--
-- Name: TRIGGER trg_auto_assign_on_insert ON deliveries; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER trg_auto_assign_on_insert ON public.deliveries IS 'If create_delivery() inserts without an assignee, fire auto_assign_delivery(). The resulting UPDATE drives the existing assignment-push webhook.';


--
-- Name: deliveries trg_deliveries_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_deliveries_updated_at BEFORE UPDATE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: deliveries trg_guard_replacement_delivery_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_replacement_delivery_delete BEFORE DELETE ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.guard_replacement_delivery_mutation();


--
-- Name: deliveries trg_guard_replacement_delivery_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_replacement_delivery_update BEFORE UPDATE OF current_status, deleted_at ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.guard_replacement_delivery_mutation();


--
-- Name: deliveries trg_set_assigned_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_set_assigned_at BEFORE INSERT OR UPDATE OF assigned_agent_id ON public.deliveries FOR EACH ROW EXECUTE FUNCTION public.tg_set_assigned_at();


--
-- Name: delivery_status_history trg_status_history_no_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_status_history_no_delete BEFORE DELETE ON public.delivery_status_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_modification();


--
-- Name: delivery_status_history trg_status_history_no_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_status_history_no_update BEFORE UPDATE ON public.delivery_status_history FOR EACH ROW EXECUTE FUNCTION public.prevent_history_modification();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_authorizations
    ADD CONSTRAINT oauth_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_client_id_fkey FOREIGN KEY (client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_consents
    ADD CONSTRAINT oauth_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_oauth_client_id_fkey FOREIGN KEY (oauth_client_id) REFERENCES auth.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_challenges
    ADD CONSTRAINT webauthn_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: address_match_log address_match_log_corrected_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_match_log
    ADD CONSTRAINT address_match_log_corrected_by_user_id_fkey FOREIGN KEY (corrected_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: address_match_log address_match_log_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_match_log
    ADD CONSTRAINT address_match_log_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: address_match_log address_match_log_matched_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_match_log
    ADD CONSTRAINT address_match_log_matched_location_id_fkey FOREIGN KEY (matched_location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: address_match_log address_match_log_override_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.address_match_log
    ADD CONSTRAINT address_match_log_override_location_id_fkey FOREIGN KEY (override_location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: agent_departures agent_departures_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_departures
    ADD CONSTRAINT agent_departures_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_departures agent_departures_departed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_departures
    ADD CONSTRAINT agent_departures_departed_by_fkey FOREIGN KEY (departed_by) REFERENCES public.users(id);


--
-- Name: agent_location_preferences agent_location_preferences_agent_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_location_preferences
    ADD CONSTRAINT agent_location_preferences_agent_profile_id_fkey FOREIGN KEY (agent_profile_id) REFERENCES public.agent_profiles(id) ON DELETE CASCADE;


--
-- Name: agent_location_preferences agent_location_preferences_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_location_preferences
    ADD CONSTRAINT agent_location_preferences_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: agent_locations agent_locations_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_locations
    ADD CONSTRAINT agent_locations_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_locations agent_locations_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_locations
    ADD CONSTRAINT agent_locations_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: agent_locations agent_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_locations
    ADD CONSTRAINT agent_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE RESTRICT;


--
-- Name: agent_profiles agent_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_profiles
    ADD CONSTRAINT agent_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agent_stock_count_submissions agent_stock_count_submissions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_stock_count_submissions
    ADD CONSTRAINT agent_stock_count_submissions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: ai_config ai_config_updated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ai_config
    ADD CONSTRAINT ai_config_updated_by_user_id_fkey FOREIGN KEY (updated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_changed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_changed_by_user_id_fkey FOREIGN KEY (changed_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: bot_inbound_messages bot_inbound_messages_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bot_inbound_messages
    ADD CONSTRAINT bot_inbound_messages_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE SET NULL;


--
-- Name: calls calls_callee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_callee_id_fkey FOREIGN KEY (callee_id) REFERENCES public.users(id);


--
-- Name: calls calls_caller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_caller_id_fkey FOREIGN KEY (caller_id) REFERENCES public.users(id);


--
-- Name: calls calls_related_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_related_delivery_id_fkey FOREIGN KEY (related_delivery_id) REFERENCES public.deliveries(id) ON DELETE SET NULL;


--
-- Name: client_balance_openings client_balance_openings_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_balance_openings
    ADD CONSTRAINT client_balance_openings_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: client_balance_openings client_balance_openings_set_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_balance_openings
    ADD CONSTRAINT client_balance_openings_set_by_fkey FOREIGN KEY (set_by) REFERENCES public.users(id);


--
-- Name: client_payments client_payments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_payments client_payments_received_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_received_by_fkey FOREIGN KEY (received_by) REFERENCES public.users(id);


--
-- Name: client_payments client_payments_voided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payments
    ADD CONSTRAINT client_payments_voided_by_fkey FOREIGN KEY (voided_by) REFERENCES public.users(id);


--
-- Name: client_payouts client_payouts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payouts
    ADD CONSTRAINT client_payouts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_payouts client_payouts_paid_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payouts
    ADD CONSTRAINT client_payouts_paid_by_fkey FOREIGN KEY (paid_by) REFERENCES public.users(id);


--
-- Name: client_payouts client_payouts_voided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_payouts
    ADD CONSTRAINT client_payouts_voided_by_fkey FOREIGN KEY (voided_by) REFERENCES public.users(id);


--
-- Name: customer_blacklist customer_blacklist_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_blacklist
    ADD CONSTRAINT customer_blacklist_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: customer_blacklist customer_blacklist_removed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_blacklist
    ADD CONSTRAINT customer_blacklist_removed_by_fkey FOREIGN KEY (removed_by) REFERENCES public.users(id);


--
-- Name: customer_blacklist customer_blacklist_source_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_blacklist
    ADD CONSTRAINT customer_blacklist_source_delivery_id_fkey FOREIGN KEY (source_delivery_id) REFERENCES public.deliveries(id);


--
-- Name: deliveries deliveries_assigned_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_assigned_agent_id_fkey FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: deliveries deliveries_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: deliveries deliveries_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: deliveries deliveries_current_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_current_status_fkey FOREIGN KEY (current_status) REFERENCES public.delivery_status_defs(status) ON DELETE RESTRICT;


--
-- Name: deliveries deliveries_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE RESTRICT;


--
-- Name: deliveries deliveries_parent_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_parent_delivery_id_fkey FOREIGN KEY (parent_delivery_id) REFERENCES public.deliveries(id) ON DELETE SET NULL;


--
-- Name: deliveries deliveries_product_catalog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_product_catalog_id_fkey FOREIGN KEY (product_catalog_id) REFERENCES public.product_catalog(id) ON DELETE RESTRICT;


--
-- Name: delivery_client_notifications delivery_client_notifications_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_client_notifications
    ADD CONSTRAINT delivery_client_notifications_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: delivery_client_notifications delivery_client_notifications_notified_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_client_notifications
    ADD CONSTRAINT delivery_client_notifications_notified_by_user_id_fkey FOREIGN KEY (notified_by_user_id) REFERENCES public.users(id);


--
-- Name: delivery_client_notifications delivery_client_notifications_status_history_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_client_notifications
    ADD CONSTRAINT delivery_client_notifications_status_history_id_fkey FOREIGN KEY (status_history_id) REFERENCES public.delivery_status_history(id) ON DELETE CASCADE;


--
-- Name: delivery_followups delivery_followups_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_followups
    ADD CONSTRAINT delivery_followups_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: delivery_followups delivery_followups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_followups
    ADD CONSTRAINT delivery_followups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: delivery_items delivery_items_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: delivery_items delivery_items_product_catalog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_items
    ADD CONSTRAINT delivery_items_product_catalog_id_fkey FOREIGN KEY (product_catalog_id) REFERENCES public.product_catalog(id) ON DELETE RESTRICT;


--
-- Name: delivery_location_changes delivery_location_changes_decided_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT delivery_location_changes_decided_by_user_id_fkey FOREIGN KEY (decided_by_user_id) REFERENCES public.users(id);


--
-- Name: delivery_location_changes delivery_location_changes_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT delivery_location_changes_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: delivery_location_changes delivery_location_changes_from_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT delivery_location_changes_from_location_id_fkey FOREIGN KEY (from_location_id) REFERENCES public.locations(id);


--
-- Name: delivery_location_changes delivery_location_changes_requested_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT delivery_location_changes_requested_by_agent_id_fkey FOREIGN KEY (requested_by_agent_id) REFERENCES public.users(id);


--
-- Name: delivery_location_changes delivery_location_changes_to_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_location_changes
    ADD CONSTRAINT delivery_location_changes_to_location_id_fkey FOREIGN KEY (to_location_id) REFERENCES public.locations(id);


--
-- Name: delivery_messages delivery_messages_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_messages
    ADD CONSTRAINT delivery_messages_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: delivery_messages delivery_messages_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_messages
    ADD CONSTRAINT delivery_messages_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: delivery_status_history delivery_status_history_changed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_history
    ADD CONSTRAINT delivery_status_history_changed_by_user_id_fkey FOREIGN KEY (changed_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: delivery_status_history delivery_status_history_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_history
    ADD CONSTRAINT delivery_status_history_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: delivery_status_history delivery_status_history_from_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_history
    ADD CONSTRAINT delivery_status_history_from_status_fkey FOREIGN KEY (from_status) REFERENCES public.delivery_status_defs(status) ON DELETE RESTRICT;


--
-- Name: delivery_status_history delivery_status_history_to_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_history
    ADD CONSTRAINT delivery_status_history_to_status_fkey FOREIGN KEY (to_status) REFERENCES public.delivery_status_defs(status) ON DELETE RESTRICT;


--
-- Name: delivery_status_transitions delivery_status_transitions_from_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_transitions
    ADD CONSTRAINT delivery_status_transitions_from_status_fkey FOREIGN KEY (from_status) REFERENCES public.delivery_status_defs(status);


--
-- Name: delivery_status_transitions delivery_status_transitions_to_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delivery_status_transitions
    ADD CONSTRAINT delivery_status_transitions_to_status_fkey FOREIGN KEY (to_status) REFERENCES public.delivery_status_defs(status);


--
-- Name: edit_locks edit_locks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.edit_locks
    ADD CONSTRAINT edit_locks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: feature_flags feature_flags_updated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_flags
    ADD CONSTRAINT feature_flags_updated_by_user_id_fkey FOREIGN KEY (updated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: mybot_inbound_messages mybot_inbound_messages_paired_contractor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mybot_inbound_messages
    ADD CONSTRAINT mybot_inbound_messages_paired_contractor_id_fkey FOREIGN KEY (paired_contractor_id) REFERENCES public.bot_inbound_messages(id);


--
-- Name: product_catalog product_catalog_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_catalog
    ADD CONSTRAINT product_catalog_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: push_tokens push_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_tokens
    ADD CONSTRAINT push_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: rate_card rate_card_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_card
    ADD CONSTRAINT rate_card_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: rate_card rate_card_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_card
    ADD CONSTRAINT rate_card_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE RESTRICT;


--
-- Name: replacement_attempts replacement_attempts_assigned_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_attempts
    ADD CONSTRAINT replacement_attempts_assigned_agent_id_fkey FOREIGN KEY (assigned_agent_id) REFERENCES public.users(id);


--
-- Name: replacement_attempts replacement_attempts_attempted_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_attempts
    ADD CONSTRAINT replacement_attempts_attempted_by_user_id_fkey FOREIGN KEY (attempted_by_user_id) REFERENCES public.users(id);


--
-- Name: replacement_attempts replacement_attempts_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_attempts
    ADD CONSTRAINT replacement_attempts_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.replacement_jobs(delivery_id) ON DELETE CASCADE;


--
-- Name: replacement_attempts replacement_attempts_status_after_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_attempts
    ADD CONSTRAINT replacement_attempts_status_after_fkey FOREIGN KEY (status_after) REFERENCES public.delivery_status_defs(status);


--
-- Name: replacement_jobs replacement_jobs_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_jobs
    ADD CONSTRAINT replacement_jobs_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: replacement_jobs replacement_jobs_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_jobs
    ADD CONSTRAINT replacement_jobs_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE CASCADE;


--
-- Name: replacement_jobs replacement_jobs_original_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_jobs
    ADD CONSTRAINT replacement_jobs_original_delivery_id_fkey FOREIGN KEY (original_delivery_id) REFERENCES public.deliveries(id) ON DELETE SET NULL;


--
-- Name: replacement_return_events replacement_return_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_events
    ADD CONSTRAINT replacement_return_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: replacement_return_events replacement_return_events_from_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_events
    ADD CONSTRAINT replacement_return_events_from_holder_id_fkey FOREIGN KEY (from_holder_id) REFERENCES public.users(id);


--
-- Name: replacement_return_events replacement_return_events_return_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_events
    ADD CONSTRAINT replacement_return_events_return_item_id_fkey FOREIGN KEY (return_item_id) REFERENCES public.replacement_return_items(id) ON DELETE CASCADE;


--
-- Name: replacement_return_events replacement_return_events_to_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_events
    ADD CONSTRAINT replacement_return_events_to_holder_id_fkey FOREIGN KEY (to_holder_id) REFERENCES public.users(id);


--
-- Name: replacement_return_items replacement_return_items_current_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_items
    ADD CONSTRAINT replacement_return_items_current_holder_id_fkey FOREIGN KEY (current_holder_id) REFERENCES public.users(id);


--
-- Name: replacement_return_items replacement_return_items_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_items
    ADD CONSTRAINT replacement_return_items_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.replacement_jobs(delivery_id) ON DELETE CASCADE;


--
-- Name: replacement_return_items replacement_return_items_inspected_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_items
    ADD CONSTRAINT replacement_return_items_inspected_by_user_id_fkey FOREIGN KEY (inspected_by_user_id) REFERENCES public.users(id);


--
-- Name: replacement_return_items replacement_return_items_product_catalog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_items
    ADD CONSTRAINT replacement_return_items_product_catalog_id_fkey FOREIGN KEY (product_catalog_id) REFERENCES public.product_catalog(id);


--
-- Name: replacement_return_items replacement_return_items_stock_adjustment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.replacement_return_items
    ADD CONSTRAINT replacement_return_items_stock_adjustment_id_fkey FOREIGN KEY (stock_adjustment_id) REFERENCES public.stock_adjustments(id);


--
-- Name: same_customer_assignment_requests same_customer_assignment_requests_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_assignment_requests
    ADD CONSTRAINT same_customer_assignment_requests_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: same_customer_assignment_requests same_customer_assignment_requests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_assignment_requests
    ADD CONSTRAINT same_customer_assignment_requests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id);


--
-- Name: same_customer_completion_reviews same_customer_completion_reviews_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_completion_reviews
    ADD CONSTRAINT same_customer_completion_reviews_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: same_customer_completion_reviews same_customer_completion_reviews_completion_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_completion_reviews
    ADD CONSTRAINT same_customer_completion_reviews_completion_event_id_fkey FOREIGN KEY (completion_event_id) REFERENCES public.delivery_status_history(id);


--
-- Name: same_customer_completion_reviews same_customer_completion_reviews_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_completion_reviews
    ADD CONSTRAINT same_customer_completion_reviews_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: same_customer_decisions same_customer_decisions_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_decisions
    ADD CONSTRAINT same_customer_decisions_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: same_customer_earning_revisions same_customer_earning_revisions_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earning_revisions
    ADD CONSTRAINT same_customer_earning_revisions_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: same_customer_earnings same_customer_earnings_completion_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earnings
    ADD CONSTRAINT same_customer_earnings_completion_event_id_fkey FOREIGN KEY (completion_event_id) REFERENCES public.delivery_status_history(id);


--
-- Name: same_customer_earnings same_customer_earnings_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earnings
    ADD CONSTRAINT same_customer_earnings_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: same_customer_earnings same_customer_earnings_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earnings
    ADD CONSTRAINT same_customer_earnings_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.same_customer_pay_groups(id);


--
-- Name: same_customer_earnings same_customer_earnings_rider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_earnings
    ADD CONSTRAINT same_customer_earnings_rider_id_fkey FOREIGN KEY (rider_id) REFERENCES public.users(id);


--
-- Name: same_customer_fee_decisions same_customer_fee_decisions_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_fee_decisions
    ADD CONSTRAINT same_customer_fee_decisions_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: same_customer_fee_decisions same_customer_fee_decisions_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_fee_decisions
    ADD CONSTRAINT same_customer_fee_decisions_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: same_customer_manual_reviews same_customer_manual_reviews_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_manual_reviews
    ADD CONSTRAINT same_customer_manual_reviews_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: same_customer_manual_reviews same_customer_manual_reviews_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_manual_reviews
    ADD CONSTRAINT same_customer_manual_reviews_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.same_customer_pay_groups(id);


--
-- Name: same_customer_normal_fee_reviews same_customer_normal_fee_reviews_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_normal_fee_reviews
    ADD CONSTRAINT same_customer_normal_fee_reviews_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: same_customer_normal_fee_reviews same_customer_normal_fee_reviews_completion_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_normal_fee_reviews
    ADD CONSTRAINT same_customer_normal_fee_reviews_completion_event_id_fkey FOREIGN KEY (completion_event_id) REFERENCES public.delivery_status_history(id);


--
-- Name: same_customer_normal_fee_reviews same_customer_normal_fee_reviews_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_normal_fee_reviews
    ADD CONSTRAINT same_customer_normal_fee_reviews_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id);


--
-- Name: same_customer_pay_groups same_customer_pay_groups_rider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.same_customer_pay_groups
    ADD CONSTRAINT same_customer_pay_groups_rider_id_fkey FOREIGN KEY (rider_id) REFERENCES public.users(id);


--
-- Name: settlement_batches settlement_batches_settled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settlement_batches
    ADD CONSTRAINT settlement_batches_settled_by_fkey FOREIGN KEY (settled_by) REFERENCES public.users(id);


--
-- Name: settlements settlements_settled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_settled_by_fkey FOREIGN KEY (settled_by) REFERENCES public.users(id);


--
-- Name: settlements settlements_voided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_voided_by_fkey FOREIGN KEY (voided_by) REFERENCES public.users(id);


--
-- Name: stock_adjustments stock_adjustments_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: stock_adjustments stock_adjustments_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: stock_adjustments stock_adjustments_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.deliveries(id) ON DELETE SET NULL;


--
-- Name: stock_adjustments stock_adjustments_product_catalog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_product_catalog_id_fkey FOREIGN KEY (product_catalog_id) REFERENCES public.product_catalog(id) ON DELETE RESTRICT;


--
-- Name: stock_adjustments stock_adjustments_related_adjustment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_adjustments
    ADD CONSTRAINT stock_adjustments_related_adjustment_id_fkey FOREIGN KEY (related_adjustment_id) REFERENCES public.stock_adjustments(id) ON DELETE SET NULL;


--
-- Name: stock_counts stock_counts_counted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_counted_by_fkey FOREIGN KEY (counted_by) REFERENCES public.users(id);


--
-- Name: stock_counts stock_counts_holder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_holder_id_fkey FOREIGN KEY (holder_id) REFERENCES public.users(id);


--
-- Name: stock_counts stock_counts_product_catalog_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_counts
    ADD CONSTRAINT stock_counts_product_catalog_id_fkey FOREIGN KEY (product_catalog_id) REFERENCES public.product_catalog(id);


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_parent_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_parent_agent_id_fkey FOREIGN KEY (parent_agent_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: users users_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: address_match_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.address_match_log ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_departures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_departures ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_departures agent_departures_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_departures_select ON public.agent_departures FOR SELECT USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR ( SELECT public.is_warehouse() AS is_warehouse) OR (agent_id = ( SELECT auth.uid() AS uid))));


--
-- Name: agent_location_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_location_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_locations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_locations ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_locations agent_locations_admin_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_locations_admin_all ON public.agent_locations TO authenticated USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: agent_locations agent_locations_self_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_locations_self_read ON public.agent_locations FOR SELECT TO authenticated USING ((agent_id = ( SELECT auth.uid() AS uid)));


--
-- Name: agent_profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_profiles agent_profiles_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_profiles_all_admin ON public.agent_profiles USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: agent_profiles agent_profiles_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_profiles_select_all ON public.agent_profiles FOR SELECT USING (true);


--
-- Name: agent_stock_count_submissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_stock_count_submissions ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_stock_count_submissions agent_stock_count_submissions_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_stock_count_submissions_select ON public.agent_stock_count_submissions FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR ( SELECT public.is_warehouse() AS is_warehouse) OR (agent_id = ( SELECT auth.uid() AS uid))));


--
-- Name: ai_config; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ai_config ENABLE ROW LEVEL SECURITY;

--
-- Name: ai_config ai_config_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ai_config_all_admin ON public.ai_config USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: ai_config ai_config_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ai_config_select_admin_dispatcher ON public.ai_config FOR SELECT USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher));


--
-- Name: agent_location_preferences alp_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alp_all_admin ON public.agent_location_preferences USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: agent_location_preferences alp_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alp_select_all ON public.agent_location_preferences FOR SELECT USING (true);


--
-- Name: address_match_log aml_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aml_all_admin ON public.address_match_log USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: address_match_log aml_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY aml_select_admin_dispatcher ON public.address_match_log FOR SELECT USING (( SELECT public.is_manager() AS is_manager));


--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_log audit_log_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_log_select_admin_dispatcher ON public.audit_log FOR SELECT USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher));


--
-- Name: bot_inbound_messages bot_inbound_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bot_inbound_all_admin ON public.bot_inbound_messages USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: bot_inbound_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bot_inbound_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: bot_inbound_messages bot_inbound_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bot_inbound_select_admin_dispatcher ON public.bot_inbound_messages FOR SELECT USING (( SELECT public.is_manager() AS is_manager));


--
-- Name: calls; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;

--
-- Name: calls calls_select_participants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY calls_select_participants ON public.calls FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR (caller_id = ( SELECT auth.uid() AS uid)) OR (callee_id = ( SELECT auth.uid() AS uid))));


--
-- Name: client_balance_openings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_balance_openings ENABLE ROW LEVEL SECURITY;

--
-- Name: client_payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: client_payouts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.client_payouts ENABLE ROW LEVEL SECURITY;

--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: clients clients_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clients_all_admin ON public.clients USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: clients clients_select_ops_warehouse; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clients_select_ops_warehouse ON public.clients FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR ( SELECT public.is_warehouse() AS is_warehouse)));


--
-- Name: POLICY clients_select_ops_warehouse ON clients; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON POLICY clients_select_ops_warehouse ON public.clients IS 'Anti-poaching: vendor (client) names are operational data. Ops (admin/dispatcher/rep) and warehouse (place + staff) need them — warehouse groups, labels and picks stock by client. Agents never read the client list (that exposure would tip them which vendors to approach off-platform). Matches canSeeClientName for ops + the warehouse stock surface.';


--
-- Name: current_stock_parity_baseline; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.current_stock_parity_baseline ENABLE ROW LEVEL SECURITY;

--
-- Name: customer_blacklist; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customer_blacklist ENABLE ROW LEVEL SECURITY;

--
-- Name: customer_blacklist customer_blacklist_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY customer_blacklist_select ON public.customer_blacklist FOR SELECT TO authenticated USING (public.is_admin_or_dispatcher());


--
-- Name: delivery_client_notifications dcn_select_ops_or_self_agent; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY dcn_select_ops_or_self_agent ON public.delivery_client_notifications FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR (EXISTS ( SELECT 1
   FROM public.deliveries d
  WHERE ((d.id = delivery_client_notifications.delivery_id) AND (d.assigned_agent_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: deliveries deliveries_delete_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY deliveries_delete_admin ON public.deliveries FOR DELETE USING (( SELECT public.is_admin() AS is_admin));


--
-- Name: deliveries deliveries_insert_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY deliveries_insert_admin_dispatcher ON public.deliveries FOR INSERT WITH CHECK (( SELECT public.is_manager() AS is_manager));


--
-- Name: deliveries deliveries_select_role_scoped; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY deliveries_select_role_scoped ON public.deliveries FOR SELECT USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR (assigned_agent_id = ( SELECT auth.uid() AS uid))));


--
-- Name: deliveries deliveries_update_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY deliveries_update_admin_dispatcher ON public.deliveries FOR UPDATE USING (( SELECT public.is_manager() AS is_manager)) WITH CHECK (( SELECT public.is_manager() AS is_manager));


--
-- Name: delivery_client_notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_client_notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_followups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_followups ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_followups delivery_followups_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_followups_select_admin_dispatcher ON public.delivery_followups FOR SELECT TO authenticated USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher));


--
-- Name: delivery_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_items ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_items delivery_items_select_role_scoped; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_items_select_role_scoped ON public.delivery_items FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR (EXISTS ( SELECT 1
   FROM public.deliveries d
  WHERE ((d.id = delivery_items.delivery_id) AND (d.assigned_agent_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: delivery_location_changes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_location_changes ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_messages delivery_messages_select_participants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_messages_select_participants ON public.delivery_messages FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR (author_id = ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM public.deliveries d
  WHERE ((d.id = delivery_messages.delivery_id) AND (d.assigned_agent_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: delivery_status_defs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_status_defs ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_status_defs delivery_status_defs_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_status_defs_all_admin ON public.delivery_status_defs USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: delivery_status_defs delivery_status_defs_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_status_defs_select_all ON public.delivery_status_defs FOR SELECT USING (true);


--
-- Name: delivery_status_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_status_history ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_status_transitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.delivery_status_transitions ENABLE ROW LEVEL SECURITY;

--
-- Name: delivery_status_transitions delivery_status_transitions_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_status_transitions_all_admin ON public.delivery_status_transitions USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: delivery_status_transitions delivery_status_transitions_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY delivery_status_transitions_select_all ON public.delivery_status_transitions FOR SELECT USING (true);


--
-- Name: delivery_location_changes dlc_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY dlc_select_own ON public.delivery_location_changes FOR SELECT TO authenticated USING (((requested_by_agent_id = ( SELECT auth.uid() AS uid)) OR ( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher)));


--
-- Name: delivery_status_history dsh_insert_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY dsh_insert_admin_dispatcher ON public.delivery_status_history FOR INSERT WITH CHECK (( SELECT public.is_manager() AS is_manager));


--
-- Name: delivery_status_history dsh_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY dsh_select_all ON public.delivery_status_history FOR SELECT USING (true);


--
-- Name: edit_locks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.edit_locks ENABLE ROW LEVEL SECURITY;

--
-- Name: edit_locks edit_locks_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY edit_locks_select_admin_dispatcher ON public.edit_locks FOR SELECT TO authenticated USING (( SELECT public.is_manager() AS is_manager));


--
-- Name: feature_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_flags ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_flags feature_flags_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY feature_flags_all_admin ON public.feature_flags USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: feature_flags feature_flags_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY feature_flags_select_admin_dispatcher ON public.feature_flags FOR SELECT USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher));


--
-- Name: locations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;

--
-- Name: locations locations_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY locations_all_admin ON public.locations USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: locations locations_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY locations_select_all ON public.locations FOR SELECT USING (true);


--
-- Name: mybot_inbound_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mybot_inbound_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: mybot_inbound_messages mybot_inbound_select_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mybot_inbound_select_admin ON public.mybot_inbound_messages FOR SELECT USING (( SELECT public.is_manager() AS is_manager));


--
-- Name: mybot_inbound_messages mybot_inbound_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mybot_inbound_select_admin_dispatcher ON public.mybot_inbound_messages FOR SELECT USING (( SELECT public.is_manager() AS is_manager));


--
-- Name: product_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.product_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: product_catalog products_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY products_all_admin ON public.product_catalog USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: product_catalog products_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY products_select_all ON public.product_catalog FOR SELECT USING (true);


--
-- Name: push_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.push_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: push_tokens push_tokens_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY push_tokens_self ON public.push_tokens FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: rate_card; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rate_card ENABLE ROW LEVEL SECURITY;

--
-- Name: rate_card rate_card_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rate_card_all_admin ON public.rate_card USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: rate_card rate_card_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rate_card_select_admin_dispatcher ON public.rate_card FOR SELECT USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher));


--
-- Name: replacement_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.replacement_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: replacement_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.replacement_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: replacement_return_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.replacement_return_events ENABLE ROW LEVEL SECURITY;

--
-- Name: replacement_return_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.replacement_return_items ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_assignment_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_assignment_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_completion_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_completion_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_decisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_decisions ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_earning_revisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_earning_revisions ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_earnings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_earnings ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_fee_decisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_fee_decisions ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_manual_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_manual_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_normal_fee_reviews; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_normal_fee_reviews ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_pay_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_pay_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_pay_policy; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_pay_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_pay_policy_days; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_pay_policy_days ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_policy_audit; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_policy_audit ENABLE ROW LEVEL SECURITY;

--
-- Name: same_customer_projection_context; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.same_customer_projection_context ENABLE ROW LEVEL SECURITY;

--
-- Name: settlement_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.settlement_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: settlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.settlements ENABLE ROW LEVEL SECURITY;

--
-- Name: settlements settlements_select_ops; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY settlements_select_ops ON public.settlements FOR SELECT USING (( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher));


--
-- Name: stock_adjustments stock_adj_all_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY stock_adj_all_admin ON public.stock_adjustments USING (( SELECT public.is_admin() AS is_admin)) WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: stock_adjustments stock_adj_insert_warehouse_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY stock_adj_insert_warehouse_self ON public.stock_adjustments FOR INSERT TO authenticated WITH CHECK (((agent_id = COALESCE(( SELECT users.warehouse_id
   FROM public.users
  WHERE (users.id = ( SELECT auth.uid() AS uid))), ( SELECT auth.uid() AS uid))) AND (( SELECT users.role
   FROM public.users
  WHERE (users.id = ( SELECT auth.uid() AS uid))) = 'warehouse'::text)));


--
-- Name: stock_adjustments stock_adj_select_admin_dispatcher; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY stock_adj_select_admin_dispatcher ON public.stock_adjustments FOR SELECT TO authenticated USING (((( SELECT users.role
   FROM public.users
  WHERE (users.id = ( SELECT auth.uid() AS uid))) = ANY (ARRAY['admin'::text, 'dispatcher'::text])) OR (agent_id = ( SELECT auth.uid() AS uid)) OR (agent_id = ( SELECT users.warehouse_id
   FROM public.users
  WHERE (users.id = ( SELECT auth.uid() AS uid))))));


--
-- Name: stock_adjustments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_adjustments ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_counts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_counts ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_counts stock_counts_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY stock_counts_select ON public.stock_counts FOR SELECT TO authenticated USING ((( SELECT public.is_admin_or_dispatcher() AS is_admin_or_dispatcher) OR ( SELECT public.is_warehouse() AS is_warehouse) OR (holder_id = ( SELECT auth.uid() AS uid))));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_delete_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_delete_admin ON public.users FOR DELETE USING (( SELECT public.is_admin() AS is_admin));


--
-- Name: users users_insert_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_insert_admin ON public.users FOR INSERT WITH CHECK (( SELECT public.is_admin() AS is_admin));


--
-- Name: users users_select_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_select_all ON public.users FOR SELECT USING (true);


--
-- Name: users users_update_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_update_admin ON public.users FOR UPDATE USING (( SELECT public.is_admin() AS is_admin));


--
-- PostgreSQL database dump complete
--



